/**
 * Gestionnaire de checkout pour ToolHack Pro
 * Gère le processus de commande et de paiement 
 */
class CheckoutManager {
  constructor() {
    this.cart = window.cart;
    this.paymentManager = window.paymentManager || new (class DummyPaymentManager {})();
    this.tg = window.Telegram?.WebApp;
    this.i18n = window.i18n;
    this.userData = null;
    this.orderData = null;
    this.shipping = {
      methods: [
        { id: 'standard', name: 'Standard Shipping', price: 15, days: '5-7' },
        { id: 'express', name: 'Express Shipping', price: 30, days: '2-3' },
        { id: 'stealth', name: 'Stealth Shipping', price: 45, days: '3-5' }
      ],
      selected: 'stealth'
    };
    this.availableCountries = [
      { code: 'us', name: 'United States' },
      { code: 'ca', name: 'Canada' },
      { code: 'gb', name: 'United Kingdom' },
      { code: 'fr', name: 'France' },
      { code: 'de', name: 'Germany' },
      { code: 'nl', name: 'Netherlands' },
      { code: 'ch', name: 'Switzerland' },
      { code: 'au', name: 'Australia' },
      { code: 'nz', name: 'New Zealand' }
    ];
    this.paymentMethods = ['TON', 'BTC', 'XMR'];
    this.selectedPaymentMethod = 'TON';
    
    // Initialiser
    this.init();
  }

  /**
   * Initialise le gestionnaire de checkout
   */
  init() {
    // Vérifier si le panier est disponible
    if (!this.cart) {
      console.error('Cart not available for checkout');
      return;
    }

    // Vérifier les informations utilisateur
    this.getUserData();
    
    // Configurer les écouteurs d'événements
    this.setupEventListeners();
  }

  /**
   * Récupère les données utilisateur de Telegram si disponibles
   */
  getUserData() {
    if (this.tg && this.tg.initDataUnsafe && this.tg.initDataUnsafe.user) {
      this.userData = this.tg.initDataUnsafe.user;
      
      // Préfixer le nom d'utilisateur si disponible
      if (this.userData.username) {
        this.userData.preferredName = '@' + this.userData.username;
      } else {
        // Sinon utiliser le nom complet
        this.userData.preferredName = [
          this.userData.first_name,
          this.userData.last_name
        ].filter(Boolean).join(' ');
      }
    } else {
      this.userData = null;
    }
  }

  /**
   * Configure les écouteurs d'événements
   */
  setupEventListeners() {
    // Écouter le clic sur le bouton de checkout
    const checkoutBtn = document.getElementById('checkoutButton');
    if (checkoutBtn) {
      checkoutBtn.addEventListener('click', () => this.startCheckout());
    }
    
    // Observer les changements dans le panier
    if (this.cart && typeof this.cart.addListener === 'function') {
      this.cart.addListener(cartData => {
        // Mettre à jour l'état du bouton de checkout
        this.updateCheckoutButton(cartData);
      });
    }
  }

  /**
   * Met à jour l'état du bouton de checkout
   */
  updateCheckoutButton(cartData) {
    const checkoutBtn = document.getElementById('checkoutButton');
    if (!checkoutBtn) return;
    
    // Désactiver le bouton si le panier est vide
    const isEmpty = cartData?.isEmpty || !cartData?.items?.length;
    checkoutBtn.disabled = isEmpty;
    checkoutBtn.setAttribute('aria-disabled', isEmpty);
    
    // Mettre à jour le texte si nécessaire
    const btnText = this.i18n?.t('btn.checkout') || 'Proceed to Checkout';
    const currencySymbol = '<span class="ton-logo">TON</span>';
    
    if (cartData?.totalPrice) {
      checkoutBtn.innerHTML = `${currencySymbol} ${btnText} (${cartData.totalPrice} TON)`;
    } else {
      checkoutBtn.innerHTML = `${currencySymbol} ${btnText}`;
    }
  }

  /**
   * Démarre le processus de checkout
   */
  async startCheckout() {
    try {
      // Vérifier si le panier est vide
      if (this.cart.isEmpty()) {
        this.showError(this.i18n?.t('checkout.empty_cart') || 'Your cart is empty');
        return;
      }
      
      // Vérifier la vérification professionnelle
      if (window.verificationManager && !window.verificationManager.isVerified()) {
        this.showError(this.i18n?.t('checkout.verification_required') || 'Professional verification required');
        return;
      }
      
      // Vérifier si nous sommes dans Telegram
      if (!this.tg) {
        this.showError(this.i18n?.t('checkout.telegram_required') || 'Checkout is only available through Telegram');
        return;
      }

      // Collecte des informations de livraison
      await this.collectShippingInfo();
      
      // Afficher le récapitulatif de commande
      const confirmed = await this.showOrderSummary();
      
      if (confirmed) {
        // Traiter le paiement
        await this.processPayment();
      }
    } catch (error) {
      console.error('Checkout error:', error);
      this.showError(error.message || 'An error occurred during checkout');
    }
  }

  /**
   * Collecte les informations de livraison
   */
  async collectShippingInfo() {
    if (!this.tg || !this.tg.showPopup) {
      throw new Error('Telegram WebApp not available');
    }
    
    return new Promise((resolve, reject) => {
      // Créer des options de pays
      const countryOptions = this.availableCountries.map(country => 
        `<option value="${country.code}">${country.name}</option>`
      ).join('');
      
      // Créer des options de méthodes de livraison
      const shippingMethodOptions = this.shipping.methods.map(method => 
        `<label class="shipping-option">
          <input type="radio" name="shipping_method" value="${method.id}" 
                 ${method.id === this.shipping.selected ? 'checked' : ''}>
          <span class="option-details">
            <strong>${method.name}</strong> - ${method.price} TON
            <span class="delivery-time">${method.days} business days</span>
          </span>
        </label>`
      ).join('');
      
      // Afficher le pop-up avec formulaire HTML
      this.tg.showPopup({
        title: this.i18n?.t('checkout.shipping_info') || 'Shipping Information',
        message: `
          <form id="shipping-form">
            <div class="form-group">
              <label for="recipient_name">Recipient Name:</label>
              <input type="text" id="recipient_name" value="${this.userData?.preferredName || ''}" required>
            </div>
            
            <div class="form-group">
              <label for="country">Country:</label>
              <select id="country" required>
                ${countryOptions}
              </select>
            </div>
            
            <div class="form-group">
              <label for="address">Address:</label>
              <textarea id="address" rows="2" required placeholder="Street address, apartment, etc."></textarea>
            </div>
            
            <div class="form-row">
              <div class="form-group half">
                <label for="city">City:</label>
                <input type="text" id="city" required>
              </div>
              
              <div class="form-group half">
                <label for="postal_code">Postal Code:</label>
                <input type="text" id="postal_code" required>
              </div>
            </div>
            
            <div class="form-group">
              <label>Shipping Method:</label>
              <div class="shipping-options">
                ${shippingMethodOptions}
              </div>
            </div>
            
            <div class="form-group">
              <label for="special_instructions">Special Instructions (Optional):</label>
              <textarea id="special_instructions" rows="2" placeholder="Any special delivery requirements..."></textarea>
            </div>
          </form>
        `,
        buttons: [
          { id: 'cancel', type: 'cancel', text: this.i18n?.t('btn.cancel') || 'Cancel' },
          { id: 'continue', type: 'default', text: this.i18n?.t('btn.continue') || 'Continue' }
        ]
      }, (buttonId) => {
        if (buttonId === 'continue') {
          // Collecter les données du formulaire
          const formData = {
            recipientName: document.getElementById('recipient_name')?.value,
            country: document.getElementById('country')?.value,
            address: document.getElementById('address')?.value,
            city: document.getElementById('city')?.value,
            postalCode: document.getElementById('postal_code')?.value,
            shippingMethod: document.querySelector('input[name="shipping_method"]:checked')?.value || this.shipping.selected,
            specialInstructions: document.getElementById('special_instructions')?.value
          };
          
          // Valider les données
          const requiredFields = ['recipientName', 'country', 'address', 'city', 'postalCode'];
          const missingFields = requiredFields.filter(field => !formData[field]);
          
          if (missingFields.length > 0) {
            this.tg.showAlert(this.i18n?.t('checkout.missing_fields') || 'Please fill in all required fields');
            reject(new Error('Missing required shipping fields'));
            return;
          }
          
          // Enregistrer les données
          this.shippingInfo = formData;
          resolve(formData);
        } else {
          reject(new Error('Shipping information collection cancelled'));
        }
      });
    });
  }

  /**
   * Affiche le récapitulatif de la commande
   */
  async showOrderSummary() {
    if (!this.tg || !this.tg.showPopup) {
      throw new Error('Telegram WebApp not available');
    }
    
    // Obtenir les articles du panier
    const cartItems = this.cart.getItems();
    
    // Calculer les totaux
    const subtotal = this.cart.getTotalPrice();
    const selectedShippingMethod = this.shipping.methods.find(m => m.id === this.shippingInfo.shippingMethod);
    const shippingCost = selectedShippingMethod?.price || 0;
    const total = subtotal + shippingCost;
    
    // Formater les éléments du panier
    const itemsHtml = cartItems.map(item => 
      `<div class="summary-item">
        <span class="item-name">${item.name} × ${item.quantity}</span>
        <span class="item-price">${item.price * item.quantity} TON</span>
      </div>`
    ).join('');
    
    // Préparer l'objet commande
    this.orderData = {
      items: cartItems,
      shipping: {
        ...this.shippingInfo,
        cost: shippingCost,
        method: selectedShippingMethod?.name || 'Standard'
      },
      payment: {
        subtotal: subtotal,
        shipping: shippingCost,
        total: total,
        currency: 'TON'
      },
      orderId: this.generateOrderId(),
      date: new Date().toISOString()
    };
    
    return new Promise((resolve) => {
      // Afficher le récapitulatif
      this.tg.showPopup({
        title: this.i18n?.t('checkout.order_summary') || 'Order Summary',
        message: `
          <div class="order-summary">
            <div class="summary-section">
              <h3>Items</h3>
              ${itemsHtml}
            </div>
            
            <div class="summary-section">
              <h3>Shipping</h3>
              <p>${this.orderData.shipping.method} to ${this.orderData.shipping.country.toUpperCase()}</p>
              <p>${this.orderData.shipping.city}, ${this.orderData.shipping.address}</p>
            </div>
            
            <div class="summary-totals">
              <div class="summary-row">
                <span>Subtotal:</span>
                <span>${subtotal} TON</span>
              </div>
              <div class="summary-row">
                <span>Shipping:</span>
                <span>${shippingCost} TON</span>
              </div>
              <div class="summary-row total">
                <span>Total:</span>
                <span>${total} TON</span>
              </div>
            </div>
            
            <div class="payment-selection">
              <h3>Payment Method</h3>
              <div class="payment-methods">
                ${this.paymentMethods.map(method => 
                  `<label class="payment-method">
                    <input type="radio" name="payment_method" value="${method}" 
                           ${method === this.selectedPaymentMethod ? 'checked' : ''}>
                    <span>${method}</span>
                  </label>`
                ).join('')}
              </div>
            </div>
          </div>
        `,
        buttons: [
          { id: 'back', type: 'cancel', text: this.i18n?.t('btn.back') || 'Back' },
          { id: 'confirm', type: 'default', text: this.i18n?.t('btn.confirm_pay') || 'Confirm & Pay' }
        ]
      }, (buttonId) => {
        if (buttonId === 'confirm') {
          // Récupérer la méthode de paiement sélectionnée
          const selectedPaymentMethod = document.querySelector('input[name="payment_method"]:checked')?.value || this.selectedPaymentMethod;
          this.orderData.payment.method = selectedPaymentMethod;
          
          resolve(true);
        } else {
          resolve(false);
        }
      });
    });
  }

  /**
   * Gère le processus de paiement
   */
  async processPayment() {
    try {
      if (!this.paymentManager) {
        throw new Error('Payment manager not available');
      }
      
      // Mettre à jour l'interface utilisateur
      this.showLoadingIndicator();
      
      // Préparer les données de commande pour le paiement
      const paymentData = {
        amount: this.orderData.payment.total,
        currency: this.orderData.payment.currency,
        orderId: this.orderData.orderId,
        items: this.orderData.items.map(item => ({
          id: item.id,
          name: item.name,
          quantity: item.quantity,
          price: item.price
        }))
      };
      
      // Démarrer le processus de paiement
      const paymentResult = await this.paymentManager.initiatePayment(paymentData);
      
      if (!paymentResult || !paymentResult.success) {
        throw new Error(paymentResult?.message || 'Payment initialization failed');
      }
      
      // Ajouter un écouteur pour les mises à jour de paiement
      this.paymentManager.addPaymentListener(this.handlePaymentUpdate.bind(this));
      
      // Masquer l'indicateur de chargement
      this.hideLoadingIndicator();
      
      return paymentResult;
    } catch (error) {
      this.hideLoadingIndicator();
      console.error('Payment processing error:', error);
      
      // Afficher une erreur à l'utilisateur
      this.showError(error.message || 'Payment processing failed');
      
      throw error;
    }
  }

  /**
   * Gère les mises à jour de l'état du paiement
   */
  handlePaymentUpdate(paymentData) {
    if (!paymentData) return;
    
    // Traiter en fonction du statut
    switch (paymentData.status) {
      case 'success':
        this.handleSuccessfulPayment(paymentData);
        break;
        
      case 'failed':
        this.handleFailedPayment(paymentData);
        break;
        
      case 'expired':
        this.showError(this.i18n?.t('checkout.payment_expired') || 'Payment time expired');
        break;
        
      case 'cancelled':
        // Ne rien faire, l'utilisateur a annulé
        break;
        
      default:
        // Statut inconnu ou en cours
        break;
    }
  }

  /**
   * Gère un paiement réussi
   */
  handleSuccessfulPayment(paymentData) {
    // Vider le panier
    if (this.cart && typeof this.cart.clearItems === 'function') {
      this.cart.clearItems();
    }
    
    // Fermer l'interface de paiement si elle est ouverte
    if (this.paymentManager.closePaymentUI) {
      this.paymentManager.closePaymentUI();
    }
    
    // Afficher un message de confirmation
    if (this.tg && this.tg.showPopup) {
      this.tg.showPopup({
        title: this.i18n?.t('checkout.order_confirmed') || 'Order Confirmed!',
        message: `
          <div class="order-confirmation">
            <div class="confirmation-icon">✅</div>
            <h3>Thank You for Your Order</h3>
            <p>Order #: ${this.orderData.orderId}</p>
            <p>Amount: ${this.orderData.payment.total} ${this.orderData.payment.currency}</p>
            <p>A confirmation has been sent to your Telegram account.</p>
            
            <div class="shipping-info">
              <h4>Shipping Information</h4>
              <p>Your order will be shipped via ${this.orderData.shipping.method} within 24 hours.</p>
              <p>Estimated delivery: ${this.shipping.methods.find(m => m.id === this.shippingInfo.shippingMethod)?.days || '5-7'} business days</p>
            </div>
          </div>
        `,
        buttons: [
          { type: 'ok', text: this.i18n?.t('btn.ok') || 'OK' }
        ]
      });
    }
    
    // Envoyer les données au bot Telegram
    if (this.tg && this.tg.sendData) {
      this.tg.sendData(JSON.stringify({
        action: 'order_completed',
        order: {
          ...this.orderData,
          payment: {
            ...this.orderData.payment,
            status: 'completed',
            txHash: paymentData.txHash,
            completedAt: new Date().toISOString()
          }
        }
      }));
    }
    
    // Déclencher un événement de commande terminée
    window.dispatchEvent(new CustomEvent('orderCompleted', {
      detail: {
        order: this.orderData,
        payment: paymentData
      }
    }));
  }

  /**
   * Gère un paiement échoué
   */
  handleFailedPayment(paymentData) {
    // Afficher un message d'erreur
    this.showError(
      this.i18n?.t('checkout.payment_failed') || 
      'Payment failed. Please try again or contact support.'
    );
    
    // Enregistrer les détails de l'échec
    console.error('Payment failed:', paymentData);
    
    // Envoyer les données d'échec au bot si nécessaire
    if (this.tg && this.tg.sendData) {
      this.tg.sendData(JSON.stringify({
        action: 'payment_failed',
        order: this.orderData,
        error: {
          reason: paymentData.reason || 'unknown',
          timestamp: new Date().toISOString()
        }
      }));
    }
  }

  /**
   * Génère un identifiant de commande unique
   */
  generateOrderId() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `THP-${timestamp}-${random}`;
  }

  /**
   * Affiche un indicateur de chargement
   */
  showLoadingIndicator() {
    // Créer un élément de chargement s'il n'existe pas
    let loadingOverlay = document.getElementById('checkout-loading');
    
    if (!loadingOverlay) {
      loadingOverlay = document.createElement('div');
      loadingOverlay.id = 'checkout-loading';
      loadingOverlay.className = 'loading-overlay';
      loadingOverlay.innerHTML = `
        <div class="loading-spinner"></div>
        <p class="loading-text">${this.i18n?.t('checkout.processing') || 'Processing payment...'}</p>
      `;
      
      document.body.appendChild(loadingOverlay);
    }
    
    // Afficher l'élément
    loadingOverlay.style.display = 'flex';
    
    // Désactiver les interactions
    document.body.style.overflow = 'hidden';
  }

  /**
   * Cache l'indicateur de chargement
   */
  hideLoadingIndicator() {
    const loadingOverlay = document.getElementById('checkout-loading');
    
    if (loadingOverlay) {
      loadingOverlay.style.display = 'none';
      document.body.style.overflow = '';
    }
  }

  /**
   * Affiche un message d'erreur
   */
  showError(message) {
    if (this.tg && this.tg.showAlert) {
      this.tg.showAlert(message);
    } else {
      alert(message);
    }
  }
}

// Initialiser le gestionnaire de checkout quand le DOM est chargé
document.addEventListener('DOMContentLoaded', () => {
  window.checkoutManager = new CheckoutManager();
});

// Exporter pour utilisation dans d'autres modules
export default CheckoutManager;
