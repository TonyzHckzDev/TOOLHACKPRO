// scripts/theme-manager.js

/**
 * Gestionnaire de thèmes
 * Gère les thèmes clair/sombre, l'intégration Telegram et les préférences utilisateur
 */

import { STORAGE_KEYS } from '../app/config/constants.js';
import { trackEvent } from '../app/services/analytics.js';
import { showNotification } from '../app/utils/ui-manager.js';
import { translate } from '../app/utils/i18n.js';

// Configuration des thèmes
const THEMES = {
  LIGHT: 'light-theme',
  DARK: 'dark-theme',
  SYSTEM: 'system-theme',
  TELEGRAM: 'telegram-theme',
  HIGH_CONTRAST: 'high-contrast-theme',
  CUSTOM: 'custom-theme'
};

// État du gestionnaire de thèmes
const themeState = {
  currentTheme: null,
  preferredTheme: null,
  userSelectedTheme: null,
  systemPrefersDark: false,
  telegramTheme: null,
  isInitialized: false,
  customColors: null,
  transitionDuration: 400, // ms
  observingSystem: false,
  autoSyncWithSystem: true,
  themeChangeListeners: [],
  isChangingTheme: false,
  lastChangeTime: 0,
  forcedTheme: null
};

/**
 * Initialise le gestionnaire de thèmes
 * @param {Object} [options={}] - Options de configuration
 * @returns {Promise<string>} - Le thème appliqué
 */
export async function initThemeManager(options = {}) {
  if (themeState.isInitialized) {
    return themeState.currentTheme;
  }
  
  console.log('Initializing theme manager');
  
  // Fusionner les options
  const defaultOptions = {
    defaultTheme: THEMES.DARK,
    autoSyncWithSystem: true,
    transitionDuration: 400,
    detectTelegramTheme: true,
    savePreference: true
  };
  
  const config = { ...defaultOptions, ...options };
  
  // Appliquer les options
  themeState.autoSyncWithSystem = config.autoSyncWithSystem;
  themeState.transitionDuration = config.transitionDuration;
  
  // Détecter les préférences système
  detectSystemThemePreference();
  
  // Détecter le thème Telegram si activé
  if (config.detectTelegramTheme) {
    detectTelegramTheme();
  }
  
  // Lire les préférences sauvegardées
  if (config.savePreference) {
    themeState.userSelectedTheme = getSavedThemePreference();
  }
  
  // Déterminer le thème initial
  let initialTheme;
  
  if (themeState.telegramTheme && config.detectTelegramTheme) {
    // Priorité au thème Telegram si l'app est dans Telegram
    initialTheme = THEMES.TELEGRAM;
  } else if (themeState.userSelectedTheme) {
    // Ensuite, priorité au choix utilisateur sauvegardé
    initialTheme = themeState.userSelectedTheme;
  } else if (themeState.autoSyncWithSystem) {
    // Ensuite, synchronisation avec les préférences système
    initialTheme = themeState.systemPrefersDark ? THEMES.DARK : THEMES.LIGHT;
  } else {
    // Enfin, thème par défaut
    initialTheme = config.defaultTheme;
  }
  
  // Configurer l'observateur de préférences système
  setupSystemPreferenceObserver();
  
  // Configurer les écouteurs d'événements
  setupEventListeners();
  
  // Appliquer le thème initial
  await applyTheme(initialTheme);
  
  themeState.isInitialized = true;
  
  return themeState.currentTheme;
}

/**
 * Détecte les préférences de thème du système
 */
function detectSystemThemePreference() {
  if (window.matchMedia) {
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    themeState.systemPrefersDark = prefersDarkScheme.matches;
  } else {
    // Fallback si matchMedia n'est pas supporté
    themeState.systemPrefersDark = false;
  }
}

/**
 * Configure l'observateur des préférences système
 */
function setupSystemPreferenceObserver() {
  if (window.matchMedia && !themeState.observingSystem) {
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    
    // Méthode moderne avec addEventListener pour compatibilité
    if (prefersDarkScheme.addEventListener) {
      prefersDarkScheme.addEventListener('change', handleSystemThemeChange);
    } else if (prefersDarkScheme.addListener) {
      // Fallback pour anciens navigateurs
      prefersDarkScheme.addListener(handleSystemThemeChange);
    }
    
    themeState.observingSystem = true;
  }
}

/**
 * Gère les changements de préférences système
 * @param {MediaQueryListEvent} event - Événement de changement
 */
function handleSystemThemeChange(event) {
  themeState.systemPrefersDark = event.matches;
  
  // Synchroniser avec les préférences système si activé et si le thème actuel est synchronisé
  if (themeState.autoSyncWithSystem && 
      (themeState.currentTheme === THEMES.LIGHT || themeState.currentTheme === THEMES.DARK) && 
      !themeState.userSelectedTheme) {
    const newTheme = event.matches ? THEMES.DARK : THEMES.LIGHT;
    applyTheme(newTheme);
    
    // Notifier du changement automatique
    showNotification(
      translate('theme.system_change_notification', {
        theme: translate(event.matches ? 'theme.dark' : 'theme.light')
      }),
      'info'
    );
  }
}

/**
 * Détecte le thème de Telegram WebApp
 */
function detectTelegramTheme() {
  const telegramWebApp = window.Telegram && window.Telegram.WebApp;
  
  if (telegramWebApp) {
    // Stocker les couleurs et la liste des paramètres
    themeState.telegramTheme = {
      bgColor: telegramWebApp.themeParams.bg_color || null,
      textColor: telegramWebApp.themeParams.text_color || null,
      hintColor: telegramWebApp.themeParams.hint_color || null,
      linkColor: telegramWebApp.themeParams.link_color || null,
      buttonColor: telegramWebApp.themeParams.button_color || null,
      buttonTextColor: telegramWebApp.themeParams.button_text_color || null,
      isDark: telegramWebApp.themeParams.bg_color 
              ? isColorDark(telegramWebApp.themeParams.bg_color) 
              : telegramWebApp.colorScheme === 'dark'
    };
    
    // Ajouter la classe de signalisation Telegram au HTML
    document.documentElement.classList.add('telegram-webapp');
    document.body.classList.add('telegram-webapp');
    
    // Observer les changements de thème dans Telegram
    if (telegramWebApp.onEvent) {
      telegramWebApp.onEvent('themeChanged', function() {
        updateTelegramTheme();
      });
    }
    
    console.log('Telegram WebApp theme detected:', 
      telegramWebApp.colorScheme || 'unknown', 
      themeState.telegramTheme.isDark ? '(dark)' : '(light)'
    );
  } else {
    themeState.telegramTheme = null;
  }
}

/**
 * Met à jour le thème Telegram suite à un changement dans l'application
 */
function updateTelegramTheme() {
  const telegramWebApp = window.Telegram && window.Telegram.WebApp;
  
  if (telegramWebApp) {
    // Mettre à jour les variables stockées
    themeState.telegramTheme = {
      bgColor: telegramWebApp.themeParams.bg_color || null,
      textColor: telegramWebApp.themeParams.text_color || null,
      hintColor: telegramWebApp.themeParams.hint_color || null,
      linkColor: telegramWebApp.themeParams.link_color || null,
      buttonColor: telegramWebApp.themeParams.button_color || null,
      buttonTextColor: telegramWebApp.themeParams.button_text_color || null,
      isDark: telegramWebApp.themeParams.bg_color 
              ? isColorDark(telegramWebApp.themeParams.bg_color) 
              : telegramWebApp.colorScheme === 'dark'
    };
    
    // Appliquer les mises à jour CSS si le thème actuel est Telegram
    if (themeState.currentTheme === THEMES.TELEGRAM) {
      applyTelegramThemeVariables();
    }
  }
}

/**
 * Applique les variables CSS du thème Telegram
 */
function applyTelegramThemeVariables() {
  if (!themeState.telegramTheme) return;
  
  const telegramStyles = document.getElementById('tg-webapp-styles');
  if (telegramStyles) {
    // Mettre à jour les styles directement dans la balise dédiée
    const tg = themeState.telegramTheme;
    
    let cssText = `
      body {
        background-color: var(--tg-theme-bg-color, ${tg.bgColor || '#1C1C1E'});
        color: var(--tg-theme-text-color, ${tg.textColor || '#FFFFFF'});
      }
      
      .tg-main-button {
        background-color: var(--tg-theme-button-color, ${tg.buttonColor || '#2481cc'});
        color: var(--tg-theme-button-text-color, ${tg.buttonTextColor || '#FFFFFF'});
      }
      
      a {
        color: var(--tg-theme-link-color, ${tg.linkColor || '#2481cc'});
      }
      
      @supports (padding: max(0px)) {
        body {
          padding-bottom: max(16px, env(safe-area-inset-bottom));
          padding-top: max(16px, env(safe-area-inset-top));
          padding-left: max(16px, env(safe-area-inset-left));
          padding-right: max(16px, env(safe-area-inset-right));
        }
      }
      
      body {
        -ms-overflow-style: none;
        scrollbar-width: none;
      }
      
      body::-webkit-scrollbar {
        display: none;
      }
      
      @media (hover: none) {
        .hover-effect:hover {
          transform: none !important;
          box-shadow: none !important;
        }
      }
    `;
    
    telegramStyles.textContent = cssText;
  }
}

/**
 * Détermine si une couleur est sombre
 * @param {string} color - Couleur au format hex ou rgba
 * @returns {boolean} - Vrai si la couleur est sombre
 */
function isColorDark(color) {
  let r, g, b;
  
  // Gestion des formats de couleur
  if (color.startsWith('#')) {
    // Format hexadécimal
    const hex = color.substring(1);
    if (hex.length === 3) {
      r = parseInt(hex.charAt(0) + hex.charAt(0), 16);
      g = parseInt(hex.charAt(1) + hex.charAt(1), 16);
      b = parseInt(hex.charAt(2) + hex.charAt(2), 16);
    } else {
      r = parseInt(hex.substring(0, 2), 16);
      g = parseInt(hex.substring(2, 4), 16);
      b = parseInt(hex.substring(4, 6), 16);
    }
  } else if (color.startsWith('rgb')) {
    // Format RGB(A)
    const values = color.match(/(\d+)/g);
    if (values && values.length >= 3) {
      r = parseInt(values[0], 10);
      g = parseInt(values[1], 10);
      b = parseInt(values[2], 10);
    } else {
      return false;
    }
  } else {
    return false;
  }
  
  // Calcul de la luminance relative (formule YIQ)
  // Valeur plus faible = plus sombre
  const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
  
  // Seuil standard: moins de 128 est considéré comme sombre
  return yiq < 128;
}

/**
 * Configure les écouteurs d'événements
 */
function setupEventListeners() {
  // Écouteur pour le bouton de basculement de thème
  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      // Simple basculement entre thèmes clair et sombre
      const newTheme = themeState.currentTheme === THEMES.DARK ? THEMES.LIGHT : THEMES.DARK;
      setTheme(newTheme);
    });
  }
  
  // Détection des changements de couleur automatiques dans iOS/Safari
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && themeState.autoSyncWithSystem) {
      detectSystemThemePreference();
      if ((themeState.currentTheme === THEMES.LIGHT && themeState.systemPrefersDark) ||
          (themeState.currentTheme === THEMES.DARK && !themeState.systemPrefersDark)) {
        // Mettre à jour le thème seulement si le mode système a changé
        const newTheme = themeState.systemPrefersDark ? THEMES.DARK : THEMES.LIGHT;
        applyTheme(newTheme);
      }
    }
  });
}

/**
 * Récupère la préférence de thème sauvegardée
 * @returns {string|null} - Le thème sauvegardé ou null
 */
function getSavedThemePreference() {
  try {
    return localStorage.getItem(STORAGE_KEYS.THEME_PREFERENCE);
  } catch (error) {
    console.warn('Error reading theme preference:', error);
    return null;
  }
}

/**
 * Sauvegarde la préférence de thème
 * @param {string} theme - Le thème à sauvegarder
 */
function saveThemePreference(theme) {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME_PREFERENCE, theme);
  } catch (error) {
    console.warn('Error saving theme preference:', error);
  }
}

/**
 * Définit le thème de l'application
 * @param {string} theme - Thème à appliquer
 * @param {boolean} [savePreference=true] - Sauvegarder la préférence ou non
 * @returns {Promise<boolean>} - Succès de l'opération
 */
export async function setTheme(theme, savePreference = true) {
  if (!theme || themeState.isChangingTheme) {
    return false;
  }
  
  // Valider le thème
  if (!Object.values(THEMES).includes(theme)) {
    console.warn('Invalid theme:', theme);
    return false;
  }
  
  try {
    // Appliquer le thème
    await applyTheme(theme);
    
    // Sauvegarder la préférence si demandé
    if (savePreference) {
      themeState.userSelectedTheme = theme;
      saveThemePreference(theme);
      
      // Tracking analytique
      trackEvent('theme_changed', {
        theme: theme,
        source: 'user_preference'
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error applying theme:', error);
    return false;
  }
}

/**
 * Applique le thème spécifié
 * @param {string} theme - Thème à appliquer
 * @returns {Promise<boolean>} - Succès de l'opération
 */
async function applyTheme(theme) {
  // Éviter les changements multiples simultanés
  if (themeState.isChangingTheme) {
    return false;
  }
  
  themeState.isChangingTheme = true;
  
  try {
    // Si aucun changement, ne rien faire
    if (theme === themeState.currentTheme) {
      themeState.isChangingTheme = false;
      return true;
    }
    
    // Stocker l'ancien thème pour référence
    const oldTheme = themeState.currentTheme;
    
    // Selon le thème choisi
    switch (theme) {
      case THEMES.LIGHT:
        updateClassList(THEMES.LIGHT);
        updateIconsForTheme('light');
        break;
        
      case THEMES.DARK:
        updateClassList(THEMES.DARK);
        updateIconsForTheme('dark');
        break;
        
      case THEMES.SYSTEM:
        const systemTheme = themeState.systemPrefersDark ? THEMES.DARK : THEMES.LIGHT;
        updateClassList(systemTheme);
        updateIconsForTheme(themeState.systemPrefersDark ? 'dark' : 'light');
        break;
        
      case THEMES.TELEGRAM:
        if (themeState.telegramTheme) {
          updateClassList(themeState.telegramTheme.isDark ? THEMES.DARK : THEMES.LIGHT);
          updateClassList(THEMES.TELEGRAM, false); // Ajouter sans supprimer les autres
          applyTelegramThemeVariables();
          updateIconsForTheme(themeState.telegramTheme.isDark ? 'dark' : 'light');
        } else {
          // Fallback si pas de thème Telegram
          updateClassList(THEMES.DARK);
          updateIconsForTheme('dark');
        }
        break;
        
      case THEMES.HIGH_CONTRAST:
        updateClassList(THEMES.HIGH_CONTRAST);
        updateIconsForTheme('high-contrast');
        break;
        
      case THEMES.CUSTOM:
        if (themeState.customColors) {
          updateClassList(THEMES.CUSTOM);
          applyCustomThemeColors();
          updateIconsForTheme('custom');
        } else {
          // Fallback si pas de couleurs personnalisées
          updateClassList(THEMES.DARK);
          updateIconsForTheme('dark');
        }
        break;
        
      default:
        // Thème par défaut
        updateClassList(THEMES.DARK);
        updateIconsForTheme('dark');
        break;
    }
    
    // Mettre à jour l'état
    themeState.currentTheme = theme;
    themeState.lastChangeTime = Date.now();
    
    // Mettre à jour la meta tag pour le thème
    updateThemeMetaTag(theme);
    
    // Notifier les écouteurs de changement de thème
    notifyThemeChangeListeners(theme, oldTheme);
    
    return true;
  } catch (error) {
    console.error('Error during theme application:', error);
    return false;
  } finally {
    // Réinitialiser le flag après un délai pour la transition
    setTimeout(() => {
      themeState.isChangingTheme = false;
    }, themeState.transitionDuration);
  }
}

/**
 * Met à jour les classes CSS pour le thème
 * @param {string} theme - Thème à appliquer
 * @param {boolean} [removeOthers=true] - Supprimer les autres classes de thème
 */
function updateClassList(theme, removeOthers = true) {
  // Appliquer au HTML et au BODY pour une couverture complète
  [document.documentElement, document.body].forEach(element => {
    // Appliquer une transition initiale si nécessaire
    if (!element.style.transition) {
      element.style.transition = `background-color ${themeState.transitionDuration}ms ease, color ${themeState.transitionDuration}ms ease`;
    }
    
    // Supprimer les classes existantes si demandé
    if (removeOthers) {
      Object.values(THEMES).forEach(t => {
        if (t !== THEMES.TELEGRAM) { // Garder la classe Telegram pour les fonctionnalités WebApp
          element.classList.remove(t);
        }
      });
    }
    
    // Ajouter la nouvelle classe
    element.classList.add(theme);
  });
}

/**
 * Met à jour les icônes pour le thème actuel
 * @param {string} themeType - Type de thème (light, dark, high-contrast, custom)
 */
function updateIconsForTheme(themeType) {
  // Mettre à jour l'icône du bouton de thème
  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    const icon = themeToggle.querySelector('i') || themeToggle;
    
    if (icon.classList.contains('fa') || icon.classList.contains('fas')) {
      // Supprimer les classes d'icônes existantes
      icon.className = '';
      icon.classList.add('fas');
      
      // Ajouter la classe appropriée selon le thème
      switch (themeType) {
        case 'light':
          icon.classList.add('fa-moon'); // Montrer la lune en mode clair
          break;
        case 'dark':
          icon.classList.add('fa-sun'); // Montrer le soleil en mode sombre
          break;
        case 'high-contrast':
          icon.classList.add('fa-adjust'); // Icône de contraste
          break;
        case 'custom':
          icon.classList.add('fa-palette'); // Icône de palette
          break;
        default:
          icon.classList.add('fa-moon');
      }
    }
  }
}

/**
 * Applique les couleurs personnalisées du thème
 */
function applyCustomThemeColors() {
  if (!themeState.customColors) return;
  
  // Créer ou mettre à jour la feuille de style pour les couleurs personnalisées
  let customStylesheet = document.getElementById('custom-theme-colors');
  
  if (!customStylesheet) {
    customStylesheet = document.createElement('style');
    customStylesheet.id = 'custom-theme-colors';
    document.head.appendChild(customStylesheet);
  }
  
  // Générer les variables CSS pour les couleurs personnalisées
  const colors = themeState.customColors;
  const cssVars = [];
  
  for (const [key, value] of Object.entries(colors)) {
    if (value) {
      cssVars.push(`--color-${key}: ${value};`);
    }
  }
  
  // Créer le contenu CSS
  const css = `
    .custom-theme {
      ${cssVars.join('\n      ')}
    }
  `;
  
  customStylesheet.textContent = css;
}

/**
 * Met à jour la meta tag pour le thème
 * @param {string} theme - Thème actuel
 */
function updateThemeMetaTag(theme) {
  let metaThemeColor = document.querySelector('meta[name="theme-color"]');
  
  if (!metaThemeColor) {
    metaThemeColor = document.createElement('meta');
    metaThemeColor.name = 'theme-color';
    document.head.appendChild(metaThemeColor);
  }
  
  // Définir la couleur appropriée selon le thème
  let color;
  
  switch (theme) {
    case THEMES.LIGHT:
      color = '#f2f2f7';
      break;
    case THEMES.DARK:
      color = '#1C1C1E';
      break;
    case THEMES.TELEGRAM:
      color = themeState.telegramTheme && themeState.telegramTheme.bgColor
        ? themeState.telegramTheme.bgColor
        : '#1C1C1E';
      break;
    case THEMES.HIGH_CONTRAST:
      color = '#000000';
      break;
    case THEMES.CUSTOM:
      color = themeState.customColors && themeState.customColors.bg_primary
        ? themeState.customColors.bg_primary
        : '#1C1C1E';
      break;
    default:
      color = '#1C1C1E';
  }
  
  metaThemeColor.content = color;
}

/**
 * Définit des couleurs personnalisées pour le thème
 * @param {Object} colors - Objet contenant les couleurs
 * @returns {boolean} - Succès de l'opération
 */
export function setCustomThemeColors(colors) {
  if (!colors || typeof colors !== 'object') {
    return false;
  }
  
  themeState.customColors = { ...colors };
  
  // Si le thème actuel est personnalisé, appliquer immédiatement
  if (themeState.currentTheme === THEMES.CUSTOM) {
    applyCustomThemeColors();
  }
  
  return true;
}

/**
 * Bascule le thème entre clair et sombre
 * @returns {Promise<string>} - Le nouveau thème
 */
export async function toggleTheme() {
  const newTheme = themeState.currentTheme === THEMES.DARK ? THEMES.LIGHT : THEMES.DARK;
  await setTheme(newTheme);
  return newTheme;
}

/**
 * Force un thème spécifique temporairement
 * @param {string} theme - Thème à forcer
 * @param {boolean} [persistent=false] - Thème persistant ou temporaire
 * @returns {Promise<boolean>} - Succès de l'opération
 */
export async function forceTheme(theme, persistent = false) {
  if (!theme || !Object.values(THEMES).includes(theme)) {
    return false;
  }
  
  // Sauvegarder le thème actuel si c'est temporaire
  if (!persistent) {
    themeState.forcedTheme = themeState.currentTheme;
  }
  
  // Appliquer le thème forcé
  await applyTheme(theme);
  
  return true;
}

/**
 * Restaure le thème précédent après un forçage
 * @returns {Promise<boolean>} - Succès de l'opération
 */
export async function restorePreviousTheme() {
  if (!themeState.forcedTheme) {
    return false;
  }
  
  const previousTheme = themeState.forcedTheme;
  themeState.forcedTheme = null;
  
  await applyTheme(previousTheme);
  
  return true;
}

/**
 * Active ou désactive la synchronisation automatique avec le thème système
 * @param {boolean} enable - Activer ou désactiver
 */
export function setSyncWithSystem(enable) {
  themeState.autoSyncWithSystem = enable;
  
  // Si on active la synchronisation, mettre à jour immédiatement
  if (enable) {
    detectSystemThemePreference();
    const systemTheme = themeState.systemPrefersDark ? THEMES.DARK : THEMES.LIGHT;
    
    // Mettre à jour seulement si le thème actuel est différent
    if ((themeState.currentTheme === THEMES.LIGHT && themeState.systemPrefersDark) ||
        (themeState.currentTheme === THEMES.DARK && !themeState.systemPrefersDark)) {
      applyTheme(systemTheme);
    }
  }
  
  // Sauvegarder la préférence
  try {
    localStorage.setItem(STORAGE_KEYS.SYNC_THEME_WITH_SYSTEM, enable.toString());
  } catch (error) {
    console.warn('Error saving system sync preference:', error);
  }
  
  return true;
}

/**
 * Ajoute un écouteur de changement de thème
 * @param {Function} listener - Fonction de rappel
 * @returns {string} - Identifiant de l'écouteur
 */
export function addThemeChangeListener(listener) {
  if (typeof listener !== 'function') {
    throw new Error('Theme change listener must be a function');
  }
  
  const id = Math.random().toString(36).substring(2, 10);
  themeState.themeChangeListeners.push({ id, callback: listener });
  
  return id;
}

/**
 * Supprime un écouteur de changement de thème
 * @param {string} id - Identifiant de l'écouteur
 * @returns {boolean} - Succès de l'opération
 */
export function removeThemeChangeListener(id) {
  const initialLength = themeState.themeChangeListeners.length;
  themeState.themeChangeListeners = themeState.themeChangeListeners.filter(
    listener => listener.id !== id
  );
  
  return themeState.themeChangeListeners.length < initialLength;
}

/**
 * Notifie les écouteurs d'un changement de thème
 * @param {string} newTheme - Nouveau thème
 * @param {string} oldTheme - Ancien thème
 */
function notifyThemeChangeListeners(newTheme, oldTheme) {
  const eventData = {
    oldTheme,
    newTheme,
    timestamp: Date.now(),
    systemPreference: themeState.systemPrefersDark ? 'dark' : 'light'
  };
  
    // Appeler tous les écouteurs enregistrés
  themeState.themeChangeListeners.forEach(({ callback }) => {
    try {
      callback(eventData);
    } catch (error) {
      console.error('Error in theme change listener:', error);
    }
  });
  
  // Déclencher également un événement DOM pour l'interopérabilité
  document.dispatchEvent(new CustomEvent('themechange', {
    detail: eventData
  }));
}

/**
 * Obtient le thème actuel
 * @returns {string} - Thème actuel
 */
export function getCurrentTheme() {
  return themeState.currentTheme;
}

/**
 * Vérifie si le thème actuel est sombre
 * @returns {boolean} - Vrai si le thème est sombre
 */
export function isDarkTheme() {
  if (themeState.currentTheme === THEMES.DARK) {
    return true;
  }
  
  if (themeState.currentTheme === THEMES.TELEGRAM && themeState.telegramTheme) {
    return themeState.telegramTheme.isDark;
  }
  
  if (themeState.currentTheme === THEMES.SYSTEM) {
    return themeState.systemPrefersDark;
  }
  
  if (themeState.currentTheme === THEMES.HIGH_CONTRAST) {
    return true;
  }
  
  return false;
}

/**
 * Obtient des informations sur le thème actuel
 * @returns {Object} - Informations sur le thème
 */
export function getThemeInfo() {
  return {
    currentTheme: themeState.currentTheme,
    userPreference: themeState.userSelectedTheme,
    systemPreference: themeState.systemPrefersDark ? 'dark' : 'light',
    syncWithSystem: themeState.autoSyncWithSystem,
    isDark: isDarkTheme(),
    telegramTheme: themeState.telegramTheme,
    lastChanged: themeState.lastChangeTime,
    forcedTheme: themeState.forcedTheme
  };
}

/**
 * Exporte les thèmes disponibles
 */
export const AVAILABLE_THEMES = { ...THEMES };

// Initialiser automatiquement lors de l'importation si document est disponible
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      initThemeManager();
    });
  } else {
    initThemeManager();
  }
}

// Exporter les fonctions principales
export default {
  initThemeManager,
  setTheme,
  toggleTheme,
  getCurrentTheme,
  isDarkTheme,
  getThemeInfo,
  setCustomThemeColors,
  forceTheme,
  restorePreviousTheme,
  setSyncWithSystem,
  addThemeChangeListener,
  removeThemeChangeListener,
  THEMES: AVAILABLE_THEMES
};
