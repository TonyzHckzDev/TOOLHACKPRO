// scripts/product-details.js - Gestion des détails produits et des modales

/**
 * Gestionnaire de détails produits pour ToolHack Pro
 * Affiche les informations détaillées des produits dans une modale
 */
class ProductDetailsManager {
  constructor() {
    this.activeProduct = null;
    this.modalContainer = null;
    this.isModalOpen = false;
    
    // Créer le conteneur modal s'il n'existe pas
    this.createModalContainer();
    
    // Configurer les écouteurs d'événements
    this.setupEventListeners();
  }
  
  /**
   * Crée le conteneur de modal s'il n'existe pas
   */
  createModalContainer() {
    // Vérifier si le conteneur existe déjà
    let container = document.getElementById('product-details-modal');
    
    if (!container) {
      container = document.createElement('div');
      container.id = 'product-details-modal';
      container.className = 'product-modal';
      container.setAttribute('role', 'dialog');
      container.setAttribute('aria-modal', 'true');
      container.setAttribute('aria-labelledby', 'modal-title');
      container.setAttribute('hidden', '');
      
      container.innerHTML = `
        <div class="modal-content">
          <button class="modal-close" aria-label="Fermer" id="modal-close">&times;</button>
          <div class="modal-body"></div>
        </div>
      `;
      
      document.body.appendChild(container);
    }
    
    this.modalContainer = container;
  }
  
  /**
   * Configure les écouteurs d'événements
   */
  setupEventListeners() {
    // Écouteur pour les boutons de détails des produits
    document.addEventListener('click', (event) => {
      const detailsButton = event.target.closest('[data-view-details]');
      
      if (detailsButton) {
        const productId = detailsButton.getAttribute('data-view-details');
        this.showProductDetails(productId);
      }
    });
    
    // Écouteurs pour la fermeture de la modale
    document.getElementById('modal-close')?.addEventListener('click', () => {
      this.closeModal();
    });
    
    this.modalContainer.addEventListener('click', (event) => {
      if (event.target === this.modalContainer) {
        this.closeModal();
      }
    });
    
    // Écouteur pour la touche Échap
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && this.isModalOpen) {
        this.closeModal();
      }
    });
  }
  
  /**
   * Affiche les détails d'un produit
   */
  async showProductDetails(productId) {
    try {
      // Obtenir les données du produit
      const product = this.findProductById(productId);
      
      if (!product) {
        console.error(`Product not found: ${productId}`);
        return;
      }
      
      this.activeProduct = product;
      
      // Préparer le contenu de la modale
      const modalBody = this.modalContainer.querySelector('.modal-body');
      
      // Créer la structure HTML pour les détails du produit
      modalBody.innerHTML = `
        <div class="product-details">
          <div class="product-details-image">
            <img src="${product.image}" alt="${product.name}" loading="lazy">
          </div>
          <div class="product-details-info">
            <h2 id="modal-title">${product.name}</h2>
            <div class="product-details-meta">
              <span class="product-rating">
                ${this.generateStars(product.rating)} <span class="rating-value">${product.rating}/5</span>
              </span>
              <span class="product-stock ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}">
                ${product.stock > 0 ? window.i18n?.t('product.in_stock') || 'In Stock' : window.i18n?.t('product.out_of_stock') || 'Out of Stock'}
              </span>
            </div>
            <p class="product-details-price">${product.price} TON</p>
            <p class="product-details-description">${product.description}</p>
            
            ${this.renderSpecifications(product)}
            
            <div class="product-details-actions">
              <button class="tg-button" data-add-to-cart="${product.id}" ${product.stock <= 0 ? 'disabled' : ''}>
                <span class="btn-icon">🛒</span> ${window.i18n?.t('btn.add_cart') || 'Add to Cart'}
              </button>
            </div>
          </div>
        </div>
      `;
      
      // Ajouter un gestionnaire de clic pour l'ajout au panier
      const addToCartBtn = modalBody.querySelector('[data-add-to-cart]');
      addToCartBtn?.addEventListener('click', () => {
        if (window.cart && typeof window.cart.addItem === 'function') {
          window.cart.addItem(product);
          
          // Notification de succès
          this.showNotification(
            window.i18n?.t('cart.added.title') || 'Added to Cart',
            `${product.name} ${window.i18n?.t('cart.added.message') || 'has been added to your cart.'}`
          );
          
          // Fermer la modale après ajout
          this.closeModal();
        }
      });
      
      // Ouvrir la modale
      this.openModal();
      
    } catch (error) {
      console.error('Error showing product details:', error);
    }
  }
  
  /**
   * Génère la représentation HTML des étoiles pour une note
   */
  generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    
    let starsHTML = '';
    
    // Étoiles pleines
    for (let i = 0; i < fullStars; i++) {
      starsHTML += '<span class="star full">★</span>';
    }
    
    // Demi-étoile si nécessaire
    if (hasHalfStar) {
      starsHTML += '<span class="star half">★</span>';
    }
    
    // Étoiles vides
    for (let i = 0; i < emptyStars; i++) {
      starsHTML += '<span class="star empty">☆</span>';
    }
    
    return starsHTML;
  }
  
  /**
   * Rend les spécifications du produit en HTML
   */
  renderSpecifications(product) {
    if (!product.specifications || product.specifications.length === 0) {
      return '';
    }
    
    let specsHTML = `
      <div class="product-details-specs">
        <h3>${window.i18n?.t('product.specs') || 'Specifications'}</h3>
        <ul class="specs-list">
    `;
    
    product.specifications.forEach(spec => {
      specsHTML += `<li>${spec}</li>`;
    });
    
    specsHTML += `
        </ul>
      </div>
    `;
    
    return specsHTML;
  }
  
  /**
   * Ouvre la modale
   */
  openModal() {
    this.modalContainer.removeAttribute('hidden');
    document.body.style.overflow = 'hidden'; // Empêcher le défilement
    this.isModalOpen = true;
    
    // Focus sur le bouton de fermeture pour l'accessibilité
    setTimeout(() => {
      this.modalContainer.querySelector('#modal-close').focus();
    }, 100);
  }
  
  /**
   * Ferme la modale
   */
  closeModal() {
    this.modalContainer.setAttribute('hidden', '');
    document.body.style.overflow = ''; // Rétablir le défilement
    this.isModalOpen = false;
  }
  
  /**
   * Affiche une notification temporaire
   */
  showNotification(title, message, duration = 3000) {
    // Vérifier si une notification existe déjà
    let notification = document.querySelector('.notification');
    
    // Créer la notification si elle n'existe pas
    if (!notification) {
      notification = document.createElement('div');
      notification.className = 'notification';
      document.body.appendChild(notification);
    }
    
    // Mettre à jour le contenu
    notification.innerHTML = `
      <div class="notification-content">
        <h4>${title}</h4>
        <p>${message}</p>
      </div>
    `;
    
    // Afficher la notification
    notification.classList.add('show');
    
    // Masquer après la durée spécifiée
    setTimeout(() => {
      notification.classList.remove('show');
    }, duration);
  }
  
  /**
   * Trouve un produit par son ID
   */
  findProductById(productId) {
    // Si le gestionnaire de produits est disponible
    if (window.productManager && typeof window.productManager.getProductById === 'function') {
      return window.productManager.getProductById(productId);
    }
    
    // Fallback: chercher dans les données du document
    const productElement = document.getElementById(productId);
    if (!productElement) return null;
    
    // Extraire les données du DOM
    return {
      id: productId,
      name: productElement.querySelector('h3')?.textContent || '',
      description: productElement.querySelector('[itemprop="description"]')?.textContent || '',
      price: parseFloat(productElement.querySelector('[itemprop="price"]')?.content || '0'),
      image: productElement.querySelector('[itemprop="image"] [itemprop="url"]')?.getAttribute('data-src') || '',
      stock: productElement.querySelector('.in-stock') ? 10 : 0,
      rating: parseFloat(productElement.querySelector('.product-rating')?.getAttribute('aria-label')?.split('/')[0] || '0'),
      specifications: []
    };
  }
}

// Initialiser le gestionnaire de détails produit
document.addEventListener('DOMContentLoaded', () => {
  window.productDetails = new ProductDetailsManager();
});

// Exporter pour l'utilisation dans d'autres modules
export default window.productDetails;
