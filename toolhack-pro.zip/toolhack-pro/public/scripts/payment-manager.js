// scripts/payment-manager.js

/**
 * Gestionnaire de paiement
 * Gère les paiements, génération de QR codes, et traitements de transactions
 */

import { PAYMENT_CONFIG } from '../app/config/constants.js';
import { 
  isWalletConnected, 
  sendTransaction, 
  generateTonPaymentUrl,
  watchTransaction
} from '../app/config/ton-wallet.js';
import { showAlert, hapticFeedback } from '../app/utils/telegram-api.js';
import { translate } from '../app/utils/i18n.js';
import { trackEvent, trackPurchase } from '../app/services/analytics.js';

// État du gestionnaire de paiement
let paymentState = {
  currentOrder: null,
  selectedMethod: null,
  paymentIntent: null,
  processing: false,
  transactionId: null,
  qrCodeElement: null,
  timer: null,
  timerDuration: 15 * 60, // 15 minutes en secondes
  currentStep: 'method', // 'method', 'processing', 'confirmed', 'failed'
  observingTransaction: false,
  orderId: null
};

/**
 * Initialise le gestionnaire de paiement
 * @param {Object} orderData - Données de la commande
 * @returns {Promise<boolean>} - Succès de l'initialisation
 */
export async function initPaymentManager(orderData) {
  // Réinitialiser l'état
  resetPaymentState();
  
  // Stocker les données de la commande
  paymentState.currentOrder = orderData;
  paymentState.orderId = generateOrderId();
  
  try {
    // Initialiser l'interface de paiement
    await setupPaymentInterface();
    
    // Initialiser les écouteurs d'événements
    setupEventListeners();
    
    // Tenter de pré-sélectionner une méthode de paiement
    if (isWalletConnected()) {
      // Si un portefeuille TON est connecté, le pré-sélectionner
      selectPaymentMethod('ton');
    }
    
    console.log('Payment manager initialized with order:', paymentState.orderId);
    
    return true;
  } catch (error) {
    console.error('Error initializing payment manager:', error);
    return false;
  }
}

/**
 * Réinitialise l'état du gestionnaire de paiement
 */
function resetPaymentState() {
  // Arrêter le timer s'il y en a un
  if (paymentState.timer) {
    clearInterval(paymentState.timer);
    paymentState.timer = null;
  }
  
  // Réinitialiser l'état
  paymentState = {
    currentOrder: null,
    selectedMethod: null,
    paymentIntent: null,
    processing: false,
    transactionId: null,
    qrCodeElement: null,
    timer: null,
    timerDuration: 15 * 60,
    currentStep: 'method',
    observingTransaction: false,
    orderId: null
  };
  
  // Réinitialiser l'interface
  const confirmationPanel = document.getElementById('payment-confirmation');
  if (confirmationPanel) {
    confirmationPanel.innerHTML = '';
  }
}

/**
 * Configure l'interface de paiement
 * @returns {Promise<void>}
 */
async function setupPaymentInterface() {
  // Obtenir les conteneurs
  const paymentOptions = document.getElementById('payment-options');
  const paymentTitle = document.querySelector('#payment-step h2');
  
  if (!paymentOptions || !paymentTitle) {
    throw new Error('Payment interface elements not found');
  }
  
  // Mettre à jour le titre
  paymentTitle.textContent = translate('checkout.select_payment');
  
  // Préparer les options de paiement
  const methods = [
    {
      id: 'ton',
      name: 'TON',
      icon: '/assets/images/ton-logo.svg',
      available: true,
      description: translate('payment.ton_description')
    },
    {
      id: 'btc',
      name: 'Bitcoin',
      icon: '/assets/images/bitcoin-logo.svg',
      available: true,
      description: translate('payment.btc_description')
    }
  ];
  
  // Générer le HTML
  let optionsHtml = '';
  methods.forEach(method => {
    const availableClass = method.available ? '' : 'disabled';
    optionsHtml += `
      <div class="payment-option ${availableClass}" data-method="${method.id}">
        <img src="${method.icon}" alt="${method.name}" />
        <div class="payment-option-details">
          <h3>${method.name}</h3>
          <p>${method.description}</p>
        </div>
      </div>
    `;
  });
  
  // Insérer dans le DOM
  paymentOptions.innerHTML = optionsHtml;
  
  // Afficher le récapitulatif de la commande si disponible
  if (paymentState.currentOrder) {
    displayOrderSummary();
  }
}

/**
 * Affiche le récapitulatif de la commande
 */
function displayOrderSummary() {
  // Chercher ou créer le conteneur du récapitulatif
  let summaryContainer = document.getElementById('order-summary');
  
  if (!summaryContainer) {
    summaryContainer = document.createElement('div');
    summaryContainer.id = 'order-summary';
    summaryContainer.className = 'order-summary';
    
    const paymentStep = document.getElementById('payment-step');
    if (paymentStep) {
      paymentStep.appendChild(summaryContainer);
    }
  }
  
  // Calculer le total
  const order = paymentState.currentOrder;
  const totalAmount = order.total;
  const itemCount = order.items.length;
  
  // Générer le HTML
  let html = `
    <h3>${translate('checkout.order_summary')}</h3>
    <div class="summary-details">
      <p>${translate('checkout.item_count', { count: itemCount })}</p>
      <p class="order-total">${translate('checkout.total')}: <strong>${totalAmount.toFixed(2)} $</strong></p>
    </div>
  `;
  
  // Insérer dans le DOM
  summaryContainer.innerHTML = html;
}

/**
 * Configure les écouteurs d'événements
 */
function setupEventListeners() {
  // Écouteur pour les options de paiement
  const paymentOptions = document.querySelectorAll('.payment-option');
  paymentOptions.forEach(option => {
    option.addEventListener('click', () => {
      if (!option.classList.contains('disabled')) {
        const method = option.getAttribute('data-method');
        selectPaymentMethod(method);
      }
    });
  });
  
  // Écouteur pour le bouton Suivant
  const nextButton = document.getElementById('payment-next');
  if (nextButton) {
    nextButton.addEventListener('click', async () => {
      if (paymentState.selectedMethod) {
        try {
          await processPayment();
        } catch (error) {
          showAlert(error.message || translate('payment.generic_error'));
        }
      } else {
        showAlert(translate('payment.select_method'));
      }
    });
  }
  
  // Écouteur pour le bouton Retour
  const backButton = document.getElementById('payment-back');
  if (backButton) {
    backButton.addEventListener('click', () => {
      // Retour au panier
      window.history.back();
    });
  }
}

/**
 * Sélectionne une méthode de paiement
 * @param {string} method - Identifiant de la méthode
 */
function selectPaymentMethod(method) {
  // Mettre à jour l'état
  paymentState.selectedMethod = method;
  
  // Mettre à jour l'interface
  const options = document.querySelectorAll('.payment-option');
  options.forEach(option => {
    if (option.getAttribute('data-method') === method) {
      option.classList.add('active');
    } else {
      option.classList.remove('active');
    }
  });
  
  // Activer le bouton suivant
  const nextButton = document.getElementById('payment-next');
  if (nextButton) {
    nextButton.disabled = false;
  }
  
  // Retour haptique
  hapticFeedback('medium');
}

/**
 * Génère un identifiant unique pour la commande
 * @returns {string} - Identifiant de commande
 */
function generateOrderId() {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 8);
  return `ORD-${timestamp}-${randomStr}`.toUpperCase();
}

/**
 * Traite le paiement selon la méthode sélectionnée
 * @returns {Promise<boolean>} - Succès du paiement
 */
async function processPayment() {
  // Vérifier si une méthode est sélectionnée
  if (!paymentState.selectedMethod) {
    throw new Error(translate('payment.no_method'));
  }
  
  // Vérifier si la commande existe
  if (!paymentState.currentOrder) {
    throw new Error(translate('payment.no_order'));
  }
  
  // Empêcher les doubles clics
  if (paymentState.processing) {
    return false;
  }
  
  paymentState.processing = true;
  updatePaymentInterface('processing');
  
  try {
    switch (paymentState.selectedMethod) {
      case 'ton':
        await processTonPayment();
        break;
      case 'btc':
        await processBitcoinPayment();
        break;
      default:
        throw new Error(translate('payment.invalid_method'));
    }
    
    // Tracking analytics
    trackEvent('payment_initiated', {
      payment_method: paymentState.selectedMethod,
      order_id: paymentState.orderId,
      amount: paymentState.currentOrder.total
    });
    
    return true;
  } catch (error) {
    console.error('Payment processing error:', error);
    
    // Mettre à jour l'interface
    updatePaymentInterface('error', { error: error.message });
    
    // Tracking analytics
    trackEvent('payment_error', {
      payment_method: paymentState.selectedMethod,
      error: error.message
    });
    
    paymentState.processing = false;
    return false;
  }
}

/**
 * Met à jour l'interface de paiement selon l'étape
 * @param {string} step - Étape de paiement
 * @param {Object} [data={}] - Données supplémentaires
 */
function updatePaymentInterface(step, data = {}) {
  paymentState.currentStep = step;
  
  // Mettre à jour le titre et le contenu
  const paymentStep = document.getElementById('payment-step');
  const paymentOptions = document.getElementById('payment-options');
  const nextButton = document.getElementById('payment-next');
  const backButton = document.getElementById('payment-back');
  
  if (!paymentStep || !paymentOptions) return;
  
  switch (step) {
    case 'processing':
      // Masquer les options et afficher le message de chargement
      paymentOptions.innerHTML = `
        <div class="payment-processing">
          <div class="spinner"></div>
          <p>${translate('payment.processing')}</p>
        </div>
      `;
      
      // Désactiver les boutons
      if (nextButton) nextButton.disabled = true;
      if (backButton) backButton.disabled = true;
      break;
      
    case 'qr_generated':
      // Afficher le QR code de paiement
      const { qrUrl, paymentAddress, amount } = data;
      
      paymentOptions.innerHTML = `
        <div class="payment-qr-container">
          <h3>${translate('payment.scan_qr')}</h3>
          <div class="qr-code" id="payment-qr"></div>
          <div class="payment-details">
            <p>${translate('payment.send')} <strong>${amount} ${paymentState.selectedMethod.toUpperCase()}</strong> ${translate('payment.to_address')}:</p>
            <div class="payment-address">
              <code>${paymentAddress}</code>
              <button class="copy-button" data-clipboard="${paymentAddress}">
                <i class="fas fa-copy"></i>
              </button>
            </div>
          </div>
          <div class="payment-timer" id="payment-timer">
            <p>${translate('payment.expires_in')}: <span class="time-remaining">15:00</span></p>
          </div>
        </div>
      `;
      
      // Générer le QR code
      const qrElement = document.getElementById('payment-qr');
      if (qrElement) {
        qrElement.innerHTML = `<img src="${qrUrl}" alt="Payment QR Code" />`;
        paymentState.qrCodeElement = qrElement;
      }
      
      // Configurer le timer
      startPaymentTimer();
      
      // Configurer les écouteurs pour le bouton de copie
      setupCopyButton();
      
      break;
      
    case 'transaction_sent':
      // Afficher le message de confirmation de transaction envoyée
      paymentOptions.innerHTML = `
        <div class="payment-confirmation">
          <div class="confirmation-icon success">
            <i class="fas fa-paper-plane"></i>
          </div>
          <h3>${translate('payment.transaction_sent')}</h3>
          <p>${translate('payment.awaiting_confirmation')}</p>
          <div class="transaction-details">
            ${data.transactionId ? `
              <p>${translate('payment.transaction_id')}:</p>
              <code>${data.transactionId}</code>
            ` : ''}
          </div>
          <div class="confirmation-progress">
            <div class="progress-bar">
              <div class="progress" style="width: 33%"></div>
            </div>
            <p>${translate('payment.confirmations')}: <span id="confirmation-count">0</span>/3</p>
          </div>
        </div>
      `;
      
      break;
      
    case 'confirmed':
      // Afficher le message de confirmation
      paymentOptions.innerHTML = `
        <div class="payment-confirmation">
          <div class="confirmation-icon success">
            <i class="fas fa-check-circle"></i>
          </div>
          <h3>${translate('payment.confirmed')}</h3>
          <p>${translate('payment.thank_you')}</p>
          <div class="order-info">
            <p>${translate('payment.order_id')}: <strong>${paymentState.orderId}</strong></p>
            <p>${translate('payment.confirmation_sent')}</p>
          </div>
          <button id="continue-shopping" class="button-primary">
            ${translate('payment.continue_shopping')}
          </button>
        </div>
      `;
      
      // Configurer l'écouteur pour le bouton
      const continueButton = document.getElementById('continue-shopping');
      if (continueButton) {
        continueButton.addEventListener('click', () => {
          window.location.href = '/';
        });
      }
      
      // Désactiver les boutons de navigation
      if (nextButton) nextButton.style.display = 'none';
      if (backButton) backButton.style.display = 'none';
      
      break;
      
    case 'error':
      // Afficher le message d'erreur
      paymentOptions.innerHTML = `
        <div class="payment-error">
          <div class="error-icon">
            <i class="fas fa-exclamation-circle"></i>
          </div>
          <h3>${translate('payment.payment_failed')}</h3>
          <p>${data.error || translate('payment.generic_error')}</p>
          <button id="retry-payment" class="button-primary">
            ${translate('payment.retry')}
          </button>
        </div>
      `;
      
      // Configurer l'écouteur pour le bouton
      const retryButton = document.getElementById('retry-payment');
      if (retryButton) {
        retryButton.addEventListener('click', () => {
          // Revenir à l'état initial
          setupPaymentInterface();
        });
      }
      
      // Réactiver le bouton de retour
      if (backButton) backButton.disabled = false;
      
      break;
      
    default:
      // Étape par défaut (sélection de méthode)
      break;
  }
}

/**
 * Démarre le timer pour le paiement
 */
function startPaymentTimer() {
  // Arrêter le timer précédent s'il existe
  if (paymentState.timer) {
    clearInterval(paymentState.timer);
  }
  
  let remainingTime = paymentState.timerDuration;
  const timerElement = document.querySelector('#payment-timer .time-remaining');
  
  if (!timerElement) return;
  
  // Fonction pour mettre à jour l'affichage du timer
  const updateTimer = () => {
    const minutes = Math.floor(remainingTime / 60);
    const seconds = remainingTime % 60;
    timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    if (remainingTime <= 0) {
      clearInterval(paymentState.timer);
      // Le paiement a expiré
      updatePaymentInterface('error', { error: translate('payment.expired') });
    }
    
    remainingTime--;
  };
  
  // Initialiser l'affichage
  updateTimer();
  
  // Démarrer l'intervalle
  paymentState.timer = setInterval(updateTimer, 1000);
}

/**
 * Configure le bouton de copie d'adresse
 */
function setupCopyButton() {
  const copyButton = document.querySelector('.copy-button');
  if (!copyButton) return;
  
  copyButton.addEventListener('click', () => {
    const textToCopy = copyButton.getAttribute('data-clipboard');
    
    // Utiliser l'API clipboard
    navigator.clipboard.writeText(textToCopy)
      .then(() => {
        // Indiquer le succès
        copyButton.classList.add('copied');
        copyButton.innerHTML = '<i class="fas fa-check"></i>';
        
        // Retour haptique
        hapticFeedback('success');
        
        // Réinitialiser après un délai
        setTimeout(() => {
          copyButton.classList.remove('copied');
          copyButton.innerHTML = '<i class="fas fa-copy"></i>';
        }, 2000);
      })
      .catch(err => {
        console.error('Erreur lors de la copie:', err);
        
        // Retour haptique
        hapticFeedback('error');
      });
  });
}

/**
 * Traite un paiement en TON
 * @returns {Promise<void>}
 */
async function processTonPayment() {
  const order = paymentState.currentOrder;
  const amount = order.total;
  const comment = `Order ${paymentState.orderId}`;
  
  // Vérifier si le portefeuille TON est connecté
  if (isWalletConnected()) {
    try {
      // Utiliser le portefeuille connecté
      const result = await sendTransaction(
        PAYMENT_CONFIG.TON.walletAddress,
        amount,
        comment
      );
      
      if (result && result.success) {
        // Enregistrer l'ID de transaction
        paymentState.transactionId = result.transactionId;
        
        // Observer la transaction
        watchPaymentTransaction();
        
        // Mettre à jour l'interface
        updatePaymentInterface('transaction_sent', {
          transactionId: result.transactionId
        });
      } else {
        throw new Error('Transaction failed');
      }
    } catch (error) {
      throw new Error(`TON transaction failed: ${error.message}`);
    }
  } else {
    // Mode QR code pour le paiement externe
    try {
      // Générer l'URL de paiement
      const paymentUrl = generateTonPaymentUrl(
        PAYMENT_CONFIG.TON.walletAddress,
        amount,
        comment
      );
      
      // Mettre à jour l'interface avec le QR code
      updatePaymentInterface('qr_generated', {
        qrUrl: paymentUrl,
        paymentAddress: PAYMENT_CONFIG.TON.walletAddress,
        amount
      });
      
      // Démarrer la vérification périodique du paiement
      checkPaymentStatus();
    } catch (error) {
      throw new Error(`Failed to generate TON payment: ${error.message}`);
    }
  }
}

/**
 * Traite un paiement en Bitcoin
 * @returns {Promise<void>}
 */
async function processBitcoinPayment() {
  const order = paymentState.currentOrder;
  const amount = convertToBTC(order.total); // Convertir USD en BTC
  
  try {
    // En production, on générerait une adresse unique depuis le serveur
    // Pour l'exemple, on utilise une adresse statique
    const paymentAddress = PAYMENT_CONFIG.BTC.walletAddress;
    
    // Générer l'URL pour le QR code (format BIP21)
    const paymentUrl = `bitcoin:${paymentAddress}?amount=${amount}`;
    
    // URL du QR code
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(paymentUrl)}`;
    
    // Mettre à jour l'interface avec le QR code
    updatePaymentInterface('qr_generated', {
      qrUrl,
      paymentAddress,
      amount
    });
    
    // Démarrer la vérification périodique du paiement
    checkPaymentStatus();
  } catch (error) {
    throw new Error(`Failed to generate Bitcoin payment: ${error.message}`);
  }
}

/**
 * Convertit un montant USD en BTC (simplifié)
 * @param {number} amountUSD - Montant en USD
 * @returns {number} - Montant équivalent en BTC
 */
function convertToBTC(amountUSD) {
  // Dans une application réelle, ce taux serait obtenu dynamiquement via une API
  const btcRate = PAYMENT_CONFIG.BTC.rate || 30000; // 1 BTC = 30000 USD
  return parseFloat((amountUSD / btcRate).toFixed(8));
}

/**
 * Vérifie périodiquement l'état du paiement
 */
function checkPaymentStatus() {
  // Dans une application réelle, on interrogerait l'API pour vérifier le paiement
  // Pour l'exemple, on simule une vérification après 10 secondes
  
  setTimeout(() => {
    // Simulation aléatoire de confirmation (pour démonstration)
    if (Math.random() > 0.3) { // 70% de chance de succès
      // Paiement réussi
      paymentSuccess();
    } else {
      // Vérifier à nouveau après un délai
      setTimeout(checkPaymentStatus, 5000);
    }
  }, 10000);
}

/**
 * Observe une transaction pour les confirmations
 */
function watchPaymentTransaction() {
  if (paymentState.observingTransaction || !paymentState.transactionId) {
    return;
  }
  
  paymentState.observingTransaction = true;
  
  // Utiliser la fonction watchTransaction du portefeuille TON
  const watcher = watchTransaction(
    paymentState.transactionId, 
    (status, confirmations) => {
      console.log(`Transaction status: ${status}, confirmations: ${confirmations}`);
      
      // Mettre à jour le compteur de confirmations
      const confirmationCount = document.getElementById('confirmation-count');
      if (confirmationCount) {
        confirmationCount.textContent = confirmations.toString();
        
        // Mettre à jour la barre de progression
        const progress = document.querySelector('.progress');
        if (progress) {
          progress.style.width = `${Math.min(confirmations / 3 * 100, 100)}%`;
        }
      }
      
      if (status === 'confirmed' || confirmations >= 3) {
        // Transaction confirmée
        paymentSuccess();
        
        // Arrêter l'observation
        if (watcher && typeof watcher.stop === 'function') {
          watcher.stop();
        }
      } else if (status === 'error' || status === 'timeout') {
        // Erreur de transaction
        updatePaymentInterface('error', { 
          error: translate('payment.transaction_error') 
        });
      }
    },
    3 // Nombre de confirmations requises
  );
}

/**
 * Traite le succès d'un paiement
 */
function paymentSuccess() {
  // Arrêter le timer
  if (paymentState.timer) {
    clearInterval(paymentState.timer);
    paymentState.timer = null;
  }
  
  // Mettre à jour l'interface
  updatePaymentInterface('confirmed');
  
  // Retour haptique
  hapticFeedback('success');
  
  // Enregistrer le paiement dans l'analytique
  trackPurchase(
    paymentState.orderId,
    paymentState.currentOrder.total,
    paymentState.selectedMethod
  );
  
  // Déclencher un événement pour le système
  document.dispatchEvent(new CustomEvent('payment-completed', {
    detail: {
      orderId: paymentState.orderId,
      amount: paymentState.currentOrder.total,
      method: paymentState.selectedMethod,
      transactionId: paymentState.transactionId
    }
  }));
  
  // Nettoyer le panier (utiliser l'API du panier)
  if (window.cartManager && typeof window.cartManager.clearCart === 'function') {
    window.cartManager.clearCart();
  }
}

/**
 * Vérifie si le paiement est en cours
 * @returns {boolean} - Vrai si le paiement est en cours
 */
export function isPaymentProcessing() {
  return paymentState.processing;
}

/**
 * Obtient l'identifiant de la commande en cours
 * @returns {string|null} - Identifiant de commande
 */
export function getCurrentOrderId() {
  return paymentState.orderId;
}

/**
 * Annule le processus de paiement en cours
 * @returns {boolean} - Succès de l'annulation
 */
export function cancelPayment() {
  // Vérifier s'il y a un paiement en cours
  if (!paymentState.processing) {
    return false;
  }
  
  // Arrêter le timer
  if (paymentState.timer) {
    clearInterval(paymentState.timer);
    paymentState.timer = null;
  }
  
  // Réinitialiser l'état
  resetPaymentState();
  
  // Revenir à la sélection de méthode
  setupPaymentInterface();
  
  return true;
}

// Exporter les fonctions principales
export default {
  initPaymentManager,
  isPaymentProcessing,
  getCurrentOrderId,
  cancelPayment
};
