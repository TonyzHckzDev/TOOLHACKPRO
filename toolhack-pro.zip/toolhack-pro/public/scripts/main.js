// scripts/main.js

// Import des dépendances
import { initTelegramWebApp } from '../app/utils/telegram-api.js';
import { setupLanguage, translate } from '../app/utils/i18n.js';
import { initProductsService } from '../app/services/products.js';
import { initCart } from '../app/components/cart.js';
import { initPayments } from '../app/services/payments.js';
import { setupAnalytics } from '../app/services/analytics.js';
import { initSecurity } from '../app/services/security.js';
import { TON_NETWORK } from '../app/config/constants.js';
import { initTonWallet } from '../app/config/ton-wallet.js';
import { lazyLoadImages } from './lazyload.js';
import { initTheme } from './theme-manager.js';

// État global de l'application
const appState = {
  isLoaded: false,
  isVerified: false,
  cart: [],
  user: null,
  currentPage: 'catalog',
  tonConnected: false,
  selectedLanguage: 'fr',
  darkMode: false
};

/**
 * Initialisation de l'application
 */
async function initApp() {
  console.log('ToolHack Pro initializing...');
  
  try {
    // Initialiser Telegram WebApp
    const telegramUser = await initTelegramWebApp();
    if (telegramUser) {
      appState.user = telegramUser;
      console.log('Telegram WebApp initialized successfully');
      
      // Vérifier si l'utilisateur est autorisé
      const isVerified = await verifyUser(telegramUser);
      appState.isVerified = isVerified;
      
      if (!isVerified) {
        showVerificationScreen();
        return;
      }
    } else {
      // Fallback pour les environnements hors Telegram
      console.log('Running outside Telegram WebApp environment');
    }
    
    // Initialiser les préférences utilisateur
    initUserPreferences();
    
    // Configurer la langue
    await setupLanguage(appState.selectedLanguage);
    
    // Initialiser les services
    await Promise.all([
      initProductsService(),
      initSecurity(),
      setupAnalytics(appState.user)
    ]);
    
    // Initialiser le wallet TON si nécessaire
    if (appState.user) {
      initTonWallet(TON_NETWORK, appState.user.id)
        .then(connected => {
          appState.tonConnected = connected;
          updatePaymentOptions();
        })
        .catch(err => console.error('TON wallet initialization failed:', err));
    }
    
    // Initialiser les composants UI
    initCart(appState.cart, updateCartDisplay);
    initTheme(appState.darkMode);
    initUIComponents();
    
    // Optimisations de performances
    lazyLoadImages();
    registerServiceWorker();
    
    // Marquer l'application comme chargée
    appState.isLoaded = true;
    document.body.classList.add('app-loaded');
    hideLoadingScreen();
    
    // Afficher la page appropriée
    renderCurrentPage();
    
    console.log('ToolHack Pro initialized successfully');
  } catch (error) {
    console.error('Error initializing ToolHack Pro:', error);
    showErrorScreen(error);
  }
}

/**
 * Vérifie si l'utilisateur est autorisé à accéder à la plateforme
 * @param {Object} user - L'utilisateur Telegram
 * @return {Promise<boolean>} - Si l'utilisateur est vérifié
 */
async function verifyUser(user) {
  // Import dynamique pour réduire la charge initiale
  const { verifyTelegramUser } = await import('../app/verification.js');
  return await verifyTelegramUser(user);
}

/**
 * Initialiser les préférences utilisateur depuis le stockage local
 */
function initUserPreferences() {
  try {
    const storedPrefs = localStorage.getItem('toolhack_preferences');
    if (storedPrefs) {
      const prefs = JSON.parse(storedPrefs);
      appState.selectedLanguage = prefs.language || 'fr';
      appState.darkMode = prefs.darkMode || false;
      
      // Restaurer le panier
      const storedCart = localStorage.getItem('toolhack_cart');
      if (storedCart) {
        appState.cart = JSON.parse(storedCart);
      }
    }
  } catch (e) {
    console.warn('Failed to load user preferences:', e);
  }
}

/**
 * Enregistre le service worker pour les fonctionnalités offline
 */
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js')
        .then(registration => {
          console.log('ServiceWorker registration successful');
        })
        .catch(error => {
          console.error('ServiceWorker registration failed:', error);
        });
    });
  }
}

/**
 * Initialiser les composants de l'interface utilisateur
 */
function initUIComponents() {
  // Attacher les gestionnaires d'événements aux éléments du DOM
  document.querySelectorAll('[data-page]').forEach(element => {
    element.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(element.dataset.page);
    });
  });
  
  // Initialisation du menu
  const menuToggle = document.getElementById('menu-toggle');
  if (menuToggle) {
    menuToggle.addEventListener('click', toggleMenu);
  }
  
  // Initialisation du sélecteur de langue
  const langSelector = document.getElementById('language-selector');
  if (langSelector) {
    langSelector.addEventListener('change', (e) => {
      changeLanguage(e.target.value);
    });
    langSelector.value = appState.selectedLanguage;
  }
  
  // Initialisation du toggle theme
  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
    themeToggle.checked = appState.darkMode;
  }
}

/**
 * Mise à jour des options de paiement basée sur la connexion du wallet
 */
function updatePaymentOptions() {
  const paymentSection = document.getElementById('payment-options');
  if (paymentSection) {
    if (appState.tonConnected) {
      paymentSection.innerHTML = `
        <div class="payment-option ton active">
          <img src="assets/images/ton-logo.svg" alt="TON" />
          <span>${translate('payment.ton_connected')}</span>
        </div>
        <div class="payment-option btc">
          <img src="assets/images/bitcoin-logo.svg" alt="Bitcoin" />
          <span>${translate('payment.btc_option')}</span>
        </div>
      `;
    } else {
      paymentSection.innerHTML = `
        <div class="payment-option ton">
          <img src="assets/images/ton-logo.svg" alt="TON" />
          <span>${translate('payment.connect_ton_wallet')}</span>
          <button id="connect-ton" class="btn-connect">${translate('payment.connect')}</button>
        </div>
        <div class="payment-option btc active">
          <img src="assets/images/bitcoin-logo.svg" alt="Bitcoin" />
          <span>${translate('payment.btc_option')}</span>
        </div>
      `;
      
      // Ajouter l'événement pour la connexion du wallet
      const connectBtn = document.getElementById('connect-ton');
      if (connectBtn) {
        connectBtn.addEventListener('click', async () => {
          try {
            const connected = await initTonWallet(TON_NETWORK, appState.user.id);
            appState.tonConnected = connected;
            updatePaymentOptions();
          } catch (err) {
            console.error('Failed to connect TON wallet:', err);
            alert(translate('payment.connect_error'));
          }
        });
      }
    }
  }
}

/**
 * Affiche l'écran de vérification pour les utilisateurs non autorisés
 */
function showVerificationScreen() {
  hideLoadingScreen();
  document.getElementById('verification-screen').classList.remove('hidden');
  document.getElementById('main-content').classList.add('hidden');
  
  // Initialisation du formulaire de vérification
  const verifyForm = document.getElementById('verification-form');
  if (verifyForm) {
    verifyForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const code = document.getElementById('verification-code').value;
      try {
        const { verifyInviteCode } = await import('../app/verification.js');
        const isValid = await verifyInviteCode(code, appState.user);
        if (isValid) {
          appState.isVerified = true;
          document.getElementById('verification-screen').classList.add('hidden');
          document.getElementById('main-content').classList.remove('hidden');
          initApp(); // Réinitialiser l'application
        } else {
          document.getElementById('verification-error').textContent = translate('verification.invalid_code');
        }
      } catch (err) {
        console.error('Verification error:', err);
        document.getElementById('verification-error').textContent = translate('verification.error');
      }
    });
  }
}

/**
 * Affiche un écran d'erreur en cas de problème critique
 */
function showErrorScreen(error) {
  hideLoadingScreen();
  const errorScreen = document.getElementById('error-screen');
  if (errorScreen) {
    const errorMessage = document.getElementById('error-message');
    if (errorMessage) {
      errorMessage.textContent = translate('errors.initialization') + (error.message || '');
    }
    errorScreen.classList.remove('hidden');
  }
}

/**
 * Cache l'écran de chargement une fois l'initialisation terminée
 */
function hideLoadingScreen() {
  const loadingScreen = document.getElementById('loading-screen');
  if (loadingScreen) {
    loadingScreen.classList.add('fade-out');
    setTimeout(() => {
      loadingScreen.classList.add('hidden');
    }, 500);
  }
}

/**
 * Change la langue de l'application
 * @param {string} lang - Code de la langue ('fr', 'en', etc.)
 */
async function changeLanguage(lang) {
  try {
    appState.selectedLanguage = lang;
    await setupLanguage(lang);
    // Mettre à jour l'interface utilisateur avec les nouvelles traductions
    document.querySelectorAll('[data-i18n]').forEach(element => {
      const key = element.dataset.i18n;
      element.textContent = translate(key);
    });
    
    // Sauvegarder la préférence
    saveUserPreferences();
    
    // Mettre à jour les éléments dynamiques
    updateCartDisplay();
    updatePaymentOptions();
  } catch (error) {
    console.error('Error changing language:', error);
  }
}

/**
 * Bascule le thème entre clair et sombre
 */
function toggleTheme() {
  appState.darkMode = !appState.darkMode;
  document.body.classList.toggle('dark-theme', appState.darkMode);
  saveUserPreferences();
}

/**
 * Affiche/cache le menu mobile
 */
function toggleMenu() {
  const navMenu = document.getElementById('nav-menu');
  if (navMenu) {
    navMenu.classList.toggle('open');
    document.getElementById('menu-toggle').classList.toggle('open');
  }
}

/**
 * Navigation entre les pages de l'application
 * @param {string} page - Identifiant de la page
 */
function navigateTo(page) {
  // Masquer toutes les pages
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  
  // Afficher la page demandée
  const targetPage = document.getElementById(`page-${page}`);
  if (targetPage) {
    targetPage.classList.remove('hidden');
    appState.currentPage = page;
    
    // Mettre à jour la navigation
    document.querySelectorAll('nav a').forEach(a => {
      a.classList.toggle('active', a.dataset.page === page);
    });
    
    // Fermer le menu mobile si ouvert
    const navMenu = document.getElementById('nav-menu');
    if (navMenu && navMenu.classList.contains('open')) {
      toggleMenu();
    }
    
    // Actions spécifiques selon la page
    if (page === 'checkout') {
      // Charger dynamiquement le module de checkout
      import('./checkout.js').then(module => {
        module.initCheckout(appState.cart, appState.tonConnected);
      });
    } else if (page === 'product-details' && appState.selectedProduct) {
      // Charger les détails d'un produit
      import('./product-details.js').then(module => {
        module.loadProductDetails(appState.selectedProduct);
      });
    }
    
    // Analytiques de navigation
    if (appState.isLoaded) {
      import('../app/services/analytics.js').then(module => {
        module.trackPageView(page);
      });
    }
  } else {
    console.error(`Page not found: ${page}`);
  }
}

/**
 * Mise à jour de l'affichage du panier
 */
function updateCartDisplay() {
  const cartCount = document.getElementById('cart-count');
  const cartTotal = document.getElementById('cart-total');
  const cartItems = document.getElementById('cart-items');
  
  if (cartCount) {
    const itemCount = appState.cart.reduce((total, item) => total + item.quantity, 0);
    cartCount.textContent = itemCount.toString();
    cartCount.classList.toggle('hidden', itemCount === 0);
  }
  
  if (cartTotal) {
    const total = appState.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotal.textContent = `${total.toFixed(2)} $`;
  }
  
  if (cartItems) {
    if (appState.cart.length === 0) {
      cartItems.innerHTML = `<p class="empty-cart">${translate('cart.empty')}</p>`;
    } else {
      cartItems.innerHTML = appState.cart.map(item => `
        <div class="cart-item" data-id="${item.id}">
          <img src="${item.image}" alt="${item.name}" class="cart-item-image">
          <div class="cart-item-details">
            <h4>${item.name}</h4>
            <div class="cart-item-price">${item.price.toFixed(2)} $ × ${item.quantity}</div>
          </div>
          <button class="remove-item" data-id="${item.id}">&times;</button>
        </div>
      `).join('');
      
      // Ajouter les gestionnaires d'événements pour la suppression
      document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', () => {
          const itemId = button.dataset.id;
          removeFromCart(itemId);
        });
      });
    }
  }
  
  // Sauvegarder le panier dans le stockage local
  localStorage.setItem('toolhack_cart', JSON.stringify(appState.cart));
}

/**
 * Supprimer un produit du panier
 * @param {string} productId - ID du produit à supprimer
 */
function removeFromCart(productId) {
  const index = appState.cart.findIndex(item => item.id === productId);
  if (index !== -1) {
    if (appState.cart[index].quantity > 1) {
      appState.cart[index].quantity -= 1;
    } else {
      appState.cart.splice(index, 1);
    }
    updateCartDisplay();
  }
}

/**
 * Sauvegarde les préférences utilisateur
 */
function saveUserPreferences() {
  try {
    const prefs = {
      language: appState.selectedLanguage,
      darkMode: appState.darkMode
    };
    localStorage.setItem('toolhack_preferences', JSON.stringify(prefs));
  } catch (e) {
    console.warn('Failed to save user preferences:', e);
  }
}

/**
 * Affiche la page actuelle
 */
function renderCurrentPage() {
  navigateTo(appState.currentPage);
}

// Démarrer l'application quand le DOM est chargé
document.addEventListener('DOMContentLoaded', initApp);

// Exporter les fonctions et états nécessaires
export {
  appState,
  navigateTo,
  updateCartDisplay,
  removeFromCart,
  changeLanguage,
  toggleTheme
};
