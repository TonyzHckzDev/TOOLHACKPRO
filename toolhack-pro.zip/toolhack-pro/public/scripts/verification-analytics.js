/**
 * Module d'analyse des vérifications professionnelles
 * Collecte et analyse les données de vérification de manière anonymisée
 */
class VerificationAnalytics {
  constructor() {
    this.analyticsEndpoint = 'https://analytics.toolhack.pro/verify';
    this.localStorageKey = 'toolhack_analytics_consent';
    this.sessionData = {};
    this.hasConsent = this.checkConsentStatus();
  }
  
  /**
   * Vérifie si l'utilisateur a donné son consentement
   */
  checkConsentStatus() {
    try {
      const consent = localStorage.getItem(this.localStorageKey);
      return consent === 'granted';
    } catch (e) {
      return false;
    }
  }
  
  /**
   * Définit le statut de consentement
   */
  setConsentStatus(status) {
    try {
      if (status === true) {
        localStorage.setItem(this.localStorageKey, 'granted');
        this.hasConsent = true;
      } else {
        localStorage.setItem(this.localStorageKey, 'denied');
        this.hasConsent = false;
      }
    } catch (e) {
      console.warn('Could not save consent status', e);
    }
  }
  
  /**
   * Initialise la session analytique
   */
  initSession() {
    this.sessionData = {
      sessionId: this.generateSessionId(),
      startTime: new Date(),
      platform: this.getPlatformInfo(),
      events: []
    };
    
    // Écouter les événements de vérification
    window.addEventListener('toolhackVerified', (event) => {
      this.trackEvent('verification_success', event.detail);
    });
    
    window.addEventListener('toolhackVerificationFailed', (event) => {
      this.trackEvent('verification_failure', event.detail);
    });
  }
  
  /**
   * Génère un identifiant de session anonyme
   */
  generateSessionId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0, 
            v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
  
  /**
   * Obtient des informations sur la plateforme
   */
  getPlatformInfo() {
    return {
      userAgent: navigator.userAgent,
      language: navigator.language,
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
      isTelegramWebApp: !!window.Telegram?.WebApp
    };
  }
  
  /**
   * Suit un événement d'analyse
   */
  trackEvent(eventName, eventData = {}) {
    if (!this.hasConsent) return;
    
    // Créer l'objet d'événement
    const event = {
      eventName,
      timestamp: new Date(),
      data: this.sanitizeData(eventData)
    };
    
    // Ajouter à la liste des événements
    this.sessionData.events.push(event);
    
    // Envoyer les données si nécessaire
    if (eventName === 'verification_success' || eventName === 'verification_failure') {
      this.sendAnalytics();
    }
  }
  
  /**
   * Nettoie les données sensibles
   */
  sanitizeData(data) {
    // Créer une copie pour ne pas modifier l'original
    const sanitized = JSON.parse(JSON.stringify(data));
    
    // Supprimer les données sensibles
    if (sanitized.license) sanitized.license = 'REDACTED';
    if (sanitized.licenseNumber) sanitized.licenseNumber = 'REDACTED';
    
    // Hacher l'ID utilisateur si présent pour l'anonymisation
    if (sanitized.userId) {
      sanitized.userId = this.hashIdentifier(sanitized.userId);
    }
    
    // Anonymiser tout identifiant Telegram
    if (sanitized.telegramId) {
      sanitized.telegramId = this.hashIdentifier(sanitized.telegramId);
    }
    
    return sanitized;
  }
  
  /**
   * Hache un identifiant pour l'anonymiser
   */
  hashIdentifier(identifier) {
    // Simple hachage du côté client (non sécurisé mais acceptable pour l'anonymisation)
    let hash = 0;
    for (let i = 0; i < identifier.length; i++) {
      const char = identifier.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Conversion en 32bit integer
    }
    return 'user_' + Math.abs(hash).toString(16);
  }
  
  /**
   * Envoie les données d'analyse au serveur
   */
  async sendAnalytics() {
    if (!this.hasConsent || this.sessionData.events.length === 0) return;
    
    try {
      // Préparer les données à envoyer
      const analyticsData = {
        sessionId: this.sessionData.sessionId,
        platform: this.sessionData.platform,
        events: this.sessionData.events
      };
      
      // Envoyer de manière asynchrone
      navigator.sendBeacon(
        this.analyticsEndpoint,
        JSON.stringify(analyticsData)
      );
      
      // Vider les événements envoyés
      this.sessionData.events = [];
    } catch (error) {
      console.warn('Failed to send analytics data', error);
    }
  }
  
  /**
   * Affiche la demande de consentement
   */
  showConsentPrompt() {
    // Créer l'élément de consentement s'il n'existe pas déjà
    if (document.getElementById('analytics-consent')) return;
    
    const consentElement = document.createElement('div');
    consentElement.id = 'analytics-consent';
    consentElement.className = 'consent-prompt';
    consentElement.innerHTML = `
      <div class="consent-content">
        <p>Nous collectons des données anonymisées pour améliorer le processus de vérification. Aucune information personnelle n'est partagée.</p>
        <div class="consent-buttons">
          <button id="consent-accept" class="consent-button accept">Accepter</button>
          <button id="consent-decline" class="consent-button decline">Refuser</button>
        </div>
      </div>
    `;
    
    // Ajouter à la page
    document.body.appendChild(consentElement);
    
    // Configurer les écouteurs
    document.getElementById('consent-accept').addEventListener('click', () => {
      this.setConsentStatus(true);
      this.initSession();
      consentElement.remove();
    });
    
    document.getElementById('consent-decline').addEventListener('click', () => {
      this.setConsentStatus(false);
      consentElement.remove();
    });
  }
}

// Initialiser le module d'analyse
document.addEventListener('DOMContentLoaded', () => {
  window.verificationAnalytics = new VerificationAnalytics();
  
  // Demander le consentement après un court délai
  setTimeout(() => {
    if (window.verificationAnalytics.hasConsent === false) {
      window.verificationAnalytics.showConsentPrompt();
    } else if (window.verificationAnalytics.hasConsent === true) {
      window.verificationAnalytics.initSession();
    }
  }, 2000);
});

// Exporter pour l'utilisation dans d'autres modules
export default VerificationAnalytics;
