// scripts/lazyload.js

/**
 * Module de chargement paresseux des images
 * Optimise le chargement des images pour améliorer les performances
 */

// Configuration
const config = {
  // Marge de déclenchement (en pixels) avant que l'image entre dans la vue
  rootMargin: '200px 0px',
  // Seuil de visibilité (0 à 1) pour charger l'image
  threshold: 0.1,
  // Attributs à observer
  lazyAttribute: 'data-src',
  lazyBackgroundAttribute: 'data-bg',
  srcsetAttribute: 'data-srcset',
  sizesAttribute: 'data-sizes',
  // Placeholders
  placeholderLowQuality: 'data-placeholder',
  // Classes
  loadingClass: 'image-loading',
  loadedClass: 'image-loaded',
  errorClass: 'image-error',
  // Délai avant de masquer le placeholder (ms)
  placeholderFadeDelay: 300,
  // Temps d'expiration pour le chargement des images (ms)
  loadTimeout: 8000,
  // Réessais en cas d'échec
  maxRetries: 2,
  // Priorité des images (true pour charger les images importantes d'abord)
  enablePriority: true,
  // Attribut de priorité
  priorityAttribute: 'data-priority',
  // Délai entre les chargements (ms)
  throttleDelay: 100
};

// État du module
const state = {
  observer: null,
  fallbackTimer: null,
  loadQueue: [],
  loadingImages: new Set(),
  processedImages: new WeakSet(),
  totalImages: 0,
  loadedImages: 0,
  failedImages: 0,
  isObserverSupported: 'IntersectionObserver' in window,
  isInitialized: false
};

/**
 * Initialise le module de chargement paresseux
 * @param {Object} [options={}] - Options de configuration
 */
export function initLazyLoad(options = {}) {
  // Déjà initialisé, éviter une double initialisation
  if (state.isInitialized) {
    return;
  }
  
  // Fusionner la configuration personnalisée avec la configuration par défaut
  Object.assign(config, options);
  
  console.log('Initializing lazy loading module');
  
  // Créer l'observateur d'intersection si supporté
  if (state.isObserverSupported) {
    state.observer = createIntersectionObserver();
  }
  
  // Observer les images existantes
  lazyLoadImages();
  
  // Observer les modifications du DOM pour les nouvelles images
  setupMutationObserver();
  
  // Mettre en place un écouteur de défilement pour le fallback
  setupScrollListener();
  
  // Traiter immédiatement les images critiques
  processHighPriorityImages();
  
  state.isInitialized = true;
  
  // Mettre à jour les images lorsque l'utilisateur devient inactif
  setupUserIdleCallback();
}

/**
 * Crée et configure un observateur d'intersection
 * @returns {IntersectionObserver} - Observateur configuré
 */
function createIntersectionObserver() {
  const options = {
    rootMargin: config.rootMargin,
    threshold: config.threshold
  };
  
  return new IntersectionObserver((entries, observer) => {
    // Trier les entrées par priorité et visibilité
    const sortedEntries = sortEntriesByPriority(entries);
    
    // Traiter chaque entrée avec un délai pour ne pas bloquer le thread principal
    processEntriesWithDelay(sortedEntries, observer);
  }, options);
}

/**
 * Trie les entrées par priorité et visibilité
 * @param {Array} entries - Entrées de l'observateur d'intersection
 * @returns {Array} - Entrées triées
 */
function sortEntriesByPriority(entries) {
  if (!config.enablePriority) {
    return entries;
  }
  
  return entries.slice().sort((a, b) => {
    // D'abord par visibilité
    if (a.isIntersecting !== b.isIntersecting) {
      return b.isIntersecting ? 1 : -1;
    }
    
    // Ensuite par priorité
    const priorityA = parseInt(a.target.getAttribute(config.priorityAttribute) || '0', 10);
    const priorityB = parseInt(b.target.getAttribute(config.priorityAttribute) || '0', 10);
    
    return priorityB - priorityA;
  });
}

/**
 * Traite les entrées avec un délai entre elles
 * @param {Array} entries - Entrées à traiter
 * @param {IntersectionObserver} observer - Observateur d'intersection
 */
function processEntriesWithDelay(entries, observer) {
  entries.forEach((entry, index) => {
    if (entry.isIntersecting) {
      setTimeout(() => {
        processIntersectionEntry(entry, observer);
      }, index * config.throttleDelay);
    }
  });
}

/**
 * Traite une entrée d'intersection
 * @param {IntersectionObserverEntry} entry - Entrée d'intersection
 * @param {IntersectionObserver} observer - Observateur d'intersection
 */
function processIntersectionEntry(entry, observer) {
  const element = entry.target;
  
  // Vérifier si l'élément a déjà été traité
  if (state.processedImages.has(element)) {
    return;
  }
  
  // Marquer comme traité pour éviter les doublons
  state.processedImages.add(element);
  
  if (element.tagName.toLowerCase() === 'img') {
    loadImage(element);
    observer.unobserve(element);
  } else if (element.hasAttribute(config.lazyBackgroundAttribute)) {
    loadBackgroundImage(element);
    observer.unobserve(element);
  }
}

/**
 * Traite les images à haute priorité immédiatement
 */
function processHighPriorityImages() {
  if (!config.enablePriority) {
    return;
  }
  
  const highPriorityImages = document.querySelectorAll(`[${config.priorityAttribute}="10"]`);
  
  highPriorityImages.forEach(img => {
    if (img.hasAttribute(config.lazyAttribute) || img.hasAttribute(config.lazyBackgroundAttribute)) {
      state.processedImages.add(img);
      
      if (img.tagName.toLowerCase() === 'img') {
        loadImage(img);
      } else if (img.hasAttribute(config.lazyBackgroundAttribute)) {
        loadBackgroundImage(img);
      }
      
      // Désinscrire de l'observateur si nécessaire
      if (state.observer) {
        state.observer.unobserve(img);
      }
    }
  });
}

/**
 * Charge une image en remplaçant l'attribut src
 * @param {HTMLImageElement} img - Élément image
 */
function loadImage(img) {
  // Vérifier si une URL est définie
  const src = img.getAttribute(config.lazyAttribute);
  if (!src) {
    return;
  }
  
  // Éviter les multiples chargements pour un même élément
  if (state.loadingImages.has(img)) {
    return;
  }
  
  state.totalImages++;
  state.loadingImages.add(img);
  
  // Appliquer la classe de chargement
  img.classList.add(config.loadingClass);
  
  // Configurer les attributs supplémentaires si présents
  if (img.hasAttribute(config.srcsetAttribute)) {
    img.setAttribute('srcset', img.getAttribute(config.srcsetAttribute));
  }
  
  if (img.hasAttribute(config.sizesAttribute)) {
    img.setAttribute('sizes', img.getAttribute(config.sizesAttribute));
  }
  
  // Créer une image temporaire pour le préchargement
  const tempImage = new Image();
  let timeout;
  let retries = 0;
  
  // Définir un délai d'attente pour les images qui ne se chargent pas
  timeout = setTimeout(() => {
    if (retries < config.maxRetries) {
      retries++;
      console.log(`Retry loading image (${retries}/${config.maxRetries}): ${src}`);
      tempImage.src = src + (src.includes('?') ? '&' : '?') + `retry=${retries}`;
    } else {
      handleImageError(img, 'Timeout loading image');
    }
  }, config.loadTimeout);
  
  // Gestionnaire de chargement réussi
  tempImage.onload = function() {
    clearTimeout(timeout);
    applyLoadedImage(img, src);
  };
  
  // Gestionnaire d'erreur
  tempImage.onerror = function(error) {
    console.error('Error loading image:', src, error);
    
    if (retries < config.maxRetries) {
      retries++;
      console.log(`Retry loading image (${retries}/${config.maxRetries}): ${src}`);
      tempImage.src = src + (src.includes('?') ? '&' : '?') + `retry=${retries}`;
    } else {
      clearTimeout(timeout);
      handleImageError(img, error);
    }
  };
  
  // Déclencher le chargement
  tempImage.src = src;
}

/**
 * Applique l'image chargée à l'élément
 * @param {HTMLImageElement} img - Élément image
 * @param {string} src - URL de l'image
 */
function applyLoadedImage(img, src) {
  // Si l'image a une version basse qualité en placeholder,
  // attendre un peu avant de remplacer pour la transition
  if (img.hasAttribute(config.placeholderLowQuality)) {
    setTimeout(() => {
      performImageSwap(img, src);
    }, config.placeholderFadeDelay);
  } else {
    performImageSwap(img, src);
  }
}

/**
 * Effectue le remplacement de l'image
 * @param {HTMLImageElement} img - Élément image
 * @param {string} src - URL de l'image
 */
function performImageSwap(img, src) {
  // Définir la source
  img.setAttribute('src', src);
  
  // Retirer l'attribut de chargement paresseux
  img.removeAttribute(config.lazyAttribute);
  
  // Mettre à jour les classes
  img.classList.remove(config.loadingClass);
  img.classList.add(config.loadedClass);
  
  // Retirer de la liste des images en cours de chargement
  state.loadingImages.delete(img);
  state.loadedImages++;
  
  // Lancer un événement personnalisé pour notifier du chargement
  img.dispatchEvent(new CustomEvent('lazyloaded', {
    bubbles: true,
    detail: { element: img }
  }));
  
  // Notifier de la progression
  notifyProgress();
}

/**
 * Gère les erreurs de chargement d'image
 * @param {HTMLImageElement} img - Élément image
 * @param {Error|string} error - Erreur survenue
 */
function handleImageError(img, error) {
  console.warn('Failed to load image:', img.getAttribute(config.lazyAttribute), error);
  
  // Appliquer une classe d'erreur
  img.classList.remove(config.loadingClass);
  img.classList.add(config.errorClass);
  
  // Mettre un image placeholder d'erreur si disponible
  const fallbackSrc = img.getAttribute('data-error-src') || 
                       '/assets/images/placeholder-error.png';
  
  img.setAttribute('src', fallbackSrc);
  
  // Retirer de la liste des images en cours de chargement
  state.loadingImages.delete(img);
  state.failedImages++;
  
  // Lancer un événement personnalisé pour notifier de l'erreur
  img.dispatchEvent(new CustomEvent('lazyloadfailed', {
    bubbles: true,
    detail: { element: img, error }
  }));
  
  // Notifier de la progression
  notifyProgress();
}

/**
 * Charge une image d'arrière-plan
 * @param {HTMLElement} element - Élément avec arrière-plan
 */
function loadBackgroundImage(element) {
  // Vérifier si une URL est définie
  const src = element.getAttribute(config.lazyBackgroundAttribute);
  if (!src) {
    return;
  }
  
  // Éviter les multiples chargements pour un même élément
  if (state.loadingImages.has(element)) {
    return;
  }
  
  state.totalImages++;
  state.loadingImages.add(element);
  
  // Appliquer la classe de chargement
  element.classList.add(config.loadingClass);
  
  // Créer une image temporaire pour le préchargement
  const tempImage = new Image();
  let timeout;
  let retries = 0;
  
  // Définir un délai d'attente pour les images qui ne se chargent pas
  timeout = setTimeout(() => {
    if (retries < config.maxRetries) {
      retries++;
      tempImage.src = src + (src.includes('?') ? '&' : '?') + `retry=${retries}`;
    } else {
      handleBackgroundImageError(element, 'Timeout loading image');
    }
  }, config.loadTimeout);
  
  // Gestionnaire de chargement réussi
  tempImage.onload = function() {
    clearTimeout(timeout);
    applyLoadedBackgroundImage(element, src);
  };
  
  // Gestionnaire d'erreur
  tempImage.onerror = function(error) {
    if (retries < config.maxRetries) {
      retries++;
      tempImage.src = src + (src.includes('?') ? '&' : '?') + `retry=${retries}`;
    } else {
      clearTimeout(timeout);
      handleBackgroundImageError(element, error);
    }
  };
  
  // Déclencher le chargement
  tempImage.src = src;
}

/**
 * Applique l'image d'arrière-plan chargée à l'élément
 * @param {HTMLElement} element - Élément avec arrière-plan
 * @param {string} src - URL de l'image
 */
function applyLoadedBackgroundImage(element, src) {
  // Définir l'arrière-plan
  element.style.backgroundImage = `url(${src})`;
  
  // Retirer l'attribut de chargement paresseux
  element.removeAttribute(config.lazyBackgroundAttribute);
  
  // Mettre à jour les classes
  element.classList.remove(config.loadingClass);
  element.classList.add(config.loadedClass);
  
  // Retirer de la liste des images en cours de chargement
  state.loadingImages.delete(element);
  state.loadedImages++;
  
  // Lancer un événement personnalisé pour notifier du chargement
  element.dispatchEvent(new CustomEvent('lazyloaded', {
    bubbles: true,
    detail: { element }
  }));
  
  // Notifier de la progression
  notifyProgress();
}

/**
 * Gère les erreurs de chargement d'image d'arrière-plan
 * @param {HTMLElement} element - Élément avec arrière-plan
 * @param {Error|string} error - Erreur survenue
 */
function handleBackgroundImageError(element, error) {
  console.warn('Failed to load background image:', 
    element.getAttribute(config.lazyBackgroundAttribute), error);
  
  // Appliquer une classe d'erreur
  element.classList.remove(config.loadingClass);
  element.classList.add(config.errorClass);
  
  // Fallback à un fond d'erreur
  const fallbackSrc = element.getAttribute('data-error-bg') || 
                      '/assets/images/placeholder-bg-error.png';
  element.style.backgroundImage = `url(${fallbackSrc})`;
  
  // Retirer de la liste des images en cours de chargement
  state.loadingImages.delete(element);
  state.failedImages++;
  
  // Lancer un événement personnalisé pour notifier de l'erreur
  element.dispatchEvent(new CustomEvent('lazyloadfailed', {
    bubbles: true,
    detail: { element, error }
  }));
  
  // Notifier de la progression
  notifyProgress();
}

/**
 * Notifie de la progression du chargement des images
 */
function notifyProgress() {
  const progress = {
    total: state.totalImages,
    loaded: state.loadedImages,
    failed: state.failedImages,
    pending: state.totalImages - state.loadedImages - state.failedImages,
    percentage: state.totalImages > 0 
      ? Math.round((state.loadedImages / state.totalImages) * 100) 
      : 0
  };
  
  // Publier un événement de progression
  document.dispatchEvent(new CustomEvent('lazyload-progress', {
    detail: progress
  }));
  
  // Log de débogage (seulement pour les changements significatifs)
  if (progress.loaded % 5 === 0 || progress.loaded === progress.total) {
    console.log(`LazyLoad progress: ${progress.loaded}/${progress.total} (${progress.percentage}%)`);
  }
}

/**
 * Configure l'observateur de mutations pour les nouvelles images
 */
function setupMutationObserver() {
  if (!window.MutationObserver) {
    return;
  }
  
  const observer = new MutationObserver((mutations) => {
    let needsUpdate = false;
    
    mutations.forEach(mutation => {
      // Vérifier si des noeuds ont été ajoutés
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        needsUpdate = true;
      } else if (mutation.type === 'attributes' && 
                (mutation.attributeName === config.lazyAttribute || 
                 mutation.attributeName === config.lazyBackgroundAttribute)) {
        needsUpdate = true;
      }
    });
    
    if (needsUpdate) {
      // Mise à jour limitée pour ne pas surcharger
      debounce(lazyLoadImages, 100)();
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: [config.lazyAttribute, config.lazyBackgroundAttribute]
  });
}

/**
 * Configure un écouteur de défilement pour le fallback
 */
function setupScrollListener() {
  if (state.isObserverSupported) {
    return;
  }
  
  // Utiliser le défilement comme fallback pour les navigateurs anciens
  const scrollHandler = debounce(() => {
    const lazyElements = document.querySelectorAll(
      `[${config.lazyAttribute}], [${config.lazyBackgroundAttribute}]`
    );
    
    lazyElements.forEach(element => {
      if (isElementInViewport(element) && !state.processedImages.has(element)) {
        state.processedImages.add(element);
        
        if (element.tagName.toLowerCase() === 'img') {
          loadImage(element);
        } else {
          loadBackgroundImage(element);
        }
      }
    });
    
    // Si tous les éléments ont été chargés, supprimer l'écouteur
    if (document.querySelectorAll(
      `[${config.lazyAttribute}], [${config.lazyBackgroundAttribute}]`
    ).length === 0) {
      window.removeEventListener('scroll', scrollHandler);
    }
  }, 200);
  
  window.addEventListener('scroll', scrollHandler);
  window.addEventListener('resize', scrollHandler);
  window.addEventListener('orientationchange', scrollHandler);
}

/**
 * Configure un callback pour les périodes d'inactivité de l'utilisateur
 */
function setupUserIdleCallback() {
  if ('requestIdleCallback' in window) {
    const processRemainingImages = () => {
      const remainingElements = document.querySelectorAll(
        `[${config.lazyAttribute}], [${config.lazyBackgroundAttribute}]`
      );
      
      if (remainingElements.length > 0) {
        console.log(`Processing ${remainingElements.length} remaining images during idle time`);
        
        let index = 0;
        const processNext = (deadline) => {
          while (index < remainingElements.length && 
                (deadline.timeRemaining() > 0 || deadline.didTimeout)) {
            const element = remainingElements[index++];
            
            if (!state.processedImages.has(element)) {
              state.processedImages.add(element);
              
              if (element.tagName.toLowerCase() === 'img') {
                loadImage(element);
              } else {
                loadBackgroundImage(element);
              }
            }
          }
          
          if (index < remainingElements.length) {
            window.requestIdleCallback(processNext, { timeout: 1000 });
          }
        };
        
        window.requestIdleCallback(processNext, { timeout: 1000 });
      }
    };
    
    // Exécuter après un délai pour donner la priorité au contenu visible
    setTimeout(() => {
      window.requestIdleCallback(processRemainingImages, { timeout: 2000 });
    }, 5000);
  }
}

/**
 * Vérifie si un élément est visible dans le viewport
 * @param {HTMLElement} element - Élément à vérifier
 * @returns {boolean} - Vrai si l'élément est visible
 */
function isElementInViewport(element) {
  const rect = element.getBoundingClientRect();
  const margin = parseInt(config.rootMargin, 10) || 200;
  
  return (
    rect.bottom >= -margin &&
    rect.right >= -margin &&
    rect.top <= (window.innerHeight || document.documentElement.clientHeight) + margin &&
    rect.left <= (window.innerWidth || document.documentElement.clientWidth) + margin
  );
}

/**
 * Fonction principale pour charger paresseusement les images
 */
export function lazyLoadImages() {
  const lazyImages = document.querySelectorAll(`[${config.lazyAttribute}]`);
  const lazyBackgrounds = document.querySelectorAll(`[${config.lazyBackgroundAttribute}]`);
  
  // Traiter les images
  if (lazyImages.length > 0) {
    if (state.isObserverSupported && state.observer) {
      lazyImages.forEach(img => {
        if (!state.processedImages.has(img)) {
          state.observer.observe(img);
        }
      });
    } else {
      // Fallback pour les navigateurs qui ne supportent pas IntersectionObserver
      lazyImages.forEach(img => {
        if (!state.processedImages.has(img) && isElementInViewport(img)) {
          state.processedImages.add(img);
          loadImage(img);
        }
      });
    }
  }
  
  // Traiter les arrière-plans
  if (lazyBackgrounds.length > 0) {
    if (state.isObserverSupported && state.observer) {
      lazyBackgrounds.forEach(element => {
        if (!state.processedImages.has(element)) {
          state.observer.observe(element);
        }
      });
    } else {
      // Fallback pour les navigateurs qui ne supportent pas IntersectionObserver
      lazyBackgrounds.forEach(element => {
        if (!state.processedImages.has(element) && isElementInViewport(element)) {
          state.processedImages.add(element);
          loadBackgroundImage(element);
        }
      });
    }
  }
}

/**
 * Précharge immédiatement une image sans attendre qu'elle soit visible
 * @param {string} src - URL de l'image à précharger
 * @returns {Promise<HTMLImageElement>} - Promesse résolue lorsque l'image est chargée
 */
export function preloadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(e);
    
    img.src = src;
  });
}

/**
 * Limite la fréquence d'exécution d'une fonction
 * @param {Function} fn - Fonction à limiter
 * @param {number} delay - Délai en millisecondes
 * @returns {Function} - Fonction limitée
 */
function debounce(fn, delay) {
  let timer = null;
  
  return function() {
    const context = this;
    const args = arguments;
    
    clearTimeout(timer);
    
    timer = setTimeout(() => {
      fn.apply(context, args);
    }, delay);
  };
}

/**
 * Obtient les statistiques de chargement d'images
 * @returns {Object} - Statistiques
 */
export function getLazyLoadStats() {
  return {
    total: state.totalImages,
    loaded: state.loadedImages,
    failed: state.failedImages,
    pending: state.totalImages - state.loadedImages - state.failedImages,
    percentage: state.totalImages > 0 
      ? Math.round((state.loadedImages / state.totalImages) * 100) 
      : 0
  };
}

/**
 * Force le chargement de toutes les images paresseuses restantes
 */
export function loadAllLazyImages() {
  const lazyElements = document.querySelectorAll(
    `[${config.lazyAttribute}], [${config.lazyBackgroundAttribute}]`
  );
  
  console.log(`Forcing load of ${lazyElements.length} remaining lazy images`);
  
  lazyElements.forEach(element => {
    if (!state.processedImages.has(element)) {
      state.processedImages.add(element);
      
      if (element.tagName.toLowerCase() === 'img') {
        loadImage(element);
      } else {
        loadBackgroundImage(element);
      }
    }
  });
}

// Initialiser automatiquement lors de l'importation si document est disponible
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      initLazyLoad();
    });
  } else {
    initLazyLoad();
  }
}

// Exporter les fonctions
export default {
  initLazyLoad,
  lazyLoadImages,
  preloadImage,
  loadAllLazyImages,
  getLazyLoadStats
};
