// app/utils/i18n.js

/**
 * Module de gestion de l'internationalisation
 * Charge et gère les traductions pour différentes langues
 */

import { STORAGE_KEYS, SUPPORTED_LANGUAGES } from '../config/constants.js';

// État du module i18n
let currentLanguage = 'fr'; // Langue par défaut
let translations = {}; // Stocke les traductions chargées
let fallbackLanguage = 'en'; // Langue de secours
let isInitialized = false; // État d'initialisation

/**
 * Initialise le système d'internationalisation
 * @param {string} [lang] - Code de langue à utiliser
 * @returns {Promise<void>}
 */
export async function initI18n(lang) {
  try {
    // Déterminer la langue à utiliser
    const languageToUse = determineLanguage(lang);
    
    // Charger les traductions
    await loadLanguage(languageToUse);
    
    // Charger la langue de secours si différente
    if (languageToUse !== fallbackLanguage) {
      await loadLanguage(fallbackLanguage, true);
    }
    
    // Définir les attributs HTML pour la localisation
    document.documentElement.lang = languageToUse;
    document.documentElement.dir = getTextDirection(languageToUse);
    
    isInitialized = true;
    
    console.log(`Système i18n initialisé avec la langue: ${languageToUse}`);
  } catch (error) {
    console.error('Erreur lors de l\'initialisation du système i18n:', error);
    
    // Fallback aux traductions en ligne
    await loadFallbackTranslations();
  }
}

/**
 * Configure la langue à utiliser
 * @param {string} lang - Code de langue
 * @returns {Promise<boolean>} Succès du changement
 */
export async function setupLanguage(lang) {
  if (!lang || typeof lang !== 'string') {
    console.warn('Code de langue invalide fourni:', lang);
    return false;
  }
  
  // Vérifier si la langue est supportée
  if (!isLanguageSupported(lang)) {
    console.warn(`Langue non supportée: ${lang}`);
    return false;
  }
  
  try {
    // Charger les traductions si nécessaire
    if (lang !== currentLanguage || !translations[lang]) {
      await loadLanguage(lang);
    }
    
    // Mettre à jour la langue courante
    currentLanguage = lang;
    
    // Sauvegarder la préférence
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
    
    // Mettre à jour les attributs HTML
    document.documentElement.lang = lang;
    document.documentElement.dir = getTextDirection(lang);
    
    // Déclencher un événement pour notifier le changement de langue
    document.dispatchEvent(new CustomEvent('language-changed', { 
      detail: { language: lang } 
    }));
    
    return true;
  } catch (error) {
    console.error(`Erreur lors du changement de langue vers ${lang}:`, error);
    return false;
  }
}

/**
 * Détermine la langue à utiliser en fonction des préférences
 * @param {string} [preferredLanguage] - Langue préférée explicitement
 * @returns {string} Code de la langue à utiliser
 */
function determineLanguage(preferredLanguage) {
  // Priorité 1: Langue explicitement demandée
  if (preferredLanguage && isLanguageSupported(preferredLanguage)) {
    return preferredLanguage;
  }
  
  // Priorité 2: Langue stockée dans les préférences
  const storedLanguage = localStorage.getItem(STORAGE_KEYS.LANGUAGE);
  if (storedLanguage && isLanguageSupported(storedLanguage)) {
    return storedLanguage;
  }
  
  // Priorité 3: Langue du navigateur
  const browserLanguages = navigator.languages || [navigator.language];
  for (const lang of browserLanguages) {
    const mainLang = lang.split('-')[0]; // Extraire le code principal (fr-FR -> fr)
    if (isLanguageSupported(mainLang)) {
      return mainLang;
    }
  }
  
  // Priorité 4: Langue par défaut
  return currentLanguage;
}

/**
 * Vérifie si une langue est supportée
 * @param {string} lang - Code de langue
 * @returns {boolean} Vrai si la langue est supportée
 */
function isLanguageSupported(lang) {
  return Object.keys(SUPPORTED_LANGUAGES).includes(lang);
}

/**
 * Charge les traductions pour une langue donnée
 * @param {string} lang - Code de langue
 * @param {boolean} [isFallback=false] - Si c'est la langue de secours
 * @returns {Promise<void>}
 */
async function loadLanguage(lang, isFallback = false) {
  // Si les traductions sont déjà chargées pour cette langue
  if (translations[lang] && Object.keys(translations[lang]).length > 0) {
    return;
  }
  
  try {
    // Charger le fichier de traductions
    const response = await fetch(`/assets/locales/${lang}.json`);
    
    if (!response.ok) {
      throw new Error(`Erreur lors du chargement des traductions: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Stocker les traductions
    translations[lang] = data;
    
    if (!isFallback) {
      currentLanguage = lang;
    }
  } catch (error) {
    console.error(`Erreur lors du chargement des traductions pour ${lang}:`, error);
    
    if (!isFallback) {
      // Essayer de charger la langue de secours
      await loadLanguage(fallbackLanguage, true);
    } else {
      // Si même la langue de secours échoue, utiliser les traductions en ligne
      await loadFallbackTranslations();
    }
  }
}

/**
 * Charge les traductions de base en ligne (fallback ultime)
 * @returns {Promise<void>}
 */
async function loadFallbackTranslations() {
  // Définir un ensemble minimal de traductions en français et anglais
  translations = {
    fr: {
      'common.loading': 'Chargement...',
      'common.error': 'Erreur',
      'common.success': 'Succès',
      'common.confirm': 'Confirmer',
      'common.cancel': 'Annuler',
      'common.save': 'Enregistrer',
      'common.delete': 'Supprimer',
      'common.search': 'Rechercher',
      'cart.add': 'Ajouter au panier',
      'cart.remove': 'Retirer',
      'cart.empty': 'Votre panier est vide',
      'cart.checkout': 'Passer commande',
      'cart.total': 'Total',
      'cart.item_added': 'Produit ajouté au panier',
      'cart.item_removed': 'Produit retiré du panier',
      'cart.max_quantity_reached': 'Quantité maximale atteinte',
      'cart.too_many_items': 'Trop d\'articles dans le panier',
      'cart.confirm_clear': 'Voulez-vous vraiment vider votre panier?',
      'cart.restricted_item': 'Ce produit nécessite une vérification',
      'payment.connect_ton_wallet': 'Connecter portefeuille TON',
      'payment.ton_connected': 'Portefeuille TON connecté',
      'payment.connect': 'Connecter',
      'payment.connect_error': 'Erreur de connexion au portefeuille',
      'payment.btc_option': 'Payer avec Bitcoin',
      'verification.title': 'Vérification requise',
      'verification.enter_code': 'Entrez votre code d\'invitation',
      'verification.submit': 'Vérifier',
      'verification.invalid_code': 'Code d\'invitation invalide',
      'verification.error': 'Erreur lors de la vérification',
      'errors.initialization': 'Erreur d\'initialisation: ',
      'errors.network': 'Erreur réseau',
      'errors.server': 'Erreur serveur'
    },
    en: {
      'common.loading': 'Loading...',
      'common.error': 'Error',
      'common.success': 'Success',
      'common.confirm': 'Confirm',
      'common.cancel': 'Cancel',
      'common.save': 'Save',
      'common.delete': 'Delete',
      'common.search': 'Search',
      'cart.add': 'Add to cart',
      'cart.remove': 'Remove',
      'cart.empty': 'Your cart is empty',
      'cart.checkout': 'Checkout',
      'cart.total': 'Total',
      'cart.item_added': 'Product added to cart',
      'cart.item_removed': 'Product removed from cart',
      'cart.max_quantity_reached': 'Maximum quantity reached',
      'cart.too_many_items': 'Too many items in cart',
      'cart.confirm_clear': 'Do you really want to empty your cart?',
      'cart.restricted_item': 'This product requires verification',
      'payment.connect_ton_wallet': 'Connect TON wallet',
      'payment.ton_connected': 'TON wallet connected',
      'payment.connect': 'Connect',
      'payment.connect_error': 'Wallet connection error',
      'payment.btc_option': 'Pay with Bitcoin',
      'verification.title': 'Verification required',
      'verification.enter_code': 'Enter your invitation code',
      'verification.submit': 'Verify',
      'verification.invalid_code': 'Invalid invitation code',
      'verification.error': 'Verification error',
      'errors.initialization': 'Initialization error: ',
      'errors.network': 'Network error',
      'errors.server': 'Server error'
    }
  };
  
  console.warn('Utilisation des traductions de secours en ligne');
}

/**
 * Obtient la direction du texte pour une langue
 * @param {string} lang - Code de langue
 * @returns {string} Direction du texte ('ltr' ou 'rtl')
 */
function getTextDirection(lang) {
  // Liste des langues RTL (de droite à gauche)
  const rtlLanguages = ['ar', 'he', 'fa', 'ur'];
  return rtlLanguages.includes(lang) ? 'rtl' : 'ltr';
}

/**
 * Traduit une clé dans la langue actuelle
 * @param {string} key - Clé de traduction
 * @param {Object} [params] - Paramètres pour les substitutions
 * @returns {string} Texte traduit
 */
export function translate(key, params = {}) {
  // S'assurer que la clé est une chaîne
  if (!key || typeof key !== 'string') {
    console.warn('Clé de traduction invalide:', key);
    return '';
  }
  
  // Initialisation automatique si nécessaire
  if (!isInitialized) {
    console.warn('Système i18n non initialisé, initialisation automatique');
    initI18n();
  }
  
  try {
    // Récupérer la traduction
    let text = getTranslationValue(translations[currentLanguage], key);
    
    // Si pas trouvé, essayer la langue de secours
    if (!text && currentLanguage !== fallbackLanguage) {
      text = getTranslationValue(translations[fallbackLanguage], key);
    }
    
    // Si toujours pas trouvé, retourner la clé
    if (!text) {
      console.warn(`Traduction non trouvée pour la clé: ${key}`);
      return key;
    }
    
    // Substituer les paramètres
    return substituteParams(text, params);
  } catch (error) {
    console.error(`Erreur lors de la traduction de la clé ${key}:`, error);
    return key;
  }
}

/**
 * Récupère une valeur de traduction à partir d'une clé composite
 * @param {Object} translationObj - Objet de traductions
 * @param {string} key - Clé composite (ex: "cart.add")
 * @returns {string|null} Valeur de traduction ou null si non trouvé
 */
function getTranslationValue(translationObj, key) {
  if (!translationObj) return null;
  
  const parts = key.split('.');
  let current = translationObj;
  
  for (const part of parts) {
    if (current[part] === undefined) {
      return null;
    }
    current = current[part];
  }
  
  return typeof current === 'string' ? current : null;
}

/**
 * Substitue les paramètres dans une chaîne de traduction
 * @param {string} text - Texte avec placeholders
 * @param {Object} params - Paramètres pour substitution
 * @returns {string} Texte avec valeurs substituées
 */
function substituteParams(text, params) {
  // Si pas de paramètres, retourner le texte tel quel
  if (!params || Object.keys(params).length === 0) {
    return text;
  }
  
  // Remplacer les placeholders {{param}} par leurs valeurs
  return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
    return params[key] !== undefined ? params[key] : match;
  });
}

/**
 * Applique des traductions à tous les éléments avec data-i18n
 * @param {HTMLElement} [rootElement=document.body] - Élément racine
 */
export function translatePage(rootElement = document.body) {
  const elements = rootElement.querySelectorAll('[data-i18n]');
  
  elements.forEach(element => {
    const key = element.dataset.i18n;
    const params = {};
    
    // Chercher des attributs de paramètres (data-i18n-param-name)
    Object.keys(element.dataset).forEach(attrKey => {
      if (attrKey.startsWith('i18nParam')) {
        const paramName = attrKey.substring(9).toLowerCase(); // i18nParamName -> name
        params[paramName] = element.dataset[attrKey];
      }
    });
    
    // Traduire et appliquer
    element.textContent = translate(key, params);
  });
  
  // Traiter les placeholders
  const placeholders = rootElement.querySelectorAll('[data-i18n-placeholder]');
  placeholders.forEach(element => {
    const key = element.dataset.i18nPlaceholder;
    element.placeholder = translate(key);
  });
  
  // Traiter les titres
  const titles = rootElement.querySelectorAll('[data-i18n-title]');
  titles.forEach(element => {
    const key = element.dataset.i18nTitle;
    element.title = translate(key);
  });
  
  // Traiter les textes alternatifs
  const alts = rootElement.querySelectorAll('[data-i18n-alt]');
  alts.forEach(element => {
    const key = element.dataset.i18nAlt;
    element.alt = translate(key);
  });
}

/**
 * Formate une date selon la locale actuelle
 * @param {Date|string|number} date - Date à formater
 * @param {Object} [options] - Options de formatage
 * @returns {string} Date formatée
 */
export function formatDate(date, options = {}) {
  try {
    const dateObj = date instanceof Date ? date : new Date(date);
    
    // Options par défaut
    const defaultOptions = {
      dateStyle: 'medium'
    };
    
    // Fusionner avec les options fournies
    const formatOptions = { ...defaultOptions, ...options };
    
    // Obtenir le format de date du pays correspondant à la langue
    const locale = SUPPORTED_LANGUAGES[currentLanguage]?.dateFormat 
                   ? currentLanguage 
                   : fallbackLanguage;
                   
    return new Intl.DateTimeFormat(locale, formatOptions).format(dateObj);
  } catch (error) {
    console.error('Erreur lors du formatage de la date:', error);
    return String(date);
  }
}

/**
 * Formate un nombre selon la locale actuelle
 * @param {number} num - Nombre à formater
 * @param {Object} [options] - Options de formatage
 * @returns {string} Nombre formaté
 */
export function formatNumber(num, options = {}) {
  try {
    const locale = currentLanguage || fallbackLanguage;
    return new Intl.NumberFormat(locale, options).format(num);
  } catch (error) {
    console.error('Erreur lors du formatage du nombre:', error);
    return String(num);
  }
}

/**
 * Formate un prix avec devise
 * @param {number} amount - Montant
 * @param {string} [currency='USD'] - Code de devise
 * @returns {string} Prix formaté avec symbole de devise
 */
export function formatCurrency(amount, currency = 'USD') {
  return formatNumber(amount, { 
    style: 'currency', 
    currency: currency
  });
}

/**
 * Obtient la langue actuelle
 * @returns {string} Code de langue actuelle
 */
export function getCurrentLanguage() {
  return currentLanguage;
}

/**
 * Obtient la liste des langues supportées
 * @returns {Object} Liste des langues supportées
 */
export function getSupportedLanguages() {
  return { ...SUPPORTED_LANGUAGES };
}

// Exporter les fonctions principales
export default {
  initI18n,
  setupLanguage,
  translate,
  translatePage,
  formatDate,
  formatNumber,
  formatCurrency,
  getCurrentLanguage,
  getSupportedLanguages
};
