/**
 * Utilitaires pour les paiements dans ToolHack Pro
 * Fournit des fonctions pour faciliter les opérations de paiement
 */

import tonWallet from '../config/ton-wallet.js';
import { APP_CONFIG, ERROR_CODES } from '../config/constants.js';

export class PaymentUtils {
  constructor() {
    this.exchangeRates = {
      TON: 5.0,  // Valeur par défaut
      XMR: 170.0,
      BTC: 60000.0
    };
    this.lastRateUpdate = null;
  }
  
  /**
   * Met à jour les taux de change
   * @returns {Promise<Object>} - Taux mis à jour
   */
  async updateExchangeRates() {
    try {
      // Vérifier si une mise à jour a été faite récemment
      if (this.lastRateUpdate && (Date.now() - this.lastRateUpdate) < 30 * 60 * 1000) {
        return this.exchangeRates;
      }
      
      const response = await fetch(`${APP_CONFIG.API_BASE_URL}/exchange-rates`);
      
      if (!response.ok) {
        throw new Error(`Exchange rate API error: ${response.status}`);
      }
      
      const data = await response.json();
      
      this.exchangeRates = {
        TON: data.TON?.USD || 5.0,
        XMR: data.XMR?.USD || 170.0,
        BTC: data.BTC?.USD || 60000.0
      };
      
      this.lastRateUpdate = Date.now();
      
      return this.exchangeRates;
    } catch (error) {
      console.error('Failed to fetch exchange rates:', error);
      
      // Si c'est la première fois et qu'il n'y a pas de taux
      if (!this.lastRateUpdate) {
        this.lastRateUpdate = Date.now();
      }
      
      throw error;
    }
  }
  
  /**
   * Convertit un montant entre différentes monnaies
   * @param {number} amount - Montant à convertir
   * @param {string} fromCurrency - Devise source
   * @param {string} toCurrency - Devise cible
   * @returns {number} - Montant converti
   */
  convertAmount(amount, fromCurrency, toCurrency) {
    if (fromCurrency === toCurrency) {
      return amount;
    }
    
    // Si les devises sont les mêmes, retourner le montant
    if (fromCurrency === toCurrency) {
      return amount;
    }
    
    // Vérifier si les taux existent
    if (!this.exchangeRates[fromCurrency] || !this.exchangeRates[toCurrency]) {
      console.error('Exchange rates not available for', fromCurrency, 'or', toCurrency);
      return 0;
    }
    
    // Convertir via USD
    const amountInUSD = amount * this.exchangeRates[fromCurrency];
    return amountInUSD / this.exchangeRates[toCurrency];
  }
  
  /**
   * Formate un montant en crypto avec la précision appropriée
   * @param {number} amount - Montant à formater
   * @param {string} currency - Devise (TON, XMR, BTC)
   * @returns {string} - Montant formaté
   */
  formatCryptoAmount(amount, currency) {
    switch (currency) {
      case 'TON':
        return amount.toFixed(2);
      case 'XMR':
        return amount.toFixed(6);
      case 'BTC':
        return amount.toFixed(8);
      default:
        return amount.toString();
    }
  }
  
  /**
   * Génère un ID de commande unique
   * @returns {string} - ID de commande
   */
  generateOrderId() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `THP-${timestamp}-${random}`;
  }
  
  /**
   * Génère un ID de paiement unique
   * @returns {string} - ID de paiement
   */
  generatePaymentId() {
    return 'pay_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  }
  
  /**
   * Prépare les données pour le paiement TON
   * @param {number} amount - Montant en TON
   * @param {string} orderId - ID de commande
   * @returns {Object} - Données de paiement
   */
  prepareTonPayment(amount, orderId) {
    const comment = `Order: ${orderId}`;
    const paymentUrl = tonWallet.generatePaymentUrl(amount, comment);
    
    return {
      url: paymentUrl,
      amount,
      currency: 'TON',
      orderId,
      comment,
      timestamp: new Date().toISOString()
    };
  }
  
  /**
   * Vérifie si le paiement TON est disponible
   * @returns {boolean} - Disponibilité du paiement TON
   */
  isTonPaymentAvailable() {
    return tonWallet.isPaymentAvailable();
  }
  
  /**
   * Analyse et traite une erreur de paiement
   * @param {Error|string} error - Erreur à traiter
   * @returns {Object} - Informations sur l'erreur
   */
  parsePaymentError(error) {
    let errorCode = ERROR_CODES.PAYMENT.UNKNOWN_ERROR;
    let errorMessage = 'An unknown payment error occurred';
    
    if (typeof error === 'string') {
      // Détecter les codes d'erreur courants dans le message
      if (error.includes('network') || error.includes('connection')) {
        errorCode = ERROR_CODES.PAYMENT.NETWORK_ERROR;
        errorMessage = 'A network error occurred during payment';
      } else if (error.includes('insufficient') || error.includes('funds')) {
        errorCode = ERROR_CODES.PAYMENT.INSUFFICIENT_FUNDS;
        errorMessage = 'Insufficient funds to complete the payment';
      } else if (error.includes('cancel') || error.includes('cancelled')) {
        errorCode = ERROR_CODES.PAYMENT.USER_CANCELLED;
        errorMessage = 'Payment was cancelled by the user';
      } else if (error.includes('timeout')) {
        errorCode = ERROR_CODES.PAYMENT.TIMEOUT;
        errorMessage = 'Payment process timed out';
      }
    } else if (error && error.code) {
      // Utiliser le code d'erreur s'il existe
      errorCode = error.code;
      errorMessage = error.message || errorMessage;
    }
    
    return {
      code: errorCode,
      message: errorMessage,
      timestamp: new Date().toISOString(),
      originalError: error
    };
  }
  
  /**
   * Calcule les frais de livraison en fonction du pays et de la méthode
   * @param {string} country - Code pays
   * @param {string} method - Méthode de livraison
   * @returns {number} - Frais de livraison en TON
   */
  calculateShippingFee(country, method) {
    const baseRates = {
      standard: 15,
      express: 30,
      stealth: 45
    };
    
    const countryMultipliers = {
      us: 1.0,
      ca: 1.1,
      gb: 1.2,
      fr: 1.2,
      de: 1.2,
      nl: 1.2,
      ch: 1.3,
      au: 1.5,
      nz: 1.6
    };
    
    const baseRate = baseRates[method] || baseRates.standard;
    const multiplier = countryMultipliers[country.toLowerCase()] || 1.4;
    
    return Math.round(baseRate * multiplier * 100) / 100;
  }
}

export default new PaymentUtils();
