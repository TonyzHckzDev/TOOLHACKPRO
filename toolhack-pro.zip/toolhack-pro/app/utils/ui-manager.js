// app/utils/ui-manager.js

/**
 * Gestionnaire d'interface utilisateur
 * Gère les notifications, modals, spinners et autres éléments d'UI dynamiques
 */

import { NOTIFICATION_TYPES, NOTIFICATION_DURATION } from '../config/constants.js';
import { translate } from './i18n.js';
import { trackEvent } from '../services/analytics.js';
import { hapticFeedback } from './telegram-api.js';

// État du module
const uiState = {
  activeModals: [],
  activeToasts: new Map(),
  activeLoaders: new Map(),
  toastContainer: null,
  modalContainer: null,
  portalContainer: null,
  lastZIndex: 1000,
  transitionDuration: 300,
  inAnimation: false,
  eventListeners: new Map()
};

/**
 * Initialise le gestionnaire d'UI
 * @returns {Promise<void>}
 */
export async function initUIManager() {
  // Créer les conteneurs nécessaires s'ils n'existent pas
  createContainers();
  
  // Configurer les écouteurs globaux
  setupGlobalListeners();
  
  console.log('UI Manager initialized');
}

/**
 * Crée les conteneurs nécessaires pour les éléments d'UI
 */
function createContainers() {
  // Conteneur pour les toasts/notifications
  if (!uiState.toastContainer) {
    const toastContainer = document.getElementById('notification-container');
    if (toastContainer) {
      uiState.toastContainer = toastContainer;
    } else {
      uiState.toastContainer = document.createElement('div');
      uiState.toastContainer.id = 'notification-container';
      uiState.toastContainer.className = 'notification-container';
      document.body.appendChild(uiState.toastContainer);
    }
  }
  
  // Conteneur pour les modals
  if (!uiState.modalContainer) {
    const modalContainer = document.getElementById('modal-container');
    if (modalContainer) {
      uiState.modalContainer = modalContainer;
    } else {
      uiState.modalContainer = document.createElement('div');
      uiState.modalContainer.id = 'modal-container';
      uiState.modalContainer.className = 'modal-container';
      document.body.appendChild(uiState.modalContainer);
    }
  }
  
  // Conteneur pour les portals (éléments qui doivent être montés en dehors de leur contexte)
  if (!uiState.portalContainer) {
    const portalContainer = document.getElementById('portal-container');
    if (portalContainer) {
      uiState.portalContainer = portalContainer;
    } else {
      uiState.portalContainer = document.createElement('div');
      uiState.portalContainer.id = 'portal-container';
      uiState.portalContainer.className = 'portal-container';
      document.body.appendChild(uiState.portalContainer);
    }
  }
}

/**
 * Configure les écouteurs d'événements globaux
 */
function setupGlobalListeners() {
  // Écouteur pour la touche Escape pour fermer les modals
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && uiState.activeModals.length > 0) {
      const topModalId = uiState.activeModals[uiState.activeModals.length - 1];
      const modal = document.getElementById(topModalId);
      
      if (modal && modal.dataset.closeOnEscape === 'true') {
        closeModal(topModalId);
      }
    }
  });
  
  // Observer le redimensionnement pour repositionner les éléments
  window.addEventListener('resize', debounce(() => {
    // Repositionner les toasts
    if (uiState.activeToasts.size > 0) {
      repositionToasts();
    }
    
    // Repositionner les modals centrés
    if (uiState.activeModals.length > 0) {
      repositionModals();
    }
  }, 200));
}

/**
 * Affiche une notification/toast
 * @param {string} message - Message à afficher
 * @param {string} [type='info'] - Type de notification (success, error, warning, info)
 * @param {Object} [options={}] - Options supplémentaires
 * @returns {string} - ID de la notification
 */
export function showNotification(message, type = 'info', options = {}) {
  // Valider le type
  if (!Object.values(NOTIFICATION_TYPES).includes(type)) {
    type = NOTIFICATION_TYPES.INFO;
  }
  
  // Fusionner les options avec les valeurs par défaut
  const defaultOptions = {
    duration: NOTIFICATION_DURATION.MEDIUM,
    closable: true,
    position: 'bottom-right',
    icon: true,
    onClose: null
  };
  
  const settings = { ...defaultOptions, ...options };
  
  // Générer un ID unique
  const notificationId = `notification-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  
  // Créer l'élément de notification
  const notificationElement = document.createElement('div');
  notificationElement.id = notificationId;
  notificationElement.className = `notification notification-${type}`;
  notificationElement.setAttribute('role', 'alert');
  notificationElement.dataset.position = settings.position;
  
  // Contenu HTML de la notification
  let iconHtml = '';
  if (settings.icon) {
    switch (type) {
      case NOTIFICATION_TYPES.SUCCESS:
        iconHtml = '<i class="fa-solid fa-check-circle notification-icon"></i>';
        break;
      case NOTIFICATION_TYPES.WARNING:
        iconHtml = '<i class="fa-solid fa-exclamation-triangle notification-icon"></i>';
        break;
      case NOTIFICATION_TYPES.ERROR:
        iconHtml = '<i class="fa-solid fa-times-circle notification-icon"></i>';
        break;
      default: // INFO
        iconHtml = '<i class="fa-solid fa-info-circle notification-icon"></i>';
    }
  }
  
  notificationElement.innerHTML = `
    <div class="notification-content">
      ${iconHtml}
      <div class="notification-message">${message}</div>
      ${settings.closable ? '<button class="notification-close" aria-label="Close">&times;</button>' : ''}
    </div>
    ${settings.duration > 0 ? '<div class="notification-progress"></div>' : ''}
  `;
  
  // Ajouter la notification au conteneur
  uiState.toastContainer.appendChild(notificationElement);
  
  // Définir la position z-index
  notificationElement.style.zIndex = getNextZIndex();
  
  // Configurer les événements
  if (settings.closable) {
    const closeButton = notificationElement.querySelector('.notification-close');
    if (closeButton) {
      closeButton.addEventListener('click', () => {
        closeNotification(notificationId);
      });
    }
  }
  
  // Ajouter l'animation d'entrée
  requestAnimationFrame(() => {
    notificationElement.classList.add('notification-visible');
    
    // Configurer la barre de progression si une durée est définie
    if (settings.duration > 0) {
      const progressBar = notificationElement.querySelector('.notification-progress');
      if (progressBar) {
        progressBar.style.animationDuration = `${settings.duration}ms`;
        progressBar.classList.add('notification-progress-active');
      }
      
      // Fermer automatiquement après la durée spécifiée
      setTimeout(() => {
        if (uiState.activeToasts.has(notificationId)) {
          closeNotification(notificationId);
        }
      }, settings.duration);
    }
  });
  
  // Retour haptique pour les appareils mobiles
  if (type === NOTIFICATION_TYPES.SUCCESS) {
    hapticFeedback('success');
  } else if (type === NOTIFICATION_TYPES.ERROR) {
    hapticFeedback('error');
  } else {
    hapticFeedback('medium');
  }
  
  // Stocker l'état de la notification
  uiState.activeToasts.set(notificationId, {
    type,
    message,
    element: notificationElement,
    position: settings.position,
    onClose: settings.onClose
  });
  
  // Repositionner les toasts
  repositionToasts();
  
  // Analytique
  trackEvent('notification_shown', {
    type,
    position: settings.position,
    closable: settings.closable
  });
  
  return notificationId;
}

/**
 * Ferme une notification spécifique
 * @param {string} notificationId - ID de la notification à fermer
 * @returns {boolean} - Succès de l'opération
 */
export function closeNotification(notificationId) {
  // Vérifier si la notification existe
  if (!uiState.activeToasts.has(notificationId)) {
    return false;
  }
  
  const notification = uiState.activeToasts.get(notificationId);
  const element = notification.element;
  
  if (!element) {
    uiState.activeToasts.delete(notificationId);
    return false;
  }
  
  // Ajouter l'animation de sortie
  element.classList.remove('notification-visible');
  element.classList.add('notification-hiding');
  
  // Supprimer après la fin de l'animation
  setTimeout(() => {
    if (element.parentNode) {
      element.parentNode.removeChild(element);
    }
    
    // Appeler le callback onClose si défini
    if (notification.onClose && typeof notification.onClose === 'function') {
      notification.onClose();
    }
    
    // Supprimer de la liste des notifications actives
    uiState.activeToasts.delete(notificationId);
    
    // Repositionner les notifications restantes
    repositionToasts();
  }, uiState.transitionDuration);
  
  return true;
}

/**
 * Repositionne toutes les notifications actives
 */
function repositionToasts() {
  // Grouper les notifications par position
  const positionGroups = {};
  
  uiState.activeToasts.forEach((notification, id) => {
    const position = notification.position || 'bottom-right';
    
    if (!positionGroups[position]) {
      positionGroups[position] = [];
    }
    
    positionGroups[position].push({
      id,
      element: notification.element
    });
  });
  
  // Traiter chaque groupe de position
  Object.entries(positionGroups).forEach(([position, notifications]) => {
    // Trier les notifications par ID (approximativement par ordre de création)
    notifications.sort((a, b) => a.id.localeCompare(b.id));
    
    // Calcul du décalage
    let offset = 16; // Marge initiale
    
    notifications.forEach((notification) => {
      const element = notification.element;
      
      // Positionner l'élément selon sa position
      switch (position) {
        case 'top-left':
          element.style.top = `${offset}px`;
          element.style.left = '16px';
          element.style.right = 'auto';
          element.style.bottom = 'auto';
          break;
        case 'top-center':
          element.style.top = `${offset}px`;
          element.style.left = '50%';
          element.style.right = 'auto';
          element.style.bottom = 'auto';
          element.style.transform = 'translateX(-50%)';
          break;
        case 'top-right':
          element.style.top = `${offset}px`;
          element.style.right = '16px';
          element.style.left = 'auto';
          element.style.bottom = 'auto';
          break;
        case 'bottom-left':
          element.style.bottom = `${offset}px`;
          element.style.left = '16px';
          element.style.right = 'auto';
          element.style.top = 'auto';
          break;
        case 'bottom-center':
          element.style.bottom = `${offset}px`;
          element.style.left = '50%';
          element.style.right = 'auto';
          element.style.top = 'auto';
          element.style.transform = 'translateX(-50%)';
          break;
        case 'bottom-right':
        default:
          element.style.bottom = `${offset}px`;
          element.style.right = '16px';
          element.style.left = 'auto';
          element.style.top = 'auto';
          break;
      }
      
      // Mettre à jour l'offset pour la prochaine notification
      offset += element.offsetHeight + 8; // hauteur + marge entre les notifications
    });
  });
}

/**
 * Affiche une boîte de dialogue modale
 * @param {string|HTMLElement} content - Contenu HTML ou élément DOM
 * @param {Object} [options={}] - Options de configuration
 * @returns {string} - ID du modal
 */
export function showModal(content, options = {}) {
  // Fusionner les options avec les valeurs par défaut
  const defaultOptions = {
    title: '',
    size: 'medium', // small, medium, large, fullscreen, auto
    position: 'center', // center, top, bottom
    closable: true,
    closeOnEscape: true,
    closeOnOverlayClick: true,
    showOverlay: true,
    scrollable: true,
    animation: 'fade', // fade, slide-up, slide-down, none
    zIndex: null,
    onOpen: null,
    onClose: null,
    className: '',
    buttons: [],
    preventBodyScroll: true
  };
  
  const settings = { ...defaultOptions, ...options };
  
  // Générer un ID unique
  const modalId = `modal-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  
  // Créer l'élément modal
  const modalElement = document.createElement('div');
  modalElement.id = modalId;
  modalElement.className = `modal-wrapper ${settings.showOverlay ? 'with-overlay' : ''} position-${settings.position} ${settings.className}`;
  modalElement.setAttribute('role', 'dialog');
  modalElement.setAttribute('aria-modal', 'true');
  if (settings.title) {
    modalElement.setAttribute('aria-labelledby', `${modalId}-title`);
  }
  
  // Définir les données
  modalElement.dataset.size = settings.size;
  modalElement.dataset.animation = settings.animation;
  modalElement.dataset.closeOnEscape = settings.closeOnEscape ? 'true' : 'false';
  modalElement.dataset.closeOnOverlayClick = settings.closeOnOverlayClick ? 'true' : 'false';
  
  // Construire la structure du modal
  let headerHtml = '';
  if (settings.title || settings.closable) {
    headerHtml = `
      <div class="modal-header">
        ${settings.title ? `<h3 class="modal-title" id="${modalId}-title">${settings.title}</h3>` : ''}
        ${settings.closable ? '<button type="button" class="modal-close" aria-label="Close">&times;</button>' : ''}
      </div>
    `;
  }
  
  let footerHtml = '';
  if (settings.buttons && settings.buttons.length > 0) {
    const buttonsHtml = settings.buttons.map(btn => {
      const buttonClasses = ['modal-button', btn.className || ''].join(' ').trim();
      const buttonType = btn.type || 'button';
      const buttonId = btn.id ? `id="${btn.id}"` : '';
      
      return `<button type="${buttonType}" class="${buttonClasses}" ${buttonId} data-action="${btn.action || ''}">${btn.text}</button>`;
    }).join('');
    
    footerHtml = `<div class="modal-footer">${buttonsHtml}</div>`;
  }
  
  // Assembler la structure
  modalElement.innerHTML = `
    <div class="modal modal-${settings.size} ${settings.scrollable ? 'modal-scrollable' : ''}">
      ${headerHtml}
      <div class="modal-content">
        <div class="modal-body"></div>
      </div>
      ${footerHtml}
    </div>
  `;
  
  // Insérer le contenu
  const contentContainer = modalElement.querySelector('.modal-body');
  if (typeof content === 'string') {
    contentContainer.innerHTML = content;
  } else if (content instanceof HTMLElement) {
    contentContainer.appendChild(content);
  }
  
  // Gérer le z-index
  const zIndex = settings.zIndex || getNextZIndex();
  modalElement.style.zIndex = zIndex;
  
  // Ajouter le modal au DOM
  uiState.modalContainer.appendChild(modalElement);
  
  // Empêcher le défilement du body si nécessaire
  if (settings.preventBodyScroll && uiState.activeModals.length === 0) {
    document.body.classList.add('modal-open');
  }
  
  // Ajouter à la liste des modals actifs
  uiState.activeModals.push(modalId);
  
  // Configurer les gestionnaires d'événements
  if (settings.closable) {
    const closeButton = modalElement.querySelector('.modal-close');
    if (closeButton) {
      closeButton.addEventListener('click', () => {
        closeModal(modalId);
      });
    }
  }
  
  if (settings.closeOnOverlayClick && settings.showOverlay) {
    modalElement.addEventListener('click', (event) => {
      if (event.target === modalElement) {
        closeModal(modalId);
      }
    });
  }
  
  // Configurer les boutons
  const buttonElements = modalElement.querySelectorAll('.modal-button');
  buttonElements.forEach((button) => {
    const actionName = button.dataset.action;
    
    if (actionName) {
      button.addEventListener('click', () => {
        // Trouver l'action correspondante
        const buttonConfig = settings.buttons.find(b => b.action === actionName);
        
        if (buttonConfig && buttonConfig.onClick) {
          // Exécuter le callback
          buttonConfig.onClick();
        }
        
        // Fermer le modal si nécessaire
        if (buttonConfig && buttonConfig.closeModal) {
          closeModal(modalId);
        }
      });
    }
  });
  
  // Activer l'animation d'entrée
  requestAnimationFrame(() => {
    uiState.inAnimation = true;
    modalElement.classList.add('modal-visible');
    
    // Exécuter le callback onOpen
    if (settings.onOpen && typeof settings.onOpen === 'function') {
      settings.onOpen(modalId, modalElement);
    }
    
    // Terminer l'animation
    setTimeout(() => {
      uiState.inAnimation = false;
    }, uiState.transitionDuration);
  });
  
  // Analytique
  trackEvent('modal_shown', {
    size: settings.size,
    position: settings.position,
    hasButtons: settings.buttons.length > 0
  });
  
  return modalId;
}

/**
 * Ferme une boîte de dialogue modale
 * @param {string} modalId - ID du modal à fermer
 * @returns {boolean} - Succès de l'opération
 */
export function closeModal(modalId) {
  // Vérifier si le modal existe
  const modalIndex = uiState.activeModals.indexOf(modalId);
  if (modalIndex === -1) {
    return false;
  }
  
  const modalElement = document.getElementById(modalId);
  if (!modalElement) {
    // Nettoyer l'état même si l'élément n'existe plus
    uiState.activeModals = uiState.activeModals.filter(id => id !== modalId);
    return false;
  }
  
  // Ne pas fermer pendant une animation
  if (uiState.inAnimation) {
    return false;
  }
  
  // Récupérer le callback onClose
  const onClose = modalElement.dataset.onClose;
  
  // Démarrer l'animation de sortie
  modalElement.classList.remove('modal-visible');
  modalElement.classList.add('modal-hiding');
  
  // Marquer comme en animation
  uiState.inAnimation = true;
  
  // Supprimer après la fin de l'animation
  setTimeout(() => {
    // Supprimer du DOM
    if (modalElement.parentNode) {
      modalElement.parentNode.removeChild(modalElement);
    }
    
    // Supprimer de la liste des modals actifs
    uiState.activeModals = uiState.activeModals.filter(id => id !== modalId);
    
    // Réactiver le défilement du body si nécessaire
    if (uiState.activeModals.length === 0) {
      document.body.classList.remove('modal-open');
    }
    
    // Exécuter le callback onClose
    if (onClose && typeof window[onClose] === 'function') {
      window[onClose](modalId);
    }
    
    // Terminer l'animation
    uiState.inAnimation = false;
  }, uiState.transitionDuration);
  
  return true;
}

/**
 * Repositionne tous les modals actifs
 */
function repositionModals() {
  uiState.activeModals.forEach(modalId => {
    const modal = document.getElementById(modalId);
    if (modal && modal.dataset.position === 'center') {
      const modalContent = modal.querySelector('.modal');
      if (modalContent) {
        // Centrer le modal
        const windowHeight = window.innerHeight;
        const modalHeight = modalContent.offsetHeight;
        
        if (modalHeight < windowHeight) {
          modalContent.style.top = `${Math.max(0, (windowHeight - modalHeight) / 2)}px`;
        } else {
          modalContent.style.top = '0';
        }
      }
    }
  });
}

/**
 * Affiche une boîte de dialogue de confirmation
 * @param {string} message - Message à afficher
 * @param {Object} [options={}] - Options de configuration
 * @returns {Promise<boolean>} - Résolution avec la réponse de l'utilisateur
 */
export function showConfirm(message, options = {}) {
  return new Promise((resolve) => {
    // Fusionner les options
    const defaultOptions = {
      title: translate('ui.confirm_title'),
      confirmText: translate('ui.confirm'),
      cancelText: translate('ui.cancel'),
      confirmClass: 'button-primary',
      cancelClass: 'button-secondary',
      icon: 'question', // question, warning, info, error, success, none
      size: 'small'
    };
    
    const settings = { ...defaultOptions, ...options };
    
    // Préparer le contenu
    let iconHtml = '';
    if (settings.icon !== 'none') {
      const iconClass = getIconClass(settings.icon);
      iconHtml = `<div class="modal-icon ${settings.icon}"><i class="${iconClass}"></i></div>`;
    }
    
    const content = `
      <div class="confirm-dialog">
        ${iconHtml}
        <p class="confirm-message">${message}</p>
      </div>
    `;
    
    // Afficher le modal
    showModal(content, {
      title: settings.title,
      size: settings.size,
      closable: true,
      closeOnEscape: true,
      closeOnOverlayClick: true,
      buttons: [
        {
          text: settings.cancelText,
          className: settings.cancelClass,
          action: 'cancel',
          onClick: () => resolve(false),
          closeModal: true
        },
        {
          text: settings.confirmText,
          className: settings.confirmClass,
          action: 'confirm',
          onClick: () => resolve(true),
          closeModal: true
        }
      ]
    });
    
    // Feedback tactile
    hapticFeedback('medium');
  });
}

/**
 * Affiche une boîte de dialogue de prompt
 * @param {string} message - Message à afficher
 * @param {string} [defaultValue=''] - Valeur par défaut
 * @param {Object} [options={}] - Options de configuration
 * @returns {Promise<string|null>} - Résolution avec la valeur saisie ou null si annulé
 */
export function showPrompt(message, defaultValue = '', options = {}) {
  return new Promise((resolve) => {
    // Fusionner les options
    const defaultOptions = {
      title: translate('ui.prompt_title'),
      confirmText: translate('ui.confirm'),
      cancelText: translate('ui.cancel'),
      placeholder: '',
      inputType: 'text',
      validator: null
    };
    
    const settings = { ...defaultOptions, ...options };
    
    // Créer un ID unique pour l'input
    const inputId = `prompt-input-${Date.now()}`;
    
    // Préparer le contenu
    const content = `
      <div class="prompt-dialog">
        <p class="prompt-message">${message}</p>
        <div class="form-group">
          <input type="${settings.inputType}" id="${inputId}" class="input-field" 
                 value="${defaultValue}" placeholder="${settings.placeholder}">
          <div class="input-error" id="${inputId}-error"></div>
        </div>
      </div>
    `;
    
    // Variable pour stocker l'ID du modal
    let modalId = null;
    
    // Fonction de validation
    const validateInput = () => {
      const input = document.getElementById(inputId);
      const value = input.value;
      
      // Exécuter le validateur si fourni
      if (settings.validator && typeof settings.validator === 'function') {
        const validationResult = settings.validator(value);
        
        if (validationResult !== true) {
          // Afficher l'erreur
          const errorElement = document.getElementById(`${inputId}-error`);
          if (errorElement) {
            errorElement.textContent = typeof validationResult === 'string' 
              ? validationResult 
              : translate('ui.validation_error');
            errorElement.style.display = 'block';
          }
          
          input.classList.add('input-invalid');
          input.focus();
          return false;
        }
      }
      
      return true;
    };
    
    // Afficher le modal
    modalId = showModal(content, {
      title: settings.title,
      size: 'small',
      closable: true,
      closeOnEscape: true,
      closeOnOverlayClick: false,
      buttons: [
        {
          text: settings.cancelText,
          className: 'button-secondary',
          action: 'cancel',
          onClick: () => resolve(null),
          closeModal: true
        },
        {
          text: settings.confirmText,
          className: 'button-primary',
          action: 'confirm',
          onClick: () => {
            if (validateInput()) {
              const input = document.getElementById(inputId);
              resolve(input.value);
              closeModal(modalId);
            }
          },
          closeModal: false
        }
      ],
      onOpen: () => {
        // Focus sur l'input
        setTimeout(() => {
          const input = document.getElementById(inputId);
          if (input) {
            input.focus();
            
            // Sélectionner le texte
            input.select();
            
            // Configurer la soumission avec Enter
            input.addEventListener('keydown', (event) => {
              if (event.key === 'Enter') {
                event.preventDefault();
                if (validateInput()) {
                  resolve(input.value);
                  closeModal(modalId);
                }
              }
            });
          }
        }, 100);
      }
    });
  });
}

/**
 * Affiche un indicateur de chargement
 * @param {string|HTMLElement} [target=document.body] - Élément cible
 * @param {Object} [options={}] - Options de configuration
 * @returns {string} - ID du loader
 */
export function showLoader(target = document.body, options = {}) {
  // Fusionner les options
  const defaultOptions = {
    message: translate('ui.loading'),
    size: 'medium', // small, medium, large
    overlay: true,
    spinnerType: 'circle', // circle, dots, bars
    cancelable: false,
    onCancel: null
  };
  
  const settings = { ...defaultOptions, ...options };
  
  // Générer un ID unique
  const loaderId = `loader-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  
  // Déterminer l'élément cible
  const targetElement = typeof target === 'string' ? document.querySelector(target) : target;
  
  if (!targetElement) {
    console.error('Target element for loader not found');
    return null;
  }
  
  // Créer l'élément loader
  const loaderElement = document.createElement('div');
  loaderElement.id = loaderId;
  loaderElement.className = `loader-container size-${settings.size} ${settings.overlay ? 'with-overlay' : ''}`;
  
  // Préparer le HTML du spinner selon le type
  let spinnerHtml = '';
  switch (settings.spinnerType) {
    case 'dots':
      spinnerHtml = '<div class="loader-dots"><div></div><div></div><div></div></div>';
      break;
    case 'bars':
      spinnerHtml = '<div class="loader-bars"><div></div><div></div><div></div><div></div><div></div></div>';
      break;
    case 'circle':
    default:
      spinnerHtml = '<div class="loader-circle"></div>';
  }
  
  // Assembler le contenu
  loaderElement.innerHTML = `
    <div class="loader-content">
      ${spinnerHtml}
      ${settings.message ? `<div class="loader-message">${settings.message}</div>` : ''}
      ${settings.cancelable ? '<button class="loader-cancel">' + translate('ui.cancel') + '</button>' : ''}
    </div>
  `;
  
  // Ajouter à l'élément cible
  targetElement.appendChild(loaderElement);
  
  // Ajouter une classe à la cible si c'est un élément relatif
  const computedStyle = window.getComputedStyle(targetElement);
  if (computedStyle.position === 'static') {
    targetElement.classList.add('loader-container');
  }
  
  // Création du conteneur de loader
  const loaderContainer = document.createElement('div');
  loaderContainer.className = 'app-loader-container';
  
  // Création de l'élément loader
  const loader = document.createElement('div');
  loader.className = 'app-loader';
  
  // Ajout du loader dans son conteneur
  loaderContainer.appendChild(loader);
  
  // Ajout du conteneur dans la cible
  targetElement.appendChild(loaderContainer);
  
  return {
    remove: function() {
      // Supprimer le loader quand nécessaire
      if (targetElement.contains(loaderContainer)) {
        targetElement.removeChild(loaderContainer);
      }
      // Supprimer la classe ajoutée si elle a été ajoutée
      if (computedStyle.position === 'static') {
        targetElement.classList.remove('loader-container');
      }
    }
  };
}

/**
 * Gère l'affichage des messages d'information à l'utilisateur
 * @param {string} message - Le message à afficher
 * @param {string} type - Le type de notification (success, error, warning, info)
 * @param {number} duration - Durée d'affichage en ms (par défaut 3000ms)
 */
function showNotification(message, type = 'info', duration = 3000) {
  // Création du conteneur de notification s'il n'existe pas
  let notifContainer = document.getElementById('notification-container');
  if (!notifContainer) {
    notifContainer = document.createElement('div');
    notifContainer.id = 'notification-container';
    document.body.appendChild(notifContainer);
  }
  
  // Création de la notification
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
    <div class="notification-content">
      <div class="notification-message">${message}</div>
    </div>
  `;
  
  // Ajout de la notification au conteneur
  notifContainer.appendChild(notification);
  
  // Animation d'entrée
  setTimeout(() => {
    notification.classList.add('show');
  }, 10);
  
  // Suppression après la durée spécifiée
  setTimeout(() => {
    notification.classList.remove('show');
    notification.classList.add('hide');
    
    // Suppression du DOM après la fin de l'animation
    setTimeout(() => {
      if (notifContainer.contains(notification)) {
        notifContainer.removeChild(notification);
      }
    }, 300);
  }, duration);
}

// Exportation des fonctions pour les rendre disponibles
export { showLoader, showNotification };

