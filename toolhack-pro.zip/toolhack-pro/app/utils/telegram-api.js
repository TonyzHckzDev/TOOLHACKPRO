// app/utils/telegram-api.js

/**
 * Module d'intégration avec Telegram WebApp
 * Documentation officielle: https://core.telegram.org/bots/webapps
 */

// Référence à l'objet Telegram WebApp
let tgWebApp = null;

// État de l'intégration
const tgState = {
  isInitialized: false,
  isExpanded: false,
  user: null,
  version: null,
  platformInfo: null,
  viewportInfo: {
    width: window.innerWidth,
    height: window.innerHeight,
    isStable: true,
    isExpanded: false
  }
};

/**
 * Initialise l'intégration avec Telegram WebApp
 * @returns {Promise<Object|null>} Les données de l'utilisateur ou null si hors Telegram
 */
export async function initTelegramWebApp() {
  try {
    // Vérifier si nous sommes dans l'environnement Telegram WebApp
    if (window.Telegram && window.Telegram.WebApp) {
      tgWebApp = window.Telegram.WebApp;
      
      // Récupérer les informations de l'utilisateur et de la plateforme
      tgState.isInitialized = true;
      tgState.version = tgWebApp.version;
      tgState.platformInfo = {
        platform: tgWebApp.platform,
        colorScheme: tgWebApp.colorScheme,
        themeParams: tgWebApp.themeParams,
        isVersionAtLeast: tgWebApp.isVersionAtLeast.bind(tgWebApp)
      };
      
      // Récupérer les informations utilisateur
      if (tgWebApp.initDataUnsafe && tgWebApp.initDataUnsafe.user) {
        tgState.user = {
          id: tgWebApp.initDataUnsafe.user.id.toString(),
          firstName: tgWebApp.initDataUnsafe.user.first_name,
          lastName: tgWebApp.initDataUnsafe.user.last_name || '',
          username: tgWebApp.initDataUnsafe.user.username || '',
          languageCode: tgWebApp.initDataUnsafe.user.language_code || 'en',
          isPremium: !!tgWebApp.initDataUnsafe.user.is_premium
        };
      }
      
      // Configurer l'apparence en fonction des paramètres Telegram
      applyTelegramTheme();
      
      // Configurer les gestionnaires d'événements
      setupTelegramEventListeners();
      
      // Notifier Telegram que nous sommes prêts
      tgWebApp.ready();
      
      // Mettre à jour le viewport
      updateViewportInfo();
      
      console.log('Telegram WebApp initialized', { version: tgState.version, platform: tgState.platformInfo.platform });
      
      return tgState.user;
    } else {
      console.log('Not running in Telegram WebApp environment');
      
      // Retourner null pour indiquer que nous ne sommes pas dans Telegram
      return null;
    }
  } catch (error) {
    console.error('Error initializing Telegram WebApp:', error);
    
    // Fallback pour le développement hors Telegram
    if (process.env.NODE_ENV !== 'production') {
      console.log('Using development fallback for Telegram WebApp');
      return {
        id: 'dev_user_123',
        firstName: 'Dev',
        lastName: 'User',
        username: 'devuser',
        languageCode: 'fr',
        isPremium: true
      };
    }
    
    return null;
  }
}

/**
 * Applique le thème Telegram à l'application
 */
function applyTelegramTheme() {
  if (!tgWebApp || !tgState.isInitialized) return;
  
  const root = document.documentElement;
  const themeParams = tgWebApp.themeParams || {};
  
  // Appliquer les couleurs de Telegram au thème de l'application
  if (themeParams.bg_color) root.style.setProperty('--tg-bg-color', themeParams.bg_color);
  if (themeParams.text_color) root.style.setProperty('--tg-text-color', themeParams.text_color);
  if (themeParams.hint_color) root.style.setProperty('--tg-hint-color', themeParams.hint_color);
  if (themeParams.link_color) root.style.setProperty('--tg-link-color', themeParams.link_color);
  if (themeParams.button_color) root.style.setProperty('--tg-button-color', themeParams.button_color);
  if (themeParams.button_text_color) root.style.setProperty('--tg-button-text-color', themeParams.button_text_color);
  
  // Définir le thème global (clair/sombre)
  const isDarkTheme = tgWebApp.colorScheme === 'dark';
  document.body.classList.toggle('dark-theme', isDarkTheme);
  document.body.classList.toggle('light-theme', !isDarkTheme);
  
  // Mettre à jour les méta-tags pour le theme-color
  const metaThemeColor = document.querySelector('meta[name="theme-color"]');
  if (metaThemeColor) {
    metaThemeColor.content = themeParams.bg_color || (isDarkTheme ? '#212121' : '#ffffff');
  }
}

/**
 * Configure les gestionnaires d'événements pour Telegram WebApp
 */
function setupTelegramEventListeners() {
  if (!tgWebApp || !tgState.isInitialized) return;
  
  // Événement de changement de thème
  tgWebApp.onEvent('themeChanged', () => {
    console.log('Telegram theme changed to:', tgWebApp.colorScheme);
    applyTelegramTheme();
  });
  
  // Événement de changement de taille de la vue
  tgWebApp.onEvent('viewportChanged', updateViewportInfo);
  
  // Événement de fermeture de l'application
  tgWebApp.onEvent('popupClosed', (data) => {
    console.log('Popup closed with data:', data);
  });
  
  // Événement principal de retour
  tgWebApp.onEvent('backButtonClicked', handleBackButtonClicked);
  
  // Événement de sélection de carte
  if (tgWebApp.isVersionAtLeast('6.1')) {
    tgWebApp.onEvent('invoiceClosed', (data) => {
      console.log('Invoice closed with status:', data.status);
      // Gérer le résultat du paiement
      if (data.status === 'paid') {
        // Traiter le paiement réussi
        const event = new CustomEvent('payment-successful', { detail: data });
        document.dispatchEvent(event);
      }
    });
  }
}

/**
 * Met à jour les informations de viewport
 */
function updateViewportInfo() {
  if (!tgWebApp || !tgState.isInitialized) return;
  
  tgState.viewportInfo = {
    width: tgWebApp.viewportStableWidth || window.innerWidth,
    height: tgWebApp.viewportStableHeight || window.innerHeight,
    isStable: !!tgWebApp.isViewportStable,
    isExpanded: !!tgWebApp.isExpanded
  };
  
  tgState.isExpanded = tgWebApp.isExpanded;
  
  // Publier un événement pour notifier les changements de taille
  const event = new CustomEvent('tg-viewport-changed', { 
    detail: tgState.viewportInfo 
  });
  document.dispatchEvent(event);
  
  console.log('Viewport updated:', tgState.viewportInfo);
}

/**
 * Gère l'événement de clic sur le bouton retour
 */
function handleBackButtonClicked() {
  // Créer un événement personnalisé pour le bouton retour
  const event = new CustomEvent('tg-back-button');
  const wasHandled = !document.dispatchEvent(event);
  
  if (!wasHandled) {
    // Si l'événement n'a pas été géré, naviguer vers la page d'accueil
    if (window.navigateTo && typeof window.navigateTo === 'function') {
      window.navigateTo('catalog');
    }
  }
}

/**
 * Agrandit la vue WebApp pour utiliser tout l'écran
 * @returns {boolean} Succès de l'opération
 */
export function expandWebApp() {
  if (!tgWebApp || !tgState.isInitialized) return false;
  
  if (!tgState.isExpanded) {
    tgWebApp.expand();
    return true;
  }
  return false;
}

/**
 * Configure le bouton principal
 * @param {string} text - Texte du bouton
 * @param {Function} callback - Fonction à exécuter lors du clic
 * @param {boolean} [isProgress=false] - Afficher l'indicateur de progression
 * @param {boolean} [isVisible=true] - Visibilité du bouton
 */
export function setMainButton(text, callback, isProgress = false, isVisible = true) {
  if (!tgWebApp || !tgState.isInitialized) return;
  
  const mainButton = tgWebApp.MainButton;
  
  // Configurer le bouton
  mainButton.text = text;
  mainButton.color = tgWebApp.themeParams?.button_color || '#2481cc';
  mainButton.textColor = tgWebApp.themeParams?.button_text_color || '#ffffff';
  
  // Configurer l'état du bouton
  if (isProgress) {
    mainButton.showProgress(true);
  } else {
    mainButton.hideProgress();
  }
  
  // Retirer les anciens gestionnaires d'événements
  mainButton.offClick(mainButton.onClick);
  
  // Ajouter le nouveau gestionnaire
  if (callback && typeof callback === 'function') {
    mainButton.onClick(callback);
  }
  
  // Afficher ou masquer le bouton
  if (isVisible) {
    mainButton.show();
  } else {
    mainButton.hide();
  }
}

/**
 * Montre une alerte via Telegram
 * @param {string} message - Message à afficher
 * @param {Function} [callback] - Fonction à exécuter après confirmation
 */
export function showAlert(message, callback) {
  if (!tgWebApp || !tgState.isInitialized) {
    alert(message);
    if (callback && typeof callback === 'function') callback();
    return;
  }
  
  tgWebApp.showAlert(message, callback);
}

/**
 * Montre une boîte de confirmation via Telegram
 * @param {string} message - Message à afficher
 * @param {Function} [callback] - Fonction à exécuter avec le résultat
 */
export function showConfirm(message, callback) {
  if (!tgWebApp || !tgState.isInitialized) {
    const result = confirm(message);
    if (callback && typeof callback === 'function') callback(result);
    return;
  }
  
  tgWebApp.showConfirm(message, callback);
}

/**
 * Ouvre un lien dans le navigateur externe
 * @param {string} url - URL à ouvrir
 */
export function openExternalLink(url) {
  if (!tgWebApp || !tgState.isInitialized) {
    window.open(url, '_blank');
    return;
  }
  
  tgWebApp.openLink(url);
}

/**
 * Ouvre la fenêtre de partage Telegram
 * @param {string} text - Texte à partager
 */
export function shareMessage(text) {
  if (!tgWebApp || !tgState.isInitialized || !tgWebApp.isVersionAtLeast('6.0')) {
    // Fallback
    console.log('Share not supported in this version');
    return;
  }
  
  tgWebApp.showPopup({
    title: 'Partager',
    message: 'Choisissez avec qui partager',
    buttons: [
      {type: 'default', id: 'share', text: 'Partager'},
      {type: 'cancel'}
    ]
  }, (buttonId) => {
    if (buttonId === 'share') {
      // Utiliser l'API de partage interne à Telegram
      fetch('https://api.telegram.org/bot' + BOT_TOKEN + '/sendMessage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: tgState.user.id,
          text: text
        }),
      });
    }
  });
}

/**
 * Déclenche une vibration de feedback sur l'appareil
 * @param {string} [style='medium'] - Style de vibration ('light', 'medium', 'heavy', 'rigid', 'soft')
 */
export function hapticFeedback(style = 'medium') {
  if (!tgWebApp || !tgState.isInitialized || !tgWebApp.isVersionAtLeast('6.1')) {
    // Fallback à l'API de vibration du navigateur si disponible
    if (navigator.vibrate) {
      switch (style) {
        case 'light': navigator.vibrate(10); break;
        case 'medium': navigator.vibrate(20); break;
        case 'heavy': navigator.vibrate(30); break;
        case 'rigid': navigator.vibrate([5, 5, 10]); break;
        case 'soft': navigator.vibrate([10, 5, 5]); break;
        default: navigator.vibrate(20);
      }
    }
    return;
  }
  
  tgWebApp.HapticFeedback.impactOccurred(style);
}

/**
 * Ferme l'application WebApp
 */
export function closeWebApp() {
  if (!tgWebApp || !tgState.isInitialized) {
    // Rediriger vers Telegram si possible
    window.location.href = 'https://t.me/';
    return;
  }
  
  tgWebApp.close();
}

/**
 * Obtient les paramètres d'initialisation sécurisés pour la validation côté backend
 * @returns {Object} Données d'initialisation
 */
export function getInitData() {
  if (!tgWebApp || !tgState.isInitialized) {
    return null;
  }
  
  return {
    raw: tgWebApp.initData,
    parsed: tgWebApp.initDataUnsafe
  };
}

/**
 * Vérifie si l'application est en cours d'exécution dans Telegram WebApp
 * @returns {boolean} Vrai si dans Telegram
 */
export function isRunningInTelegram() {
  return tgState.isInitialized;
}

/**
 * Obtient les informations sur l'utilisateur actuel
 * @returns {Object|null} Données utilisateur ou null si non disponible
 */
export function getCurrentUser() {
  return tgState.user;
}

/**
 * Envoie des données au bot Telegram
 * @param {Object} data - Données à envoyer
 */
export function sendDataToBot(data) {
  if (!tgWebApp || !tgState.isInitialized) {
    console.log('Cannot send data to bot outside Telegram WebApp');
    return;
  }
  
  try {
    const dataString = JSON.stringify(data);
    tgWebApp.sendData(dataString);
    console.log('Data sent to Telegram bot:', data);
  } catch (e) {
    console.error('Error sending data to bot:', e);
  }
}

/**
 * Lance un paiement par facture Telegram
 * @param {string} invoiceLink - Lien de la facture
 * @returns {Promise<boolean>} Succès de l'ouverture
 */
export async function openInvoice(invoiceLink) {
  if (!tgWebApp || !tgState.isInitialized || !tgWebApp.isVersionAtLeast('6.1')) {
    console.log('Invoice payments not supported in this version');
    openExternalLink(invoiceLink);
    return false;
  }
  
  return new Promise((resolve) => {
    tgWebApp.openInvoice(invoiceLink, (status) => {
      resolve(status === 'paid');
    });
  });
}

/**
 * Obtient l'état actuel de l'intégration Telegram
 * @returns {Object} État actuel
 */
export function getTelegramState() {
  return { ...tgState };
}

/**
 * Vérifie si la version actuelle de WebApp supporte une fonctionnalité
 * @param {string} version - Version requise au format 'x.y'
 * @returns {boolean} Vrai si la version actuelle est >= version requise
 */
export function isVersionAtLeast(version) {
  if (!tgWebApp || !tgState.isInitialized) return false;
  return tgWebApp.isVersionAtLeast(version);
}

// Dans certains environnements, la largeur du viewport Telegram peut changer
// Surveiller les changements de taille de fenêtre pour les environnements hors Telegram
window.addEventListener('resize', () => {
  if (!tgState.isInitialized) {
    tgState.viewportInfo = {
      width: window.innerWidth,
      height: window.innerHeight,
      isStable: true,
      isExpanded: false
    };
    
    const event = new CustomEvent('tg-viewport-changed', { 
      detail: tgState.viewportInfo 
    });
    document.dispatchEvent(event);
  }
});

// Exporter le BOT_TOKEN depuis les constantes (si nécessaire pour les appels API)
let BOT_TOKEN = '';
try {
  // Essayer d'importer depuis les constantes
  import('../config/constants.js').then(constants => {
    if (constants.TELEGRAM_BOT_TOKEN) {
      BOT_TOKEN = constants.TELEGRAM_BOT_TOKEN;
    }
  }).catch(e => console.warn('Could not load Telegram bot token from constants', e));
} catch (e) {
  console.warn('Error importing constants', e);
}
