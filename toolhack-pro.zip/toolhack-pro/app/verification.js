// app/verification.js

/**
 * Module de vérification des utilisateurs
 * Gère l'authentification, la validation des invitations et les contrôles d'accès
 */

import { STORAGE_KEYS, SECURITY_CONFIG, API_ENDPOINTS, USER_ACCESS_LEVELS } from './config/constants.js';
import { translate } from './utils/i18n.js';
import { trackEvent } from './services/analytics.js';
import { getInitData } from './utils/telegram-api.js';
import { hapticFeedback } from './utils/telegram-api.js';

// État de vérification
let verificationState = {
  isVerified: false,
  accessLevel: USER_ACCESS_LEVELS.ANONYMOUS,
  lastVerified: null,
  verifiedBy: null,
  telegramData: null,
  verificationExpiry: null,
  pendingCode: null,
  verificationAttempts: 0,
  isLocked: false,
  lockExpiry: null,
  securityChecksEnabled: true
};

// Liste des codes d'invitation valides (en développement)
// En production, utiliser une API et du stockage sécurisé côté serveur
const DEV_INVITE_CODES = [
  { code: 'TOOLHACK2023', accessLevel: USER_ACCESS_LEVELS.VERIFIED },
  { code: 'ADMIN1337', accessLevel: USER_ACCESS_LEVELS.ADMIN },
  { code: 'PREMIUM2023', accessLevel: USER_ACCESS_LEVELS.PREMIUM }
];

/**
 * Initialise le module de vérification
 * @returns {Promise<boolean>} - État de vérification
 */
export async function initVerification() {
  try {
    // Restaurer l'état de vérification depuis le stockage local
    await restoreVerificationState();
    
    // Vérifier si le statut de vérification a expiré
    if (hasVerificationExpired()) {
      clearVerificationState();
      console.log('Verification has expired');
    }
    
    // Vérifier si le délai de verrouillage est passé
    if (isAccountLocked() && hasLockExpired()) {
      verificationState.isLocked = false;
      verificationState.lockExpiry = null;
      verificationState.verificationAttempts = 0;
      saveVerificationState();
    }
    
    // Si l'utilisateur est sur Telegram, essayer la vérification automatique
    const telegramData = getInitData();
    if (telegramData && telegramData.raw) {
      // Stocker les données Telegram pour référence
      verificationState.telegramData = {
        userId: telegramData.parsed?.user?.id,
        username: telegramData.parsed?.user?.username,
        authDate: telegramData.parsed?.auth_date,
        hash: telegramData.parsed?.hash
      };
      
      // En mode dev, on peut auto-vérifier les utilisateurs Telegram
      if (process.env.NODE_ENV !== 'production' && telegramData.parsed?.user?.id) {
        console.log('Dev mode auto-verification for Telegram user');
        await verifyTelegramUser(telegramData.parsed.user);
      } else {
        // En production, on vérifie le status auprès de l'API
        await checkVerificationStatus();
      }
    }
    
    return verificationState.isVerified;
  } catch (error) {
    console.error('Error initializing verification:', error);
    return false;
  }
}

/**
 * Restaure l'état de vérification depuis le stockage local
 * @returns {Promise<boolean>} - Succès de l'opération
 */
async function restoreVerificationState() {
  try {
    const storedState = localStorage.getItem(STORAGE_KEYS.VERIFICATION_STATUS);
    
    if (storedState) {
      const parsedState = JSON.parse(storedState);
      
      // Ne restaurer que les champs autorisés pour éviter les manipulations
      verificationState.isVerified = parsedState.isVerified || false;
      verificationState.accessLevel = parsedState.accessLevel || USER_ACCESS_LEVELS.ANONYMOUS;
      verificationState.lastVerified = parsedState.lastVerified || null;
      verificationState.verifiedBy = parsedState.verifiedBy || null;
      verificationState.verificationExpiry = parsedState.verificationExpiry || null;
      verificationState.isLocked = parsedState.isLocked || false;
      verificationState.lockExpiry = parsedState.lockExpiry || null;
      verificationState.verificationAttempts = parsedState.verificationAttempts || 0;
      
      console.log('Restored verification state:', verificationState.isVerified ? 'Verified' : 'Not verified');
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Error restoring verification state:', error);
    return false;
  }
}

/**
 * Sauvegarde l'état de vérification dans le stockage local
 * @returns {boolean} - Succès de l'opération
 */
function saveVerificationState() {
  try {
    localStorage.setItem(STORAGE_KEYS.VERIFICATION_STATUS, JSON.stringify(verificationState));
    return true;
  } catch (error) {
    console.error('Error saving verification state:', error);
    return false;
  }
}

/**
 * Efface l'état de vérification
 */
function clearVerificationState() {
  verificationState.isVerified = false;
  verificationState.accessLevel = USER_ACCESS_LEVELS.ANONYMOUS;
  verificationState.lastVerified = null;
  verificationState.verifiedBy = null;
  verificationState.verificationExpiry = null;
  
  try {
    localStorage.removeItem(STORAGE_KEYS.VERIFICATION_STATUS);
  } catch (error) {
    console.warn('Error clearing verification state:', error);
  }
}

/**
 * Vérifie si le statut de vérification a expiré
 * @returns {boolean} - Vrai si expiré
 */
function hasVerificationExpired() {
  if (!verificationState.isVerified || !verificationState.verificationExpiry) {
    return false;
  }
  
  const now = new Date();
  const expiry = new Date(verificationState.verificationExpiry);
  
  return now > expiry;
}

/**
 * Vérifie si le compte est verrouillé après trop de tentatives
 * @returns {boolean} - Vrai si verrouillé
 */
function isAccountLocked() {
  return verificationState.isLocked;
}

/**
 * Vérifie si le verrouillage du compte a expiré
 * @returns {boolean} - Vrai si le verrouillage a expiré
 */
function hasLockExpired() {
  if (!verificationState.lockExpiry) {
    return true;
  }
  
  const now = new Date();
  const expiry = new Date(verificationState.lockExpiry);
  
  return now > expiry;
}

/**
 * Vérifie le statut de vérification auprès de l'API
 * @returns {Promise<boolean>} - Succès de l'opération
 */
async function checkVerificationStatus() {
  // Ne vérifier que si nous avons des données Telegram
  if (!verificationState.telegramData || !verificationState.telegramData.userId) {
    return false;
  }
  
  try {
    // En développement, toujours retourner vérifié
    if (process.env.NODE_ENV !== 'production') {
      const randomLevel = Math.random() > 0.5 ? 
        USER_ACCESS_LEVELS.VERIFIED : 
        USER_ACCESS_LEVELS.PREMIUM;
      
      setVerificationStatus(true, randomLevel, 'dev_auto');
      return true;
    }
    
    // En production, vérifier auprès de l'API
    const response = await fetch(`${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.VERIFY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        user_id: verificationState.telegramData.userId,
        username: verificationState.telegramData.username,
        auth_date: verificationState.telegramData.authDate,
        hash: verificationState.telegramData.hash
      }),
      signal: AbortSignal.timeout(5000) // 5s timeout
    });
    
    if (response.ok) {
      const data = await response.json();
      
      if (data.verified) {
        setVerificationStatus(
          true, 
          data.access_level || USER_ACCESS_LEVELS.VERIFIED, 
          'api_check'
        );
        return true;
      } else {
        // L'API dit que l'utilisateur n'est pas vérifié
        clearVerificationState();
        return false;
      }
    } else {
      // Échec de l'API - garder le statut actuel
      console.warn('Failed to check verification status with API');
      return verificationState.isVerified;
    }
  } catch (error) {
    console.error('Error checking verification status:', error);
    
    // En cas d'erreur, garder le statut actuel
    return verificationState.isVerified;
  }
}

/**
 * Définit l'état de vérification
 * @param {boolean} isVerified - État de vérification
 * @param {number} accessLevel - Niveau d'accès
 * @param {string} method - Méthode de vérification
 */
function setVerificationStatus(isVerified, accessLevel, method) {
  const now = new Date();
  
  verificationState.isVerified = isVerified;
  verificationState.accessLevel = accessLevel;
  verificationState.lastVerified = now.toISOString();
  verificationState.verifiedBy = method;
  
  // Définir une date d'expiration (30 jours par défaut)
  const expiryDate = new Date(now);
  expiryDate.setDate(expiryDate.getDate() + 30);
  verificationState.verificationExpiry = expiryDate.toISOString();
  
  // Réinitialiser les compteurs de tentatives
  verificationState.verificationAttempts = 0;
  verificationState.isLocked = false;
  verificationState.lockExpiry = null;
  
  // Sauvegarder l'état
  saveVerificationState();
  
  // Notifier le changement
  document.dispatchEvent(new CustomEvent('verification-changed', {
    detail: { 
      verified: isVerified,
      accessLevel: accessLevel
    }
  }));
  
  // Tracking analytique
  trackEvent('user_verify', {
    success: true,
    method: method,
    access_level: accessLevel
  });
}

/**
 * Vérifie un utilisateur Telegram
 * @param {Object} user - Utilisateur Telegram
 * @returns {Promise<boolean>} - Succès de la vérification
 */
export async function verifyTelegramUser(user) {
  if (!user || !user.id) {
    return false;
  }
  
  try {
    // Stocker les informations utilisateur
    verificationState.telegramData = {
      userId: user.id,
      username: user.username,
      authDate: Math.floor(Date.now() / 1000),
      hash: 'telegram_direct' // Ceci n'est pas un vrai hash
    };
    
    // En développement, auto-vérifier certains utilisateurs
    if (process.env.NODE_ENV !== 'production') {
      // En développement, vérifier tout le monde
      setVerificationStatus(true, USER_ACCESS_LEVELS.VERIFIED, 'telegram_auth');
      return true;
    }
    
    // En production, vérifier auprès de l'API
    const response = await fetch(`${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.VERIFY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        user_id: user.id,
        username: user.username || '',
        first_name: user.first_name || '',
        last_name: user.last_name || '',
        is_premium: user.is_premium || false,
        source: 'telegram_webapp'
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      
      if (data.verified) {
        const accessLevel = data.access_level || USER_ACCESS_LEVELS.VERIFIED;
        setVerificationStatus(true, accessLevel, 'telegram_auth');
        return true;
      } else if (data.pending_code) {
        // L'utilisateur a besoin d'un code d'invitation
        verificationState.pendingCode = true;
        saveVerificationState();
        return false;
      } else {
        // Non autorisé
        return false;
      }
    } else {
      // Échec de l'API
      throw new Error(`API Error: ${response.status}`);
    }
  } catch (error) {
    console.error('Error verifying Telegram user:', error);
    
    // En cas d'erreur, conserver le modèle sécurisé (non vérifié)
    return false;
  }
}

/**
 * Vérifie un code d'invitation
 * @param {string} code - Code d'invitation
 * @param {Object} [user=null] - Données utilisateur
 * @returns {Promise<boolean>} - Succès de la vérification
 */
export async function verifyInviteCode(code, user = null) {
  // Vérifier si le compte est verrouillé
  if (isAccountLocked()) {
    if (hasLockExpired()) {
      // Réinitialiser le verrouillage
      verificationState.isLocked = false;
      verificationState.lockExpiry = null;
      verificationState.verificationAttempts = 0;
    } else {
      // Compte toujours verrouillé
      const remainingTime = Math.round((new Date(verificationState.lockExpiry) - new Date()) / 60000);
      throw new Error(translate('verification.account_locked', { minutes: remainingTime }));
    }
  }
  
  // Incrémenter le compteur de tentatives
  verificationState.verificationAttempts++;
  saveVerificationState();
  
  // Vérifier si le nombre maximum de tentatives est atteint
  if (verificationState.verificationAttempts >= SECURITY_CONFIG.maxLoginAttempts) {
    // Verrouiller le compte
    const lockExpiry = new Date();
    lockExpiry.setTime(lockExpiry.getTime() + SECURITY_CONFIG.lockoutDuration);
    
    verificationState.isLocked = true;
    verificationState.lockExpiry = lockExpiry.toISOString();
    saveVerificationState();
    
    // Feedback haptique pour l'échec
    hapticFeedback('error');
    
    // Tracking analytique
    trackEvent('verification_attempt', {
      success: false,
      reason: 'max_attempts_reached',
      attempts: verificationState.verificationAttempts
    });
    
    throw new Error(translate('verification.too_many_attempts'));
  }
  
  try {
    // Nettoyer le code
    const cleanCode = code.trim().toUpperCase();
    
    if (!cleanCode) {
      throw new Error(translate('verification.code_required'));
    }
    
    // En développement, vérifier avec les codes locaux
    if (process.env.NODE_ENV !== 'production') {
      const matchedCode = DEV_INVITE_CODES.find(c => c.code === cleanCode);
      
      if (matchedCode) {
        setVerificationStatus(true, matchedCode.accessLevel, 'invite_code');
        
        // Feedback haptique pour le succès
        hapticFeedback('success');
        
        return true;
      } else {
        // Échec de la vérification
        hapticFeedback('error');
        
        // Tracking analytique
        trackEvent('verification_attempt', {
          success: false,
          reason: 'invalid_code',
          attempts: verificationState.verificationAttempts
        });
        
        return false;
      }
    }
    
    // En production, vérifier avec l'API
    const userData = user || verificationState.telegramData || {};
    
    const response = await fetch(`${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.VALIDATE_TOKEN}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        invite_code: cleanCode,
        user_id: userData.userId || userData.id,
        username: userData.username,
        source: 'manual_entry'
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      
      if (data.valid) {
        const accessLevel = data.access_level || USER_ACCESS_LEVELS.VERIFIED;
        setVerificationStatus(true, accessLevel, 'invite_code');
        
        // Feedback haptique pour le succès
        hapticFeedback('success');
        
        return true;
      } else {
        // Code invalide
        // Feedback haptique pour l'échec
        hapticFeedback('error');
        
        // Tracking analytique
        trackEvent('verification_attempt', {
          success: false,
          reason: data.reason || 'invalid_code',
          attempts: verificationState.verificationAttempts
        });
        
        return false;
      }
    } else {
      // Erreur API
      throw new Error(`API Error: ${response.status}`);
    }
  } catch (error) {
    console.error('Error verifying invite code:', error);
    
    // Tracking analytique
    trackEvent('verification_attempt', {
      success: false,
      reason: 'api_error',
      attempts: verificationState.verificationAttempts
    });
    
    throw error;
  }
}

/**
 * Vérifie si un utilisateur a accès à un niveau spécifique
 * @param {number} requiredLevel - Niveau d'accès requis
 * @returns {boolean} - Vrai si l'accès est accordé
 */
export function hasAccessLevel(requiredLevel) {
  // Si la vérification a expiré, invalider
  if (hasVerificationExpired()) {
    clearVerificationState();
    return false;
  }
  
  // Vérifier le niveau d'accès
  return verificationState.isVerified && verificationState.accessLevel >= requiredLevel;
}

/**
 * Vérifie si l'utilisateur est authentifié
 * @returns {boolean} - Vrai si vérifié
 */
export function isAuthenticated() {
  // Si la vérification a expiré, invalider
  if (hasVerificationExpired()) {
    clearVerificationState();
    return false;
  }
  
  return verificationState.isVerified;
}

/**
 * Obtient le niveau d'accès actuel de l'utilisateur
 * @returns {number} - Niveau d'accès
 */
export function getAccessLevel() {
  return verificationState.accessLevel;
}

/**
 * Vérifie si un produit est accessible pour l'utilisateur actuel
 * @param {Object} product - Produit à vérifier
 * @returns {boolean} - Vrai si accessible
 */
export function canAccessProduct(product) {
  // Si les vérifications de sécurité sont désactivées, tout est accessible
  if (!verificationState.securityChecksEnabled) {
    return true;
  }
  
  // Si le produit requiert une vérification
  if (product.requiresVerification || product.isRestricted) {
    // Vérifier si l'utilisateur est authentifié
    if (!isAuthenticated()) {
      return false;
    }
    
    // Si le produit requiert un niveau spécifique
    if (product.requiredAccessLevel) {
      return hasAccessLevel(product.requiredAccessLevel);
    }
    
    // Par défaut, niveau VERIFIED requis pour les produits restreints
    return hasAccessLevel(USER_ACCESS_LEVELS.VERIFIED);
  }
  
  // Les produits non restreints sont accessibles à tous
  return true;
}

/**
 * Déconnecte l'utilisateur
 * @returns {boolean} - Succès de l'opération
 */
export function logout() {
  try {
    clearVerificationState();
    
    // Déclencher un événement pour la déconnexion
    document.dispatchEvent(new CustomEvent('user-logout'));
    
    return true;
  } catch (error) {
    console.error('Error during logout:', error);
    return false;
  }
}

/**
 * Active ou désactive les vérifications de sécurité (pour le mode développement)
 * @param {boolean} enabled - État d'activation
 */
export function toggleSecurityChecks(enabled) {
  verificationState.securityChecksEnabled = enabled;
  
  console.log(`Security checks ${enabled ? 'enabled' : 'disabled'}`);
  
  // Ne pas sauvegarder cette préférence dans le stockage local pour la sécurité
}

/**
 * Obtient les détails de vérification
 * @returns {Object} - État de vérification
 */
export function getVerificationDetails() {
  return {
    isVerified: verificationState.isVerified,
    accessLevel: verificationState.accessLevel,
    lastVerified: verificationState.lastVerified,
    verifiedBy: verificationState.verifiedBy,
    expiresAt: verificationState.verificationExpiry,
    hasExpired: hasVerificationExpired(),
    isLocked: isAccountLocked(),
    remainingAttempts: SECURITY_CONFIG.maxLoginAttempts - verificationState.verificationAttempts
  };
}

// Exporter les fonctions principales
export default {
  initVerification,
  verifyTelegramUser,
  verifyInviteCode,
  isAuthenticated,
  hasAccessLevel,
  getAccessLevel,
  canAccessProduct,
  logout,
  getVerificationDetails
};
