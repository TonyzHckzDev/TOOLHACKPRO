// app/config/constants.js

/**
 * Fichier de constantes pour ToolHack Pro
 * Contient toutes les valeurs de configuration centralisées
 */

// Version et informations de l'application
export const APP_VERSION = '1.0.0';
export const APP_NAME = 'ToolHack Pro';
export const APP_DESCRIPTION = 'Plateforme professionnelle pour les experts en cybersécurité';

// Identifiants Telegram
export const TELEGRAM_BOT_USERNAME = 'ToolHackProBot';
export const TELEGRAM_BOT_TOKEN = ''; // À remplir en production - ne jamais exposer dans le code source final

// Configuration du réseau TON
export const TON_NETWORK = {
  mainnet: true, // true pour mainnet, false pour testnet
  endpoints: [
    'https://toncenter.com/api/v2/jsonRPC',
    'https://ton.access.orbs.network/1/json-rpc'
  ],
  apiKey: '', // Votre API key pour TonCenter (optionnelle)
  walletConnectionTimeout: 30000, // 30 secondes
};

// Configuration Bitcoin
export const BTC_NETWORK = {
  mainnet: true,
  feeRate: 'medium' // 'low', 'medium', 'high'
};

// Clés pour le stockage local
export const STORAGE_KEYS = {
  CART: 'toolhack_cart',
  USER_PREFERENCES: 'toolhack_preferences',
  AUTH_TOKEN: 'toolhack_auth',
  LANGUAGE: 'toolhack_language',
  VIEWED_PRODUCTS: 'toolhack_viewed_products',
  VERIFICATION_STATUS: 'toolhack_verification'
};

// Paramètres des fonctionnalités
export const FEATURES = {
  ENABLE_ANALYTICS: true,
  ENABLE_OFFLINE_MODE: true,
  ENABLE_NOTIFICATIONS: true,
  ENABLE_DARK_MODE: true,
  DEBUG_MODE: false // Mettre à false en production
};

// Limites et contraintes
export const MAX_CART_ITEMS = 10;        // Maximum d'articles par produit
export const MAX_CART_PRODUCTS = 20;     // Maximum de produits différents
export const SEARCH_DEBOUNCE_MS = 300;   // Délai avant recherche
export const IMAGE_LAZY_OFFSET = 200;    // Pixels avant chargement des images
export const SESSION_TIMEOUT_MS = 3600000; // 1 heure
export const API_TIMEOUT_MS = 10000;     // 10 secondes
export const MIN_PASSWORD_LENGTH = 8;    // Longueur minimale de mot de passe

// Configurations des catégories
export const PRODUCT_CATEGORIES = {
  OFFENSIVE: {
    id: 'offensive',
    name: 'Matériel Offensif',
    icon: 'shield-slash'
  },
  SOFTWARE: {
    id: 'software',
    name: 'Logiciels & Firmwares',
    icon: 'code'
  },
  FORENSIC: {
    id: 'forensic',
    name: 'Équipement Forensique',
    icon: 'magnifying-glass'
  },
  ACCESSORIES: {
    id: 'accessories',
    name: 'Accessoires Spéciaux',
    icon: 'tools'
  },
  TRAINING: {
    id: 'training',
    name: 'Formations',
    icon: 'graduation-cap'
  }
};

// Configuration des langues supportées
export const SUPPORTED_LANGUAGES = {
  fr: {
    name: 'Français',
    flag: '🇫🇷',
    dateFormat: 'DD/MM/YYYY'
  },
  en: {
    name: 'English',
    flag: '🇬🇧',
    dateFormat: 'MM/DD/YYYY'
  }
};

// Codes de réponse API personnalisés
export const API_RESPONSE_CODES = {
  SUCCESS: 200,
  CREATED: 201,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  SERVER_ERROR: 500,
  
  // Codes personnalisés pour notre API
  VERIFICATION_REQUIRED: 1001,
  PRODUCT_UNAVAILABLE: 1002,
  PAYMENT_PENDING: 1003,
  PAYMENT_FAILED: 1004,
  SHIPPING_UNAVAILABLE: 1005,
  RATE_LIMITED: 1006
};

// Points de terminaison de l'API
export const API_ENDPOINTS = {
  BASE_URL: 'https://api.toolhackpro.com/v1', // À remplacer par votre URL réelle
  
  // Authentification et vérification
  AUTH: '/auth',
  VERIFY: '/verify',
  VALIDATE_TOKEN: '/auth/validate',
  
  // Produits
  PRODUCTS: '/products',
  PRODUCT_DETAIL: '/products/{id}',
  PRODUCT_AVAILABILITY: '/products/availability',
  PRODUCT_REVIEWS: '/products/{id}/reviews',
  
  // Panier et commandes
  CART: '/cart',
  ORDERS: '/orders',
  ORDER_DETAIL: '/orders/{id}',
  CHECKOUT: '/checkout',
  PAYMENT_METHODS: '/payment-methods',
  
  // Utilisateur
  USER_PROFILE: '/user/profile',
  USER_ORDERS: '/user/orders',
  USER_FAVORITES: '/user/favorites',
  USER_ADDRESSES: '/user/addresses',
  
  // Paiement
  PAYMENT_INTENT: '/payments/intent',
  PAYMENT_CONFIRM: '/payments/confirm',
  CRYPTO_PAYMENT: '/payments/crypto',
  
  // Divers
  SHIPPING_RATES: '/shipping/rates',
  PROMO_CODE: '/promotions/validate',
  FEEDBACK: '/feedback',
  NOTIFICATIONS: '/notifications',
  SUPPORT: '/support/ticket'
};

// Configuration des délais de rafraîchissement des données
export const REFRESH_INTERVALS = {
  PRODUCTS: 3600000, // 1 heure
  CART: 300000,      // 5 minutes
  USER: 1800000,     // 30 minutes
  ORDERS: 600000     // 10 minutes
};

// Niveaux de journalisation
export const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  WARNING: 2,
  ERROR: 3
};

// Niveau de journalisation actuel
export const CURRENT_LOG_LEVEL = FEATURES.DEBUG_MODE ? LOG_LEVELS.DEBUG : LOG_LEVELS.WARNING;

// Configurations des paiements
export const PAYMENT_CONFIG = {
  supportedCurrencies: ['USD', 'EUR', 'BTC', 'TON'],
  defaultCurrency: 'USD',
  gatewayTimeout: 60000, // 1 minute
  retryAttempts: 3,
  confirmationBlocks: {
    BTC: 2,
    TON: 3
  }
};

// Configuration des niveaux d'accès utilisateur
export const USER_ACCESS_LEVELS = {
  ANONYMOUS: 0,       // Utilisateur non authentifié
  VERIFIED: 1,        // Utilisateur vérifié
  PREMIUM: 2,         // Utilisateur premium
  ADMIN: 3            // Administrateur
};

// Configuration de la sécurité
export const SECURITY_CONFIG = {
  passwordMinLength: MIN_PASSWORD_LENGTH,
  passwordRequireSpecial: true,
  passwordRequireNumbers: true,
  maxLoginAttempts: 5,
  lockoutDuration: 900000, // 15 minutes
  sensitiveProductRequiresVerification: true,
  enableRecaptcha: true,
  csrfEnabled: true,
  sensitiveCategories: ['offensive', 'forensic']
};

// Configuration des notifications
export const NOTIFICATION_TYPES = {
  SUCCESS: 'success',
  INFO: 'info',
  WARNING: 'warning',
  ERROR: 'error'
};

// Durée d'affichage des notifications (ms)
export const NOTIFICATION_DURATION = {
  SHORT: 2000,
  MEDIUM: 3500,
  LONG: 5000
};

// Configurations du service worker
export const SERVICE_WORKER_CONFIG = {
  enabled: FEATURES.ENABLE_OFFLINE_MODE,
  cacheName: 'toolhack-cache-v1',
  filesToCache: [
    '/',
    '/index.html',
    '/styles/main.css',
    '/dist/bundle.js',
    '/assets/images/logo.svg',
    '/assets/images/placeholder.png'
  ],
  dynamicCacheSize: 50, // Nombre maximal d'entrées dans le cache dynamique
  offlinePage: '/offline.html'
};

// Configuration analytique (mesures anonymisées)
export const ANALYTICS_CONFIG = {
  enabled: FEATURES.ENABLE_ANALYTICS,
  anonymizeIP: true,
  excludeDevEnvironment: true,
  sampleRate: 100, // Pourcentage des sessions à tracker (100 = toutes)
  eventBatchSize: 10,
  eventFlushInterval: 30000, // 30 secondes
  customDimensions: {
    userType: 'dimension1',
    deviceType: 'dimension2',
    appVersion: 'dimension3',
    language: 'dimension4'
  }
};

// Réglages de performance
export const PERFORMANCE_CONFIG = {
  enableImageCompression: true,
  imageSizes: {
    thumbnail: 200,
    small: 400,
    medium: 800,
    large: 1200
  },
  maxImageWeight: 500 * 1024, // 500KB
  lazyLoadImages: true,
  enableMinification: true,
  enableCache: true,
  preloadCriticalAssets: true
};

// Messages d'erreur standard
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Erreur de connexion au serveur. Vérifiez votre connexion internet.',
  SERVER_ERROR: 'Une erreur serveur s\'est produite. Veuillez réessayer plus tard.',
  AUTH_ERROR: 'Erreur d\'authentification. Veuillez vous reconnecter.',
  VALIDATION_ERROR: 'Veuillez vérifier les informations saisies.',
  PAYMENT_ERROR: 'Erreur lors du traitement du paiement.',
  PRODUCT_UNAVAILABLE: 'Ce produit n\'est plus disponible.',
  CART_ERROR: 'Erreur lors de la mise à jour du panier.',
  ORDER_ERROR: 'Erreur lors de la création de la commande.',
  PERMISSION_ERROR: 'Vous n\'avez pas les permissions nécessaires pour cette action.',
  VERIFICATION_ERROR: 'Erreur lors de la vérification du compte.',
  TIMEOUT_ERROR: 'La requête a pris trop de temps. Veuillez réessayer.'
};

// Export par défaut de toutes les constantes
export default {
  APP_VERSION,
  APP_NAME,
  APP_DESCRIPTION,
  TELEGRAM_BOT_USERNAME,
  TON_NETWORK,
  BTC_NETWORK,
  STORAGE_KEYS,
  FEATURES,
  MAX_CART_ITEMS,
  MAX_CART_PRODUCTS,
  PRODUCT_CATEGORIES,
  SUPPORTED_LANGUAGES,
  API_ENDPOINTS,
  API_RESPONSE_CODES,
  REFRESH_INTERVALS,
  LOG_LEVELS,
  CURRENT_LOG_LEVEL,
  PAYMENT_CONFIG,
  USER_ACCESS_LEVELS,
  SECURITY_CONFIG,
  NOTIFICATION_TYPES,
  NOTIFICATION_DURATION,
  SERVICE_WORKER_CONFIG,
  ANALYTICS_CONFIG,
  PERFORMANCE_CONFIG,
  ERROR_MESSAGES
};
