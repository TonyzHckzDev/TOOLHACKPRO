// app/config/ton-wallet.js

/**
 * Module d'intégration du portefeuille TON
 * Gère les connexions et transactions avec la blockchain TON
 */

import { TON_NETWORK, STORAGE_KEYS } from './constants.js';
import { translate } from '../utils/i18n.js';
import { hapticFeedback } from '../utils/telegram-api.js';

// État du portefeuille TON
let tonConnector = null;
let walletAddress = null;
let walletBalance = null;
let isConnecting = false;
let lastConnectionError = null;
let connectedChainId = null;
let transactionListeners = [];
let embeddedWallet = null;
let connectionTimeout = null;

// Options de configuration par défaut
const defaultOptions = {
  manifestUrl: 'https://toolhackpro.com/tonconnect-manifest.json',
  bridgeUrl: 'https://bridge.tonapi.io/bridge',
  connectTimeoutMs: TON_NETWORK.walletConnectionTimeout || 30000
};

/**
 * Initialise le connecteur TON Wallet
 * @param {Object} networkConfig - Configuration du réseau TON
 * @param {string} userId - Identifiant de l'utilisateur pour le tracking
 * @param {Object} [options] - Options additionnelles pour la connexion
 * @returns {Promise<boolean>} - Succès de l'initialisation
 */
export async function initTonWallet(networkConfig, userId, options = {}) {
  try {
    // Si une connexion est déjà en cours, retourner
    if (isConnecting) {
      console.log('TON wallet connection already in progress');
      return false;
    }
    
    isConnecting = true;
    lastConnectionError = null;
    
    // Vérifier si le script TON Connect est déjà chargé
    if (!window.TonConnect) {
      await loadTonConnectScript();
    }
    
    // Fusionner les options
    const connectorOptions = { ...defaultOptions, ...options };
    
    // Ajuster les endpoints en fonction du réseau
    if (networkConfig && networkConfig.endpoints && networkConfig.endpoints.length > 0) {
      connectorOptions.endpoints = networkConfig.endpoints;
    }
    
    // Créer le connecteur
    tonConnector = new window.TonConnect({
      manifestUrl: connectorOptions.manifestUrl,
      bridgeUrl: connectorOptions.bridgeUrl
    });
    
    // Configurer un timeout pour la connexion
    clearTimeout(connectionTimeout);
    connectionTimeout = setTimeout(() => {
      if (isConnecting) {
        isConnecting = false;
        lastConnectionError = 'Connection timeout';
        console.error('TON wallet connection timeout');
        return false;
      }
    }, connectorOptions.connectTimeoutMs);
    
    // Souscrire aux événements du connecteur
    setupWalletEventListeners(userId);
    
    // Vérifier si on a déjà une connexion sauvegardée
    const persistedConnection = restoreWalletConnection();
    
    if (persistedConnection) {
      console.log('Restored TON wallet connection:', persistedConnection.address);
      walletAddress = persistedConnection.address;
      connectedChainId = persistedConnection.network;
      isConnecting = false;
      clearTimeout(connectionTimeout);
      
      // Vérifier si la connexion est toujours valide
      try {
        await updateWalletBalance();
        notifyConnectionSuccess();
        return true;
      } catch (e) {
        console.warn('Saved wallet connection is no longer valid, reconnecting...');
      }
    }
    
    // Si nous arrivons ici, nous n'avons pas pu restaurer de connexion
    // Si nous sommes dans Telegram, essayer d'utiliser Telegram comme portefeuille TON
    if (window.Telegram && window.Telegram.WebApp) {
      const telegramWalletResult = await connectTelegramWallet();
      isConnecting = false;
      clearTimeout(connectionTimeout);
      
      if (telegramWalletResult) {
        return true;
      }
    }
    
    // Sinon, ouvrir le sélecteur de portefeuille
    const result = await showWalletSelector();
    isConnecting = false;
    clearTimeout(connectionTimeout);
    
    return result;
  } catch (error) {
    console.error('Error initializing TON wallet:', error);
    lastConnectionError = error.message || 'Unknown error';
    isConnecting = false;
    clearTimeout(connectionTimeout);
    return false;
  }
}

/**
 * Charge le script TON Connect si nécessaire
 * @returns {Promise<void>}
 */
async function loadTonConnectScript() {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/@tonconnect/sdk@latest/dist/tonconnect-sdk.min.js';
    script.async = true;
    script.onload = () => resolve();
    script.onerror = (error) => reject(new Error('Failed to load TON Connect script'));
    document.head.appendChild(script);
  });
}

/**
 * Configure les écouteurs d'événements du portefeuille
 * @param {string} userId - Identifiant de l'utilisateur pour le tracking
 */
function setupWalletEventListeners(userId) {
  if (!tonConnector) return;
  
  // S'abonner aux événements de connexion et déconnexion
  tonConnector.onStatusChange((wallet) => {
    if (wallet) {
      // Connexion réussie
      walletAddress = wallet.account.address;
      connectedChainId = wallet.account.chain;
      
      // Sauvegarder la connexion
      saveWalletConnection(wallet.account);
      
      // Notifier du succès
      notifyConnectionSuccess();
      
      // Actualiser le solde
      updateWalletBalance();
      
      console.log('TON wallet connected:', walletAddress);
    } else {
      // Déconnecté
      walletAddress = null;
      walletBalance = null;
      connectedChainId = null;
      
      // Effacer la connexion sauvegardée
      clearSavedWalletConnection();
      
      // Notifier de la déconnexion
      notifyDisconnect();
      
      console.log('TON wallet disconnected');
    }
  });
  
  // Log d'activité analytique pour le tracking (anonymisé)
  if (userId) {
    tonConnector.onStatusChange(() => {
      try {
        // Log anonymisé - ne contient pas l'adresse complète
        const event = {
          type: 'wallet_connection',
          // Ne stocker que les premiers caractères pour l'anonymisation
          wallet_prefix: walletAddress ? `${walletAddress.slice(0, 8)}...` : null,
          network: connectedChainId,
          timestamp: new Date().toISOString(),
          // Utiliser un hash au lieu de l'ID utilisateur brut
          user_hash: hashUserId(userId)
        };
        
        // Envoyer à l'analytique
        if (window.trackEvent && typeof window.trackEvent === 'function') {
          window.trackEvent('wallet_interaction', event);
        }
      } catch (e) {
        console.warn('Error logging wallet activity:', e);
      }
    });
  }
}

/**
 * Génère un hash d'identifiant utilisateur pour l'anonymisation
 * @param {string} userId - Identifiant utilisateur
 * @returns {string} - Hash anonymisé
 */
function hashUserId(userId) {
  // Simple hachage pour l'exemple - en production, utiliser une méthode plus robuste
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    const char = userId.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Conversion en 32bit integer
  }
  return hash.toString(16); // Conversion en hex
}

/**
 * Affiche le sélecteur de portefeuille TON
 * @returns {Promise<boolean>} - Succès de la connexion
 */
async function showWalletSelector() {
  if (!tonConnector) {
    console.error('TON connector not initialized');
    return false;
  }
  
  try {
    // Obtenir la liste des portefeuilles disponibles
    const wallets = await tonConnector.getWallets();
    
    // Filtrer les portefeuilles en fonction du réseau (mainnet/testnet)
    const filteredWallets = wallets.filter(wallet => {
      const supportsMainnet = wallet.supports_mainnet || wallet.supports.includes('mainnet');
      const supportsTestnet = wallet.supports_testnet || wallet.supports.includes('testnet');
      
      return TON_NETWORK.mainnet ? supportsMainnet : supportsTestnet;
    });
    
    if (filteredWallets.length === 0) {
      console.error('No compatible wallets found');
      return false;
    }
    
    // Créer l'élément UI pour la sélection
    const modalContainer = document.createElement('div');
    modalContainer.className = 'wallet-selector-modal';
    modalContainer.innerHTML = `
      <div class="wallet-selector-content">
        <div class="wallet-selector-header">
          <h3>${translate('wallet.select_title')}</h3>
          <button class="wallet-selector-close">&times;</button>
        </div>
        <div class="wallet-selector-body">
          <p>${translate('wallet.select_description')}</p>
          <div class="wallet-list"></div>
        </div>
      </div>
    `;
    
    // Ajouter les portefeuilles à la liste
    const walletList = modalContainer.querySelector('.wallet-list');
    filteredWallets.forEach(wallet => {
      const walletBtn = document.createElement('button');
      walletBtn.className = 'wallet-option';
      walletBtn.dataset.walletId = wallet.id;
      walletBtn.innerHTML = `
        <img src="${wallet.image_url}" alt="${wallet.name}" />
        <span>${wallet.name}</span>
      `;
      walletList.appendChild(walletBtn);
    });
    
    // Ajouter au DOM
    document.body.appendChild(modalContainer);
    
    // Retourner une promesse qui se résout quand l'utilisateur sélectionne un portefeuille
    return new Promise((resolve) => {
      // Gérer la fermeture du modal
      const closeBtn = modalContainer.querySelector('.wallet-selector-close');
      closeBtn.addEventListener('click', () => {
        modalContainer.remove();
        resolve(false);
      });
      
      // Gérer la sélection d'un portefeuille
      const walletButtons = modalContainer.querySelectorAll('.wallet-option');
      walletButtons.forEach(btn => {
        btn.addEventListener('click', async () => {
          const walletId = btn.dataset.walletId;
          const selectedWallet = filteredWallets.find(w => w.id === walletId);
          
          if (selectedWallet) {
            try {
              // Générer une URL de connexion profonde
              const universalLink = tonConnector.connect(selectedWallet);
              
              // Ouvrir le lien
              window.open(universalLink, '_blank');
              
              // Attendre que la connexion soit établie
              const connectionResult = await waitForWalletConnection();
              
              // Supprimer le modal
              modalContainer.remove();
              
              resolve(connectionResult);
            } catch (error) {
              console.error('Error connecting to wallet:', error);
              // Afficher un message d'erreur
              const errorMsg = document.createElement('p');
              errorMsg.className = 'wallet-error';
              errorMsg.textContent = translate('wallet.connection_error');
              walletList.appendChild(errorMsg);
              
              setTimeout(() => {
                errorMsg.remove();
              }, 3000);
              
              resolve(false);
            }
          } else {
            resolve(false);
          }
        });
      });
    });
  } catch (error) {
    console.error('Error showing wallet selector:', error);
    return false;
  }
}

/**
 * Tente de se connecter via le portefeuille Telegram
 * @returns {Promise<boolean>} - Succès de la connexion
 */
async function connectTelegramWallet() {
  try {
    if (!window.Telegram || !window.Telegram.WebApp) {
      return false;
    }
    
    const tg = window.Telegram.WebApp;
    
    // Vérifier si le portefeuille Telegram est disponible
    if (!tg.isVersionAtLeast('6.9') || !tg.ton) {
      console.log('Telegram TON wallet not available in this version');
      return false;
    }
    
    // Essayer de se connecter au portefeuille Telegram
    const result = await tg.ton.connect();
    
    if (result) {
      // Sauvegarder l'adresse
      walletAddress = result.address;
      connectedChainId = TON_NETWORK.mainnet ? 'mainnet' : 'testnet';
      
      // Sauvegarder la connexion
      saveWalletConnection({
        address: walletAddress,
        chain: connectedChainId,
        provider: 'telegram'
      });
      
      // Actualiser le solde
      await updateWalletBalance();
      
      // Notifier du succès
      notifyConnectionSuccess();
      
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Error connecting to Telegram wallet:', error);
    return false;
  }
}

/**
 * Attend que la connexion au portefeuille soit établie
 * @param {number} [timeout=30000] - Délai d'attente maximum en ms
 * @returns {Promise<boolean>} - Succès de la connexion
 */
function waitForWalletConnection(timeout = 30000) {
  return new Promise((resolve) => {
    // Si déjà connecté, résoudre immédiatement
    if (walletAddress) {
      resolve(true);
      return;
    }
    
    // Définir un timeout
    const timeoutId = setTimeout(() => {
      // Supprimer l'écouteur pour éviter les fuites de mémoire
      if (tonConnector) {
        tonConnector.unsubscribe();
      }
      resolve(false);
    }, timeout);
    
    // S'abonner aux changements de statut
    if (tonConnector) {
      tonConnector.subscribe((wallet) => {
        if (wallet) {
          // Connexion établie
          clearTimeout(timeoutId);
          resolve(true);
        }
      });
    } else {
      clearTimeout(timeoutId);
      resolve(false);
    }
  });
}

/**
 * Restaure la connexion au portefeuille depuis le stockage local
 * @returns {Object|null} - Informations du portefeuille ou null
 */
function restoreWalletConnection() {
  try {
    const savedWallet = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
    
    if (!savedWallet) {
      return null;
    }
    
    const walletData = JSON.parse(savedWallet);
    
    // Vérifier si les données ont expiré (24h par défaut)
    const now = new Date();
    const savedTime = new Date(walletData.timestamp);
    const expirationHours = 24;
    
    if ((now - savedTime) > (expirationHours * 60 * 60 * 1000)) {
      // La connexion a expiré
      clearSavedWalletConnection();
      return null;
    }
    
    return walletData;
  } catch (error) {
    console.error('Error restoring wallet connection:', error);
    return null;
  }
}

/**
 * Sauvegarde la connexion au portefeuille dans le stockage local
 * @param {Object} account - Informations du compte portefeuille
 */
function saveWalletConnection(account) {
  try {
    const walletData = {
      address: account.address,
      network: account.chain,
      provider: account.walletName || 'unknown',
      timestamp: new Date().toISOString()
    };
    
    localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, JSON.stringify(walletData));
  } catch (error) {
    console.error('Error saving wallet connection:', error);
  }
}

/**
 * Efface la connexion sauvegardée
 */
function clearSavedWalletConnection() {
  try {
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
  } catch (error) {
    console.error('Error clearing saved wallet connection:', error);
  }
}

/**
 * Met à jour le solde du portefeuille
 * @returns {Promise<number|null>} - Le solde actualisé ou null en cas d'erreur
 */
export async function updateWalletBalance() {
  if (!walletAddress) {
    return null;
  }
  
  try {
    let balance = null;
    
    // Vérifier si nous utilisons le portefeuille Telegram
    if (window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.ton) {
      // Utiliser l'API Telegram pour obtenir le solde
      balance = await window.Telegram.WebApp.ton.getBalance();
    } else if (tonConnector) {
      // Utiliser l'API TON Center pour obtenir le solde
      const endpoint = TON_NETWORK.endpoints[0] || 'https://toncenter.com/api/v2/jsonRPC';
      const response = await fetch(`${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(TON_NETWORK.apiKey ? { 'X-API-Key': TON_NETWORK.apiKey } : {})
        },
        body: JSON.stringify({
          id: '1',
          jsonrpc: '2.0',
          method: 'getAddressBalance',
          params: [walletAddress]
        })
      });
      
      const data = await response.json();
      
      if (data.result) {
        // Convertir de nanoTON à TON (1 TON = 10^9 nanoTON)
        balance = parseInt(data.result) / 1000000000;
      }
    }
    
    if (balance !== null) {
      walletBalance = balance;
      
      // Déclencher un événement pour notifier du changement de solde
      const event = new CustomEvent('wallet-balance-updated', { 
        detail: { balance: walletBalance } 
      });
      document.dispatchEvent(event);
      
      return walletBalance;
    }
    
    return null;
  } catch (error) {
    console.error('Error updating wallet balance:', error);
    return null;
  }
}

/**
 * Envoie une transaction TON
 * @param {string} toAddress - Adresse du destinataire
 * @param {number} amount - Montant en TON
 * @param {string} [comment=''] - Commentaire pour la transaction
 * @returns {Promise<Object>} - Résultat de la transaction
 */
export async function sendTransaction(toAddress, amount, comment = '') {
  if (!walletAddress || !tonConnector) {
    throw new Error('Wallet not connected');
  }
  
  try {
    // Convertir le montant en nanoTON (1 TON = 10^9 nanoTON)
    const amountNano = Math.floor(amount * 1000000000);
    
    // Préparer la transaction
    const transaction = {
      validUntil: Math.floor(Date.now() / 1000) + 300, // 5 minutes
      messages: [
        {
          address: toAddress,
          amount: amountNano.toString(),
          ...(comment ? { payload: stringToHex(comment) } : {})
        }
      ]
    };
    
    // Vérifier si nous utilisons le portefeuille Telegram
    if (window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.ton) {
      // Utiliser l'API Telegram pour envoyer la transaction
      const result = await window.Telegram.WebApp.ton.sendTransaction({
        to: toAddress,
        amount: amountNano,
        comment: comment
      });
      
      // Créer un résultat unifié
      return {
        success: !!result,
        transactionId: result.tontxId || null,
        provider: 'telegram'
      };
    } else {
      // Utiliser TON Connect pour envoyer la transaction
      const result = await tonConnector.sendTransaction(transaction);
      
      // Actualiser le solde après la transaction
      setTimeout(() => {
        updateWalletBalance();
      }, 5000);
      
      return {
        success: true,
        transactionId: result.boc || null,
        provider: 'tonconnect'
      };
    }
  } catch (error) {
    console.error('Error sending TON transaction:', error);
    throw new Error(`Transaction failed: ${error.message}`);
  }
}

/**
 * Convertit une chaîne en hexadécimal pour les payloads de transaction
 * @param {string} str - Chaîne à convertir
 * @returns {string} - Chaîne en hexadécimal
 */
function stringToHex(str) {
  let hex = '';
  for (let i = 0; i < str.length; i++) {
    const charCode = str.charCodeAt(i);
    hex += charCode.toString(16).padStart(2, '0');
  }
  return hex;
}

/**
 * Déconnecte le portefeuille actuel
 * @returns {Promise<boolean>} - Succès de la déconnexion
 */
export async function disconnectWallet() {
  if (!tonConnector) {
    return true; // Déjà déconnecté
  }
  
  try {
    await tonConnector.disconnect();
    
    // Réinitialiser l'état
    walletAddress = null;
    walletBalance = null;
    connectedChainId = null;
    
    // Effacer la connexion sauvegardée
    clearSavedWalletConnection();
    
    // Notifier de la déconnexion
    notifyDisconnect();
    
    return true;
  } catch (error) {
    console.error('Error disconnecting wallet:', error);
    return false;
  }
}

/**
 * Vérifie si un portefeuille est connecté
 * @returns {boolean} - Vrai si un portefeuille est connecté
 */
export function isWalletConnected() {
  return !!walletAddress;
}

/**
 * Obtient l'adresse du portefeuille connecté
 * @param {boolean} [formatted=false] - Formater l'adresse (abrégée)
 * @returns {string|null} - Adresse du portefeuille ou null
 */
export function getWalletAddress(formatted = false) {
  if (!walletAddress) {
    return null;
  }
  
  if (formatted) {
    // Format abrégé: EQC...abc
    const start = walletAddress.substring(0, 6);
    const end = walletAddress.substring(walletAddress.length - 4);
    return `${start}...${end}`;
  }
  
  return walletAddress;
}

/**
 * Obtient le solde du portefeuille
 * @param {boolean} [formatted=false] - Formater le solde avec 2 décimales
 * @returns {number|string|null} - Solde du portefeuille ou null
 */
export function getWalletBalance(formatted = false) {
  if (walletBalance === null) {
    return null;
  }
  
  if (formatted) {
    return walletBalance.toFixed(2);
  }
  
  return walletBalance;
}

/**
 * Notifie d'une connexion réussie
 */
function notifyConnectionSuccess() {
  // Retour haptique
  if (typeof hapticFeedback === 'function') {
    hapticFeedback('medium');
  }
  
  // Événement personnalisé
  const event = new CustomEvent('wallet-connected', { 
    detail: { 
      address: walletAddress,
      network: connectedChainId
    } 
  });
  document.dispatchEvent(event);
}

/**
 * Notifie d'une déconnexion
 */
function notifyDisconnect() {
  // Événement personnalisé
  const event = new CustomEvent('wallet-disconnected');
  document.dispatchEvent(event);
}

/**
 * Obtient la dernière erreur de connexion
 * @returns {string|null} - Message d'erreur ou null
 */
export function getLastConnectionError() {
  return lastConnectionError;
}

/**
 * Vérifie si la connexion du portefeuille est en cours
 * @returns {boolean} - Vrai si la connexion est en cours
 */
export function isWalletConnecting() {
  return isConnecting;
}

/**
 * Génère une QR Code pour le paiement TON
 * @param {string} toAddress - Adresse du destinataire
 * @param {number} amount - Montant en TON
 * @param {string} [comment=''] - Commentaire pour la transaction
 * @returns {string} - URL du QR code
 */
export function generateTonPaymentUrl(toAddress, amount, comment = '') {
  if (!toAddress) {
    throw new Error('Recipient address is required');
  }
  
  // Construire l'URL du paiement ton://
  let paymentUrl = `ton://transfer/${toAddress}?amount=${Math.floor(amount * 1000000000)}`;
  
  // Ajouter un commentaire si fourni
  if (comment) {
    paymentUrl += `&text=${encodeURIComponent(comment)}`;
  }
  
  // Générer une URL pour le QR code via une API
  return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(paymentUrl)}`;
}

/**
 * Surveille une transaction TON pour confirmation
 * @param {string} transactionId - ID de la transaction
 * @param {Function} callback - Fonction de rappel (status, confirmations)
 * @param {number} [requiredConfirmations=3] - Nombre de confirmations requises
 */
export function watchTransaction(transactionId, callback, requiredConfirmations = 3) {
  if (!transactionId || !callback) {
    return;
  }
  
  let confirmations = 0;
  let checkCount = 0;
  const maxChecks = 20; // Limiter le nombre de vérifications
  
  // Fonction de vérification récursive
  const checkTransaction = async () => {
    checkCount++;
    
    try {
      // Utiliser l'API TON Center pour vérifier la transaction
      const endpoint = TON_NETWORK.endpoints[0] || 'https://toncenter.com/api/v2/jsonRPC';
      const response = await fetch(`${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(TON_NETWORK.apiKey ? { 'X-API-Key': TON_NETWORK.apiKey } : {})
        },
        body: JSON.stringify({
          id: '1',
          jsonrpc: '2.0',
          method: 'getTransactions',
          params: [walletAddress, 10] // Vérifier les 10 dernières transactions
        })
      });
      
      const data = await response.json();
      
      if (data.result) {
        // Chercher la transaction dans les résultats
        const foundTx = data.result.find(tx => 
          tx.transaction_id.hash === transactionId || 
          tx.id === transactionId);
        
        if (foundTx) {
          confirmations++;
          callback('confirming', confirmations);
          
          // Vérifier si nous avons assez de confirmations
          if (confirmations >= requiredConfirmations) {
            callback('confirmed', confirmations);
            return; // Arrêter la vérification
          }
        }
      }
      
      // Continuer à vérifier si nous n'avons pas atteint le maximum
      if (checkCount < maxChecks) {
        // Augmenter l'intervalle progressivement
        const nextInterval = Math.min(5000 + (checkCount * 1000), 15000);
        setTimeout(checkTransaction, nextInterval);
      } else {
        // Timeout après trop de vérifications
        callback('timeout', confirmations);
      }
    } catch (error) {
      console.error('Error checking transaction:', error);
      
      // Continuer à vérifier malgré l'erreur
      if (checkCount < maxChecks) {
        setTimeout(checkTransaction, 5000);
      } else {
        callback('error', confirmations);
      }
    }
  };
  
  // Démarrer la vérification
  callback('pending', 0);
  setTimeout(checkTransaction, 5000); // Commencer après 5 secondes
  
  // Retourner une fonction pour arrêter la surveillance
  return {
    stop: () => {
      checkCount = maxChecks; // Forcer l'arrêt
    }
  };
}

// Exporter les fonctions principales
export default {
  initTonWallet,
  sendTransaction,
  disconnectWallet,
  isWalletConnected,
  isWalletConnecting,
  getWalletAddress,
  getWalletBalance,
  updateWalletBalance,
  getLastConnectionError,
  generateTonPaymentUrl,
  watchTransaction
};

