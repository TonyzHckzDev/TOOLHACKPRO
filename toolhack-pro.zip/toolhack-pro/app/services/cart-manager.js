// app/services/cart-manager.js

/**
 * Service de gestion du panier
 * Gère l'ajout, la suppression, la mise à jour et la persistance des articles dans le panier
 */

import { STORAGE_KEYS, CART_CONFIG, TAX_RATES } from '../config/constants.js';
import { getProductById } from './products.js';
import { trackEvent } from './analytics.js';
import { translate } from '../utils/i18n.js';
import { showNotification } from '../utils/ui-manager.js';
import { getCurrentLanguage } from '../utils/i18n.js';

// État du panier
let cartState = {
  items: [],
  couponCode: null,
  couponDiscount: 0,
  shippingMethod: null,
  shippingCost: 0,
  taxRate: 0,
  taxExempt: false,
  subtotal: 0,
  total: 0,
  itemCount: 0,
  lastUpdated: null,
  currency: 'USD'
};

// Écouteurs d'événements
const eventListeners = new Map();

/**
 * Initialise le service de gestion du panier
 * @returns {Promise<boolean>} - Succès de l'initialisation
 */
export async function initCartManager() {
  try {
    // Restaurer le panier depuis le stockage local
    await restoreCart();
    
    // Appliquer la taxe en fonction du pays/région
    applyTaxRate();
    
    // Mettre à jour les totaux
    updateCartTotals();
    
    // Notifier de l'initialisation
    console.log('Cart manager initialized with', cartState.itemCount, 'items');
    
    return true;
  } catch (error) {
    console.error('Error initializing cart manager:', error);
    return false;
  }
}

/**
 * Restaure le panier depuis le stockage local
 * @returns {Promise<boolean>} - Succès de la restauration
 */
async function restoreCart() {
  try {
    const savedCart = localStorage.getItem(STORAGE_KEYS.CART);
    
    if (!savedCart) {
      return false;
    }
    
    const parsedCart = JSON.parse(savedCart);
    
    // Valider le format
    if (!parsedCart || !Array.isArray(parsedCart.items)) {
      return false;
    }
    
    // Vérifier les articles et leurs stocks
    const validItems = [];
    
    for (const item of parsedCart.items) {
      // Vérifier si le produit existe toujours et a un stock
      const product = await getProductById(item.id);
      
      if (product && product.stock > 0) {
        // Ajuster la quantité si nécessaire
        const quantity = Math.min(item.quantity, product.stock);
        
        validItems.push({
          id: item.id,
          name: product.name,
          price: product.price,
          originalPrice: product.originalPrice,
          image: product.image,
          quantity: quantity,
          category: product.category,
          sku: product.sku || '',
          requiresVerification: product.requiresVerification || false
        });
      }
    }
    
    // Restaurer les champs valides
    cartState.items = validItems;
    cartState.couponCode = parsedCart.couponCode || null;
    cartState.couponDiscount = parsedCart.couponDiscount || 0;
    cartState.shippingMethod = parsedCart.shippingMethod || null;
    cartState.shippingCost = parsedCart.shippingCost || 0;
    cartState.taxExempt = parsedCart.taxExempt || false;
    cartState.lastUpdated = parsedCart.lastUpdated || new Date().toISOString();
    cartState.currency = parsedCart.currency || 'USD';
    
    return true;
  } catch (error) {
    console.error('Error restoring cart:', error);
    return false;
  }
}

/**
 * Sauvegarde le panier dans le stockage local
 * @returns {boolean} - Succès de la sauvegarde
 */
function saveCart() {
  try {
    // Mettre à jour la date de dernière modification
    cartState.lastUpdated = new Date().toISOString();
    
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cartState));
    
    return true;
  } catch (error) {
    console.error('Error saving cart:', error);
    return false;
  }
}

/**
 * Ajoute un article au panier
 * @param {string} productId - ID du produit
 * @param {number} [quantity=1] - Quantité
 * @returns {Promise<boolean>} - Succès de l'ajout
 */
export async function addToCart(productId, quantity = 1) {
  try {
    // Vérifier si le produit existe
    const product = await getProductById(productId);
    
    if (!product) {
      throw new Error(translate('cart.product_not_found'));
    }
    
    // Vérifier le stock
    if (product.stock <= 0) {
      throw new Error(translate('cart.out_of_stock'));
    }
    
    // Vérifier la quantité demandée
    if (quantity <= 0) {
      throw new Error(translate('cart.invalid_quantity'));
    }
    
    // Chercher si le produit est déjà dans le panier
    const existingItem = cartState.items.find(item => item.id === productId);
    
    if (existingItem) {
      // Calculer la nouvelle quantité
      const newQuantity = existingItem.quantity + quantity;
      
      // Vérifier le stock disponible
      if (newQuantity > product.stock) {
        const maxAddable = product.stock - existingItem.quantity;
        
        if (maxAddable <= 0) {
          throw new Error(translate('cart.max_quantity_reached'));
        }
        
        // Ajuster la quantité au maximum disponible
        existingItem.quantity = product.stock;
        
        showNotification(
          translate('cart.adjusted_quantity', { quantity: product.stock }),
          'warning'
        );
      } else {
        // Mettre à jour la quantité
        existingItem.quantity = newQuantity;
      }
    } else {
      // Ajouter un nouvel article
      // Vérifier la quantité par rapport au stock
      const validQuantity = Math.min(quantity, product.stock);
      
      cartState.items.push({
        id: product.id,
        name: product.name,
        price: product.price,
        originalPrice: product.originalPrice || product.price,
        image: product.image,
        quantity: validQuantity,
        category: product.category,
        sku: product.sku || '',
        requiresVerification: product.requiresVerification || false
      });
      
      // Si on a dû ajuster la quantité
      if (validQuantity < quantity) {
        showNotification(
          translate('cart.limited_stock', { quantity: validQuantity }),
          'warning'
        );
      }
    }
    
    // Mettre à jour les totaux
    updateCartTotals();
    
    // Sauvegarder le panier
    saveCart();
    
    // Tracking analytique
    trackEvent('add_to_cart', {
      product_id: product.id,
      product_name: product.name,
      product_category: product.category,
      price: product.price,
      quantity: quantity,
      currency: cartState.currency
    });
    
    // Déclencher les événements associés
    triggerEvent('itemAdded', { productId, quantity, product });
    triggerEvent('cartUpdated', { cart: getCartSummary() });
    
    return true;
  } catch (error) {
    console.error('Error adding to cart:', error);
    throw error;
  }
}

/**
 * Retire un article du panier
 * @param {string} productId - ID du produit
 * @returns {boolean} - Succès de la suppression
 */
export function removeFromCart(productId) {
  try {
    // Vérifier si le produit est dans le panier
    const index = cartState.items.findIndex(item => item.id === productId);
    
    if (index === -1) {
      return false;
    }
    
    // Retirer l'article
    const removedItem = cartState.items.splice(index, 1)[0];
    
    // Mettre à jour les totaux
    updateCartTotals();
    
    // Sauvegarder le panier
    saveCart();
    
    // Tracking analytique
    trackEvent('remove_from_cart', {
      product_id: removedItem.id,
      product_name: removedItem.name,
      product_category: removedItem.category,
      price: removedItem.price,
      quantity: removedItem.quantity,
      currency: cartState.currency
    });
    
    // Déclencher les événements associés
    triggerEvent('itemRemoved', { productId, item: removedItem });
    triggerEvent('cartUpdated', { cart: getCartSummary() });
    
    return true;
  } catch (error) {
    console.error('Error removing from cart:', error);
    return false;
  }
}

/**
 * Met à jour la quantité d'un article
 * @param {string} productId - ID du produit
 * @param {number} quantity - Nouvelle quantité
 * @returns {Promise<boolean>} - Succès de la mise à jour
 */
export async function updateItemQuantity(productId, quantity) {
  try {
    // Vérifier si le produit est dans le panier
    const item = cartState.items.find(item => item.id === productId);
    
    if (!item) {
      return false;
    }
    
    // Vérifier si la quantité est valide
    if (quantity <= 0) {
      // Si la quantité est 0 ou négative, supprimer l'article
      return removeFromCart(productId);
    }
    
    // Vérifier le stock disponible
    const product = await getProductById(productId);
    
    if (!product) {
      throw new Error(translate('cart.product_not_found'));
    }
    
    if (quantity > product.stock) {
      // Ajuster à la quantité maximale disponible
      item.quantity = product.stock;
      
      showNotification(
        translate('cart.max_quantity_adjusted', { quantity: product.stock }),
        'warning'
      );
    } else {
      // Mettre à jour la quantité
      item.quantity = quantity;
    }
    
    // Mettre à jour les totaux
    updateCartTotals();
    
    // Sauvegarder le panier
    saveCart();
    
    // Tracking analytique
    trackEvent('update_cart_item', {
      product_id: productId,
      new_quantity: item.quantity,
      currency: cartState.currency
    });
    
    // Déclencher les événements associés
    triggerEvent('itemUpdated', { productId, quantity: item.quantity });
    triggerEvent('cartUpdated', { cart: getCartSummary() });
    
    return true;
  } catch (error) {
    console.error('Error updating item quantity:', error);
    return false;
  }
}

/**
 * Applique un code promo au panier
 * @param {string} code - Code promo
 * @returns {Promise<Object>} - Résultat de l'opération
 */
export async function applyCoupon(code) {
  if (!code || typeof code !== 'string') {
    return {
      success: false,
      message: translate('cart.invalid_coupon')
    };
  }
  
  try {
    // Nettoyer le code
    const cleanCode = code.trim().toUpperCase();
    
    // Vérifier si le code est déjà appliqué
    if (cartState.couponCode === cleanCode) {
      return {
        success: false,
        message: translate('cart.coupon_already_applied')
      };
    }
    
    // En production, vérifier le code auprès du serveur
    // Pour l'exemple, vérifier des codes statiques
    let discount = 0;
    let type = '';
    let valid = false;
    
    // Exemples de codes promo
    switch (cleanCode) {
      case 'WELCOME10':
        discount = 0.1; // 10%
        type = 'percentage';
        valid = true;
        break;
      case 'TOOLHACK20':
        discount = 0.2; // 20%
        type = 'percentage';
        valid = true;
        break;
      case 'DISCOUNT5':
        discount = 5; // $5 off
        type = 'fixed';
        valid = true;
        break;
      case 'FREESHIPPING':
        discount = cartState.shippingCost;
        type = 'shipping';
        valid = true;
        break;
    }
    
    if (!valid) {
      return {
        success: false,
        message: translate('cart.invalid_coupon')
      };
    }
    
    // Calculer la réduction
    let discountAmount = 0;
    
    if (type === 'percentage') {
      // Réduction en pourcentage
      discountAmount = cartState.subtotal * discount;
    } else if (type === 'fixed') {
      // Réduction fixe
      discountAmount = Math.min(discount, cartState.subtotal);
    } else if (type === 'shipping') {
      // Livraison gratuite
      discountAmount = cartState.shippingCost;
    }
    
    // Appliquer la réduction
    cartState.couponCode = cleanCode;
    cartState.couponDiscount = discountAmount;
    
    // Mettre à jour les totaux
    updateCartTotals();
    
    // Sauvegarder le panier
    saveCart();
    
    // Tracking analytique
    trackEvent('apply_coupon', {
      coupon_code: cleanCode,
      discount_amount: discountAmount,
      currency: cartState.currency
    });
    
    // Déclencher les événements associés
    triggerEvent('couponApplied', { code: cleanCode, discount: discountAmount });
    triggerEvent('cartUpdated', { cart: getCartSummary() });
    
    return {
      success: true,
      message: translate('cart.coupon_applied'),
      discountAmount: discountAmount,
      type: type
    };
  } catch (error) {
    console.error('Error applying coupon:', error);
    
    return {
      success: false,
      message: translate('cart.coupon_error')
    };
  }
}

/**
 * Retire le code promo appliqué
 * @returns {boolean} - Succès de la suppression
 */
export function removeCoupon() {
  if (!cartState.couponCode) {
    return false;
  }
  
  // Stocker le code avant de le supprimer
  const removedCode = cartState.couponCode;
  
  // Retirer le code promo
  cartState.couponCode = null;
  cartState.couponDiscount = 0;
  
  // Mettre à jour les totaux
  updateCartTotals();
  
  // Sauvegarder le panier
  saveCart();
  
  // Tracking analytique
  trackEvent('remove_coupon', {
    coupon_code: removedCode
  });
  
  // Déclencher les événements associés
  triggerEvent('couponRemoved', { code: removedCode });
  triggerEvent('cartUpdated', { cart: getCartSummary() });
  
  return true;
}

/**
 * Définit la méthode d'expédition
 * @param {string} methodId - ID de la méthode d'expédition
 * @returns {boolean} - Succès de l'opération
 */
export function setShippingMethod(methodId) {
  try {
    // Obtenir les méthodes d'expédition disponibles
    const availableMethods = getShippingMethods();
    
    // Trouver la méthode sélectionnée
    const method = availableMethods.find(m => m.id === methodId);
    
    if (!method) {
      return false;
    }
    
    // Appliquer la méthode d'expédition
    cartState.shippingMethod = methodId;
    cartState.shippingCost = method.cost;
    
    // Si le code promo est pour la livraison gratuite, l'appliquer
    if (cartState.couponCode && cartState.couponCode === 'FREESHIPPING') {
      cartState.shippingCost = 0;
    }
    
    // Mettre à jour les totaux
    updateCartTotals();
    
    // Sauvegarder le panier
    saveCart();
    
    // Déclencher les événements associés
    triggerEvent('shippingUpdated', { method: methodId, cost: cartState.shippingCost });
    triggerEvent('cartUpdated', { cart: getCartSummary() });
    
    return true;
  } catch (error) {
    console.error('Error setting shipping method:', error);
    return false;
  }
}

/**
 * Définit l'exemption de taxe
 * @param {boolean} exempt - État d'exemption
 * @returns {boolean} - Succès de l'opération
 */
export function setTaxExempt(exempt) {
  cartState.taxExempt = exempt;
  
  // Mettre à jour les totaux
  updateCartTotals();
  
  // Sauvegarder le panier
  saveCart();
  
  // Déclencher les événements associés
  triggerEvent('taxUpdated', { exempt });
  triggerEvent('cartUpdated', { cart: getCartSummary() });
  
  return true;
}

/**
 * Obtient le résumé du panier
 * @returns {Object} - Résumé du panier
 */
export function getCartSummary() {
  return {
    items: [...cartState.items], // Copier pour éviter les modifications directes
    itemCount: cartState.itemCount,
    totalItems: cartState.items.reduce((sum, item) => sum + item.quantity, 0),
    subtotal: cartState.subtotal,
    discount: cartState.couponDiscount,
    tax: getTaxAmount(),
    shipping: cartState.shippingCost,
    total: cartState.total,
    couponCode: cartState.couponCode,
    shippingMethod: cartState.shippingMethod,
    currency: cartState.currency,
    taxExempt: cartState.taxExempt,
    taxRate: cartState.taxRate,
    hasRestrictedItems: cartState.items.some(item => item.requiresVerification)
  };
}

/**
 * Obtient la liste des articles du panier
 * @returns {Array} - Articles du panier
 */
export function getCartItems() {
  return [...cartState.items];
}

/**
 * Obtient le nombre d'articles dans le panier
 * @returns {number} - Nombre d'articles
 */
export function getCartItemCount() {
  return cartState.itemCount;
}

/**
 * Obtient le total du panier
 * @returns {number} - Total du panier
 */
export function getCartTotal() {
  return cartState.total;
}

/**
 * Vérifie si le panier contient un produit spécifique
 * @param {string} productId - ID du produit
 * @returns {boolean} - Vrai si le produit est dans le panier
 */
export function isProductInCart(productId) {
  return cartState.items.some(item => item.id === productId);
}

/**
 * Obtient la quantité d'un produit dans le panier
 * @param {string} productId - ID du produit
 * @returns {number} - Quantité du produit
 */
export function getProductQuantity(productId) {
  const item = cartState.items.find(item => item.id === productId);
  return item ? item.quantity : 0;
}

/**
 * Vide le panier
 * @returns {boolean} - Succès de l'opération
 */
export function clearCart() {
  // Sauvegarder l'état avant de vider
  const oldState = { ...cartState };
  
  // Réinitialiser l'état
  cartState.items = [];
  cartState.couponCode = null;
  cartState.couponDiscount = 0;
  cartState.subtotal = 0;
  cartState.total = 0;
  cartState.itemCount = 0;
  
  // Sauvegarder le panier
  saveCart();
  
  // Tracking analytique
  trackEvent('clear_cart', {
    previous_item_count: oldState.itemCount,
    previous_total: oldState.total
  });
  
  // Déclencher les événements associés
  triggerEvent('cartCleared');
  triggerEvent('cartUpdated', { cart: getCartSummary() });
  
  return true;
}

/**
 * Met à jour les totaux du panier
 */
function updateCartTotals() {
  // Calculer le sous-total
  cartState.subtotal = cartState.items.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);
  
  // Nombre d'articles
  cartState.itemCount = cartState.items.length;
  
  // Calculer le total
  const tax = cartState.taxExempt ? 0 : getTaxAmount();
  
  cartState.total = cartState.subtotal - cartState.couponDiscount + tax + cartState.shippingCost;
  
  // Éviter les valeurs négatives
  cartState.total = Math.max(0, cartState.total);
}

/**
 * Obtient les méthodes d'expédition disponibles
 * @returns {Array} - Méthodes d'expédition
 */
export function getShippingMethods() {
  const subtotal = cartState.subtotal;
  
  // Méthodes de base
  const methods = [
    {
      id: 'standard',
      name: translate('shipping.standard'),
      cost: 5.99,
      estimatedDays: '5-7'
    },
    {
      id: 'express',
      name: translate('shipping.express'),
      cost: 12.99,
      estimatedDays: '2-3'
    }
  ];
  
  // Livraison gratuite pour les commandes importantes
  if (subtotal >= CART_CONFIG.freeShippingThreshold) {
    methods.push({
      id: 'free',
      name: translate('shipping.free'),
      cost: 0,
      estimatedDays: '7-10'
    });
  }
  
  // Si des articles nécessitent une vérification, proposer une livraison sécurisée
  if (cartState.items.some(item => item.requiresVerification)) {
    methods.push({
      id: 'secure',
      name: translate('shipping.secure'),
      cost: 19.99,
      estimatedDays: '3-5'
    });
  }
  
  return methods;
}

/**
 * Applique un taux de taxe en fonction de la localisation
 */
function applyTaxRate() {
  // Obtenir le pays/région
  const language = getCurrentLanguage();
  
  // Par défaut, sans taxe
  let taxRate = 0;
  
  // En production, cela serait déterminé par l'adresse de livraison
  // Pour l'exemple, on utilise la langue comme indicateur simplifié de région
  if (language in TAX_RATES) {
    taxRate = TAX_RATES[language];
  } else {
    // Taux par défaut
    taxRate = TAX_RATES.default;
  }
  
  cartState.taxRate = taxRate;
}

/**
 * Calcule le montant de la taxe
 * @returns {number} - Montant de la taxe
 */
function getTaxAmount() {
  if (cartState.taxExempt) {
    return 0;
  }
  
  // Base taxable: sous-total moins la réduction
  const taxableAmount = Math.max(0, cartState.subtotal - cartState.couponDiscount);
  
  return taxableAmount * cartState.taxRate;
}

/**
 * Ajoute un écouteur d'événement
 * @param {string} event - Nom de l'événement
 * @param {Function} callback - Fonction de rappel
 * @returns {string} - ID de l'écouteur
 */
export function addEventListener(event, callback) {
  if (typeof callback !== 'function') {
    throw new Error('Callback must be a function');
  }
  
  // Générer un ID unique pour l'écouteur
  const listenerId = Math.random().toString(36).substring(2, 10);
  
  // Créer un tableau pour cet événement s'il n'existe pas
  if (!eventListeners.has(event)) {
    eventListeners.set(event, new Map());
  }
  
  // Ajouter l'écouteur
  eventListeners.get(event).set(listenerId, callback);
  
  return listenerId;
}

/**
 * Supprime un écouteur d'événement
 * @param {string} event - Nom de l'événement
 * @param {string} listenerId - ID de l'écouteur
 * @returns {boolean} - Succès de la suppression
 */
export function removeEventListener(event, listenerId) {
  if (!eventListeners.has(event)) {
    return false;
  }
  
  return eventListeners.get(event).delete(listenerId);
}

/**
 * Déclenche un événement
 * @param {string} event - Nom de l'événement
 * @param {Object} [data={}] - Données de l'événement
 */
function triggerEvent(event, data = {}) {
  if (!eventListeners.has(event)) {
    return;
  }
  
  // Appeler tous les écouteurs pour cet événement
  for (const callback of eventListeners.get(event).values()) {
    try {
      callback(data);
    } catch (error) {
      console.error(`Error in cart event listener (${event}):`, error);
    }
  }
  
  // Également déclencher un événement DOM pour l'interopérabilité
  document.dispatchEvent(new CustomEvent('cart-' + event, {
    detail: data
  }));
}

/**
 * Vérifie si un produit peut être ajouté au panier
 * @param {string} productId - ID du produit
 * @param {number} [quantity=1] - Quantité demandée
 * @returns {Promise<Object>} - Résultat de la vérification
 */
export async function canAddToCart(productId, quantity = 1) {
  try {
    // Vérifier si le produit existe
    const product = await getProductById(productId);
    
    if (!product) {
      return {
        canAdd: false,
        reason: 'product_not_found',
        message: translate('cart.product_not_found')
      };
    }
    
    // Vérifier le stock
    if (product.stock <= 0) {
      return {
        canAdd: false,
        reason: 'out_of_stock',
        message: translate('cart.out_of_stock')
      };
    }
    
    // Vérifier la quantité déjà dans le panier
    const currentQty = getProductQuantity(productId);
    const totalQty = currentQty + quantity;
    
    if (totalQty > product.stock) {
      return {
        canAdd: false,
        reason: 'insufficient_stock',
        message: translate('cart.only_x_available', { quantity: product.stock }),
        availableQuantity: product.stock,
        currentInCart: currentQty
      };
    }
    
    // Vérifier la quantité maximale par commande si définie
    if (CART_CONFIG.maxQuantityPerItem && totalQty > CART_CONFIG.maxQuantityPerItem) {
      return {
        canAdd: false,
        reason: 'max_quantity_per_item',
        message: translate('cart.max_quantity_per_item', { quantity: CART_CONFIG.maxQuantityPerItem }),
        maxAllowed: CART_CONFIG.maxQuantityPerItem,
        currentInCart: currentQty
      };
    }
    
    return {
      canAdd: true,
      availableQuantity: product.stock,
      product: product
    };
  } catch (error) {
    console.error('Error checking if can add to cart:', error);
    
    return {
      canAdd: false,
      reason: 'error',
      message: translate('cart.generic_error')
    };
  }
}

/**
 * Prépare le panier pour la commande
 * @returns {Object} - Données de commande
 */
export function prepareOrder() {
  if (cartState.items.length === 0) {
    throw new Error(translate('cart.empty'));
  }
  
    // Créer l'objet de commande
  const order = {
    items: cartState.items.map(item => ({
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: item.quantity,
      total: item.price * item.quantity,
      sku: item.sku
    })),
    couponCode: cartState.couponCode,
    discount: cartState.couponDiscount,
    subtotal: cartState.subtotal,
    tax: getTaxAmount(),
    taxRate: cartState.taxRate,
    taxExempt: cartState.taxExempt,
    shipping: cartState.shippingCost,
    shippingMethod: cartState.shippingMethod,
    total: cartState.total,
    currency: cartState.currency,
    itemCount: cartState.items.length,
    totalItems: cartState.items.reduce((sum, item) => sum + item.quantity, 0),
    hasRestrictedItems: cartState.items.some(item => item.requiresVerification),
    createdAt: new Date().toISOString(),
    orderId: generateOrderId()
  };
  
  return order;
}

/**
 * Génère un identifiant de commande unique
 * @returns {string} - ID de commande
 */
function generateOrderId() {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 8);
  return `TH-${timestamp}-${randomStr}`.toUpperCase();
}

/**
 * Vérifie la disponibilité des articles du panier
 * @returns {Promise<Object>} - Résultat de la vérification
 */
export async function validateCartItems() {
  try {
    const unavailableItems = [];
    const updatedItems = [];
    
    // Vérifier chaque article
    for (const item of cartState.items) {
      const product = await getProductById(item.id);
      
      if (!product) {
        // Le produit n'existe plus
        unavailableItems.push({
          id: item.id,
          name: item.name,
          reason: 'product_not_found'
        });
        continue;
      }
      
      if (product.stock <= 0) {
        // Produit en rupture de stock
        unavailableItems.push({
          id: item.id,
          name: item.name,
          reason: 'out_of_stock'
        });
        continue;
      }
      
      if (item.quantity > product.stock) {
        // Stock insuffisant
        updatedItems.push({
          id: item.id,
          name: item.name,
          oldQuantity: item.quantity,
          newQuantity: product.stock,
          reason: 'insufficient_stock'
        });
      }
      
      // Vérifier si le prix a changé
      if (product.price !== item.price) {
        updatedItems.push({
          id: item.id,
          name: item.name,
          oldPrice: item.price,
          newPrice: product.price,
          reason: 'price_changed'
        });
      }
    }
    
    // Si des modifications sont nécessaires, mettre à jour le panier
    if (updatedItems.length > 0) {
      // Mise à jour des quantités et prix
      for (const update of updatedItems) {
        const item = cartState.items.find(i => i.id === update.id);
        
        if (item) {
          if (update.reason === 'insufficient_stock') {
            item.quantity = update.newQuantity;
          }
          
          if (update.reason === 'price_changed') {
            item.price = update.newPrice;
          }
        }
      }
      
      // Mettre à jour les totaux
      updateCartTotals();
      
      // Sauvegarder le panier
      saveCart();
      
      // Déclencher l'événement de mise à jour
      triggerEvent('cartUpdated', { cart: getCartSummary() });
    }
    
    // Si des articles doivent être supprimés
    if (unavailableItems.length > 0) {
      // Supprimer les articles non disponibles
      cartState.items = cartState.items.filter(item => 
        !unavailableItems.some(unavailable => unavailable.id === item.id)
      );
      
      // Mettre à jour les totaux
      updateCartTotals();
      
      // Sauvegarder le panier
      saveCart();
      
      // Déclencher l'événement de mise à jour
      triggerEvent('cartUpdated', { cart: getCartSummary() });
    }
    
    return {
      isValid: unavailableItems.length === 0 && updatedItems.length === 0,
      unavailableItems,
      updatedItems
    };
  } catch (error) {
    console.error('Error validating cart:', error);
    
    return {
      isValid: false,
      error: translate('cart.validation_error')
    };
  }
}

/**
 * Change la devise du panier
 * @param {string} currencyCode - Code de la devise
 * @returns {boolean} - Succès de l'opération
 */
export function changeCurrency(currencyCode) {
  // Vérifier si le code de devise est valide
  const validCurrencies = ['USD', 'EUR', 'GBP', 'TON', 'BTC'];
  
  if (!validCurrencies.includes(currencyCode)) {
    return false;
  }
  
  // Mettre à jour la devise
  cartState.currency = currencyCode;
  
  // Sauvegarder le panier
  saveCart();
  
  // Déclencher l'événement de mise à jour
  triggerEvent('currencyChanged', { currency: currencyCode });
  triggerEvent('cartUpdated', { cart: getCartSummary() });
  
  return true;
}

/**
 * Obtient le statut détaillé du panier
 * @returns {Object} - Statut du panier
 */
export function getCartStatus() {
  return {
    isEmpty: cartState.items.length === 0,
    needsShipping: cartState.items.length > 0 && !cartState.shippingMethod,
    hasRestrictedItems: cartState.items.some(item => item.requiresVerification),
    total: cartState.total,
    itemCount: cartState.items.length,
    cartState: { ...cartState }
  };
}

/**
 * Sauvegarde le panier actuel comme commande récente
 * @returns {string} - ID de la commande sauvegardée
 */
export function saveCartAsRecentOrder() {
  try {
    // Créer un objet de commande à partir du panier
    const order = prepareOrder();
    
    // Récupérer les commandes récentes existantes
    let recentOrders = [];
    
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.RECENT_ORDERS);
      if (saved) {
        recentOrders = JSON.parse(saved);
      }
    } catch (e) {
      // Ignorer les erreurs
      console.warn('Error loading recent orders:', e);
    }
    
    // Ajouter la nouvelle commande
    recentOrders.unshift({
      id: order.orderId,
      date: order.createdAt,
      total: order.total,
      currency: order.currency,
      items: order.totalItems
    });
    
    // Limiter à 5 commandes récentes
    recentOrders = recentOrders.slice(0, 5);
    
    // Sauvegarder
    localStorage.setItem(STORAGE_KEYS.RECENT_ORDERS, JSON.stringify(recentOrders));
    
    return order.orderId;
  } catch (error) {
    console.error('Error saving recent order:', error);
    return null;
  }
}

/**
 * Restaure le panier à partir d'une commande précédente
 * @param {Object} orderData - Données de la commande
 * @returns {boolean} - Succès de l'opération
 */
export function restoreCartFromOrder(orderData) {
  try {
    if (!orderData || !Array.isArray(orderData.items)) {
      return false;
    }
    
    // Copier les articles
    cartState.items = orderData.items.map(item => ({
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: item.quantity,
      image: item.image || '',
      sku: item.sku || '',
      category: item.category || ''
    }));
    
    // Restaurer les autres informations
    if (orderData.shippingMethod) {
      cartState.shippingMethod = orderData.shippingMethod;
      cartState.shippingCost = orderData.shipping || 0;
    }
    
    // Mettre à jour les totaux
    updateCartTotals();
    
    // Sauvegarder le panier
    saveCart();
    
    // Déclencher l'événement de mise à jour
    triggerEvent('cartUpdated', { cart: getCartSummary() });
    
    return true;
  } catch (error) {
    console.error('Error restoring cart from order:', error);
    return false;
  }
}

/**
 * Exporte le panier au format JSON
 * @returns {string} - Panier au format JSON
 */
export function exportCartToJson() {
  try {
    return JSON.stringify(cartState);
  } catch (error) {
    console.error('Error exporting cart to JSON:', error);
    return null;
  }
}

/**
 * Importe un panier depuis un fichier JSON
 * @param {string} jsonData - Données JSON du panier
 * @returns {boolean} - Succès de l'importation
 */
export function importCartFromJson(jsonData) {
  try {
    const importedCart = JSON.parse(jsonData);
    
    // Valider la structure
    if (!importedCart || !Array.isArray(importedCart.items)) {
      return false;
    }
    
    // Copier les données
    cartState.items = importedCart.items;
    cartState.couponCode = importedCart.couponCode || null;
    cartState.couponDiscount = importedCart.couponDiscount || 0;
    cartState.shippingMethod = importedCart.shippingMethod || null;
    cartState.shippingCost = importedCart.shippingCost || 0;
    cartState.taxExempt = importedCart.taxExempt || false;
    cartState.currency = importedCart.currency || 'USD';
    
    // Mettre à jour les totaux
    updateCartTotals();
    
    // Sauvegarder le panier
    saveCart();
    
    // Déclencher l'événement de mise à jour
    triggerEvent('cartUpdated', { cart: getCartSummary() });
    
    return true;
  } catch (error) {
    console.error('Error importing cart from JSON:', error);
    return false;
  }
}

/**
 * Ajoute plusieurs articles au panier
 * @param {Array} products - Liste de produits à ajouter
 * @returns {Promise<Object>} - Résultat de l'opération
 */
export async function addMultipleToCart(products) {
  if (!Array.isArray(products) || products.length === 0) {
    return {
      success: false,
      message: translate('cart.no_products_selected')
    };
  }
  
  try {
    const results = {
      added: [],
      failed: []
    };
    
    // Ajouter chaque produit
    for (const product of products) {
      if (!product.id) continue;
      
      const quantity = product.quantity || 1;
      
      try {
        const success = await addToCart(product.id, quantity);
        
        if (success) {
          results.added.push({
            id: product.id,
            quantity
          });
        } else {
          results.failed.push({
            id: product.id,
            reason: 'unknown'
          });
        }
      } catch (error) {
        results.failed.push({
          id: product.id,
          reason: error.message || 'error'
        });
      }
    }
    
    return {
      success: results.added.length > 0,
      added: results.added.length,
      failed: results.failed.length,
      message: translate('cart.multiple_items_added', { count: results.added.length }),
      details: results
    };
  } catch (error) {
    console.error('Error adding multiple products to cart:', error);
    
    return {
      success: false,
      message: translate('cart.multiple_items_error'),
      error: error.message
    };
  }
}

/**
 * Crée une liste de souhaits à partir du panier
 * @param {string} [name=''] - Nom de la liste de souhaits
 * @returns {boolean} - Succès de l'opération
 */
export function saveCartAsWishlist(name = '') {
  try {
    if (cartState.items.length === 0) {
      return false;
    }
    
    // Créer l'objet de liste de souhaits
    const wishlist = {
      name: name || `Wishlist ${new Date().toLocaleDateString()}`,
      date: new Date().toISOString(),
      items: cartState.items.map(item => ({
        id: item.id,
        quantity: item.quantity
      }))
    };
    
    // Récupérer les listes de souhaits existantes
    let wishlists = [];
    
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WISHLISTS);
      if (saved) {
        wishlists = JSON.parse(saved);
      }
    } catch (e) {
      // Ignorer les erreurs
      console.warn('Error loading wishlists:', e);
    }
    
    // Ajouter la nouvelle liste
    wishlists.push(wishlist);
    
    // Limiter à 10 listes de souhaits
    if (wishlists.length > 10) {
      wishlists.shift();
    }
    
    // Sauvegarder
    localStorage.setItem(STORAGE_KEYS.WISHLISTS, JSON.stringify(wishlists));
    
    return true;
  } catch (error) {
    console.error('Error saving wishlist:', error);
    return false;
  }
}

// Exporter les fonctions principales
export default {
  initCartManager,
  addToCart,
  removeFromCart,
  updateItemQuantity,
  applyCoupon,
  removeCoupon,
  clearCart,
  getCartSummary,
  getCartItems,
  getCartItemCount,
  getCartTotal,
  setShippingMethod,
  getShippingMethods,
  prepareOrder,
  validateCartItems,
  isProductInCart,
  getProductQuantity,
  addEventListener,
  removeEventListener,
  setTaxExempt,
  changeCurrency,
  addMultipleToCart,
  saveCartAsWishlist
};

