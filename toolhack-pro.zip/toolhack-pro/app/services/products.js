// app/services/products.js

/**
 * Service de gestion des produits
 * Gère le chargement, le filtrage et l'accès aux produits du catalogue
 */

import { API_ENDPOINTS, PRODUCT_CATEGORIES, STORAGE_KEYS, REFRESH_INTERVALS } from '../config/constants.js';

// État du service
let products = [];
let categories = Object.values(PRODUCT_CATEGORIES);
let isInitialized = false;
let lastUpdated = null;
let isLoading = false;
let lastError = null;
let featuredProducts = [];
let viewedProducts = [];

/**
 * Initialise le service de produits
 * @param {boolean} [forceRefresh=false] - Forcer le rafraîchissement des données
 * @returns {Promise<boolean>} - Succès de l'initialisation
 */
export async function initProductsService(forceRefresh = false) {
  // Éviter une double initialisation simultanée
  if (isLoading) {
    return new Promise((resolve) => {
      // Attendre que le chargement en cours se termine
      const checkInterval = setInterval(() => {
        if (!isLoading) {
          clearInterval(checkInterval);
          resolve(isInitialized);
        }
      }, 100);
    });
  }
  
  // Si déjà initialisé et pas de rafraîchissement forcé, retourner l'état actuel
  if (isInitialized && !forceRefresh && products.length > 0) {
    // Vérifier si les données sont assez récentes
    const now = new Date();
    if (lastUpdated && (now - lastUpdated) < REFRESH_INTERVALS.PRODUCTS) {
      loadViewedProducts(); // Charger les produits consultés
      return true;
    }
  }
  
  isLoading = true;
  
  try {
    await loadProducts();
    await loadViewedProducts();
    
    isInitialized = true;
    lastUpdated = new Date();
    isLoading = false;
    
    // Notifier que les produits sont chargés
    document.dispatchEvent(new CustomEvent('products-loaded', { 
      detail: { count: products.length }
    }));
    
    return true;
  } catch (error) {
    console.error('Error initializing products service:', error);
    lastError = error.message || 'Failed to load products';
    isLoading = false;
    
    // Tenter de charger des données en cache
    if (await loadCachedProducts()) {
      isInitialized = true;
      return true;
    }
    
    return false;
  }
}

/**
 * Charge les produits depuis l'API ou le fichier de données
 * @returns {Promise<void>}
 */
async function loadProducts() {
  try {
    let data;
    
    // Essayer d'abord de charger depuis l'API si disponible
    try {
      const response = await fetch(`${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.PRODUCTS}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        },
        // Timeout de 5 secondes
        signal: AbortSignal.timeout(5000)
      });
      
      if (response.ok) {
        data = await response.json();
      } else {
        throw new Error(`API responded with status: ${response.status}`);
      }
    } catch (apiError) {
      console.warn('API fetch failed, falling back to local data:', apiError);
      
      // Fallback vers le fichier local
      const response = await fetch('/produits.json');
      if (!response.ok) {
        throw new Error(`Failed to load products: ${response.status}`);
      }
      data = await response.json();
    }
    
    // Traiter et formater les données
    if (data && Array.isArray(data)) {
      products = data.map(formatProductData);
      
      // Définir les produits en vedette (les 3 premiers de chaque catégorie)
      featuredProducts = [];
      categories.forEach(category => {
        const categoryProducts = products.filter(p => p.category === category.id)
                                         .slice(0, 3);
        featuredProducts.push(...categoryProducts);
      });
      
      // Limiter à 6 produits en vedette maximun
      featuredProducts = featuredProducts.slice(0, 6);
      
      // Sauvegarder dans le cache local
      cacheProducts(products);
      
      console.log(`Loaded ${products.length} products from ${data === products ? 'API' : 'local file'}`);
    } else {
      throw new Error('Invalid product data format');
    }
  } catch (error) {
    console.error('Error loading products:', error);
    throw error;
  }
}

/**
 * Formate les données de produit pour normaliser la structure
 * @param {Object} product - Données brutes du produit
 * @returns {Object} - Produit formaté
 */
function formatProductData(product) {
  // Assurer une structure cohérente pour tous les produits
  return {
    id: product.id || `product_${Math.random().toString(36).substr(2, 9)}`,
    name: product.name || 'Unnamed Product',
    description: product.description || '',
    shortDescription: product.shortDescription || product.description?.substring(0, 100) || '',
    price: parseFloat(product.price) || 0,
    originalPrice: parseFloat(product.originalPrice || product.price) || 0,
    category: product.category || 'other',
    image: product.image || '/assets/images/placeholder.png',
    images: Array.isArray(product.images) ? product.images : 
           (product.image ? [product.image] : ['/assets/images/placeholder.png']),
    stock: parseInt(product.stock, 10) || 0,
    rating: parseFloat(product.rating) || 0,
    reviewCount: parseInt(product.reviewCount, 10) || 0,
    features: Array.isArray(product.features) ? product.features : [],
    specs: product.specs || {},
    isNew: !!product.isNew,
    isFeatured: !!product.isFeatured,
    isRestricted: !!product.isRestricted,
    requiresVerification: !!product.requiresVerification,
    sku: product.sku || '',
    tags: Array.isArray(product.tags) ? product.tags : [],
    relatedProducts: Array.isArray(product.relatedProducts) ? product.relatedProducts : [],
    addedDate: product.addedDate || new Date().toISOString()
  };
}

/**
 * Met en cache les produits dans le stockage local
 * @param {Array} productsData - Données des produits
 */
function cacheProducts(productsData) {
  try {
    const dataToCache = {
      products: productsData,
      timestamp: new Date().toISOString()
    };
    
    localStorage.setItem('cached_products', JSON.stringify(dataToCache));
  } catch (error) {
    console.warn('Failed to cache products:', error);
  }
}

/**
 * Charge les produits depuis le cache
 * @returns {Promise<boolean>} - Succès du chargement
 */
async function loadCachedProducts() {
  try {
    const cachedData = localStorage.getItem('cached_products');
    
    if (!cachedData) {
      return false;
    }
    
    const parsedData = JSON.parse(cachedData);
    
    // Vérifier si le cache est trop ancien (plus de 24h)
    const cachedTime = new Date(parsedData.timestamp);
    const now = new Date();
    const maxAge = 24 * 60 * 60 * 1000; // 24 heures
    
    if ((now - cachedTime) > maxAge) {
      console.log('Cached products too old, clearing cache');
      localStorage.removeItem('cached_products');
      return false;
    }
    
    // Utiliser les données en cache
    products = parsedData.products.map(formatProductData);
    
    // Définir les produits en vedette
    featuredProducts = [];
    categories.forEach(category => {
      const categoryProducts = products.filter(p => p.category === category.id)
                                       .slice(0, 3);
      featuredProducts.push(...categoryProducts);
    });
    
    featuredProducts = featuredProducts.slice(0, 6);
    
    console.log(`Loaded ${products.length} products from cache`);
    return true;
  } catch (error) {
    console.error('Error loading cached products:', error);
    return false;
  }
}

/**
 * Charge les produits consultés depuis le stockage local
 */
function loadViewedProducts() {
  try {
    const viewedData = localStorage.getItem(STORAGE_KEYS.VIEWED_PRODUCTS);
    
    if (!viewedData) {
      viewedProducts = [];
      return;
    }
    
    const parsed = JSON.parse(viewedData);
    
    // Vérifier que les IDs existent dans les produits actuels
    viewedProducts = parsed.filter(id => products.some(p => p.id === id))
                          .slice(0, 10); // Limiter à 10 produits
  } catch (error) {
    console.warn('Error loading viewed products:', error);
    viewedProducts = [];
  }
}

/**
 * Obtient tous les produits
 * @returns {Array} - Liste des produits
 */
export function getAllProducts() {
  return [...products];
}

/**
 * Obtient un produit par son ID
 * @param {string} productId - ID du produit
 * @returns {Object|null} - Produit ou null si non trouvé
 */
export function getProductById(productId) {
  if (!productId) return null;
  
  const product = products.find(p => p.id === productId);
  
  if (product) {
    // Ajouter aux produits consultés
    addToViewedProducts(productId);
  }
  
  return product || null;
}

/**
 * Obtient les produits par catégorie
 * @param {string} categoryId - ID de la catégorie
 * @returns {Array} - Liste de produits
 */
export function getProductsByCategory(categoryId) {
  if (!categoryId) return [];
  
  return products.filter(p => p.category === categoryId);
}

/**
 * Obtient les produits en vedette
 * @param {number} [limit=6] - Nombre maximum de produits
 * @returns {Array} - Liste de produits en vedette
 */
export function getFeaturedProducts(limit = 6) {
  // Si les produits en vedette n'ont pas été définis
  if (featuredProducts.length === 0) {
    // Sélectionner les produits avec isFeatured = true ou avec les meilleures notes
    const featured = products.filter(p => p.isFeatured)
                            .slice(0, limit);
    
    // Si pas assez de produits en vedette, compléter avec les mieux notés
    if (featured.length < limit) {
      const topRated = products.filter(p => !p.isFeatured)
                              .sort((a, b) => b.rating - a.rating)
                              .slice(0, limit - featured.length);
      
      return [...featured, ...topRated];
    }
    
    return featured;
  }
  
  return featuredProducts.slice(0, limit);
}

/**
 * Obtient les nouveaux produits
 * @param {number} [limit=6] - Nombre maximum de produits
 * @returns {Array} - Liste de nouveaux produits
 */
export function getNewProducts(limit = 6) {
  // Trier par date d'ajout (du plus récent au plus ancien)
  return products.filter(p => p.isNew)
                .slice(0, limit);
}

/**
 * Obtient les produits similaires à un produit donné
 * @param {string} productId - ID du produit
 * @param {number} [limit=4] - Nombre maximum de produits
 * @returns {Array} - Liste de produits similaires
 */
export function getSimilarProducts(productId, limit = 4) {
  const product = getProductById(productId);
  
  if (!product) return [];
  
  // Si le produit a des produits liés spécifiés
  if (product.relatedProducts && product.relatedProducts.length > 0) {
    return product.relatedProducts
      .map(relatedId => getProductById(relatedId))
      .filter(p => p !== null)
      .slice(0, limit);
  }
  
  // Sinon, trouver des produits de la même catégorie
  return products.filter(p => 
    p.id !== productId && 
    p.category === product.category
  ).slice(0, limit);
}

/**
 * Recherche des produits selon des critères
 * @param {string} query - Texte de recherche
 * @param {Object} [filters={}] - Filtres supplémentaires
 * @returns {Array} - Résultats de recherche
 */
export function searchProducts(query, filters = {}) {
  if (!query && Object.keys(filters).length === 0) {
    return getAllProducts();
  }
  
  // Convertir la requête en minuscules pour la recherche insensible à la casse
  const searchQuery = query ? query.toLowerCase() : '';
  
  // Filtrer les produits
  return products.filter(product => {
    // Si une requête est spécifiée, rechercher dans le nom et la description
    if (searchQuery) {
      const nameMatch = product.name.toLowerCase().includes(searchQuery);
      const descMatch = product.description.toLowerCase().includes(searchQuery);
      const tagMatch = product.tags.some(tag => tag.toLowerCase().includes(searchQuery));
      
      if (!(nameMatch || descMatch || tagMatch)) {
        return false;
      }
    }
    
    // Appliquer les filtres supplémentaires
    for (const [key, value] of Object.entries(filters)) {
      switch (key) {
        case 'category':
          if (value && product.category !== value) return false;
          break;
        case 'minPrice':
          if (product.price < value) return false;
          break;
        case 'maxPrice':
          if (product.price > value) return false;
          break;
        case 'inStock':
          if (value === true && product.stock <= 0) return false;
          break;
        case 'isNew':
          if (value === true && !product.isNew) return false;
          break;
        case 'tags':
          if (value && Array.isArray(value) && value.length > 0) {
            if (!value.some(tag => product.tags.includes(tag))) return false;
          }
          break;
        case 'minRating':
          if (product.rating < value) return false;
          break;
      }
    }
    
    return true;
  });
}

/**
 * Obtient toutes les catégories
 * @returns {Array} - Liste des catégories
 */
export function getAllCategories() {
  return [...categories];
}

/**
 * Obtient une catégorie par son ID
 * @param {string} categoryId - ID de la catégorie
 * @returns {Object|null} - Catégorie ou null si non trouvée
 */
export function getCategoryById(categoryId) {
  return categories.find(c => c.id === categoryId) || null;
}

/**
 * Obtient la plage de prix des produits
 * @returns {Object} - Prix min et max
 */
export function getPriceRange() {
  if (products.length === 0) {
    return { min: 0, max: 0 };
  }
  
  const prices = products.map(p => p.price);
  return {
    min: Math.min(...prices),
    max: Math.max(...prices)
  };
}

/**
 * Obtient tous les tags distincts utilisés par les produits
 * @returns {Array<string>} - Liste des tags
 */
export function getAllTags() {
  const tagsSet = new Set();
  
  products.forEach(product => {
    if (product.tags && Array.isArray(product.tags)) {
      product.tags.forEach(tag => tagsSet.add(tag));
    }
  });
  
  return [...tagsSet];
}

/**
 * Vérifie la disponibilité d'un produit
 * @param {string} productId - ID du produit
 * @returns {Promise<Object>} - Statut de disponibilité
 */
export async function checkProductAvailability(productId) {
  const product = getProductById(productId);
  
  if (!product) {
    return {
      available: false,
      reason: 'product_not_found',
      stock: 0
    };
  }
  
  // Vérifier d'abord localement
  if (product.stock <= 0) {
    return {
      available: false,
      reason: 'out_of_stock',
      stock: 0
    };
  }
  
  // Si le produit nécessite une vérification
  if (product.requiresVerification) {
    // Vérifier si l'utilisateur est vérifié (à implémenter selon votre logique)
    const isUserVerified = await checkUserVerification();
    
    if (!isUserVerified) {
      return {
        available: false,
        reason: 'verification_required',
        stock: product.stock
      };
    }
  }
  
  // Vérifier avec l'API en temps réel si disponible
  try {
    const response = await fetch(`${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.PRODUCT_AVAILABILITY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({ productId }),
      signal: AbortSignal.timeout(3000) // Timeout de 3 secondes
    });
    
    if (response.ok) {
      const data = await response.json();
      return {
        available: data.available,
        reason: data.reason || null,
        stock: data.stock || product.stock
      };
    }
  } catch (error) {
    console.warn('Failed to check real-time availability, using local data:', error);
  }
  
  // Fallback vers les données locales
  return {
    available: true,
    reason: null,
    stock: product.stock
  };
}

/**
 * Vérifie si l'utilisateur est vérifié pour les produits restreints
 * @returns {Promise<boolean>} - Statut de vérification
 */
async function checkUserVerification() {
  // Cette fonction devrait vérifier l'état de vérification de l'utilisateur
  // Pour cet exemple, nous utilisons une vérification simple du stockage local
  try {
    const verificationStatus = localStorage.getItem(STORAGE_KEYS.VERIFICATION_STATUS);
    return verificationStatus === 'verified';
  } catch (e) {
    console.warn('Error checking verification status:', e);
    return false;
  }
}

/**
 * Ajoute un produit aux produits consultés
 * @param {string} productId - ID du produit
 */
function addToViewedProducts(productId) {
  // Éviter les doublons
  viewedProducts = viewedProducts.filter(id => id !== productId);
  
  // Ajouter en tête de liste
  viewedProducts.unshift(productId);
  
  // Limiter à 10 produits
  viewedProducts = viewedProducts.slice(0, 10);
  
  // Sauvegarder dans le stockage local
  try {
    localStorage.setItem(STORAGE_KEYS.VIEWED_PRODUCTS, JSON.stringify(viewedProducts));
  } catch (e) {
    console.warn('Error saving viewed products:', e);
  }
}

/**
 * Obtient les produits récemment consultés
 * @param {number} [limit=4] - Nombre maximum de produits
 * @returns {Array} - Liste de produits consultés
 */
export function getRecentlyViewedProducts(limit = 4) {
  // Convertir les IDs en objets produit
  return viewedProducts
    .map(id => getProductById(id))
    .filter(product => product !== null)
    .slice(0, limit);
}

/**
 * Obtient des statistiques sur le catalogue
 * @returns {Object} - Statistiques du catalogue
 */
export function getCatalogStats() {
  // Compter les produits par catégorie
  const categoryCounts = {};
  categories.forEach(cat => {
    categoryCounts[cat.id] = 0;
  });
  
  products.forEach(product => {
    if (categoryCounts[product.category] !== undefined) {
      categoryCounts[product.category]++;
    }
  });
  
  // Calculer d'autres statistiques
  const totalProducts = products.length;
  const inStockCount = products.filter(p => p.stock > 0).length;
  const newProductsCount = products.filter(p => p.isNew).length;
  const averagePrice = products.length > 0 
    ? products.reduce((sum, p) => sum + p.price, 0) / products.length
    : 0;
  
  return {
    total: totalProducts,
    inStock: inStockCount,
    outOfStock: totalProducts - inStockCount,
    newProducts: newProductsCount,
    averagePrice: averagePrice,
    categories: categoryCounts
  };
}

/**
 * Vérifie si le service est initialisé
 * @returns {boolean} - État d'initialisation
 */
export function isProductServiceInitialized() {
  return isInitialized;
}

/**
 * Obtient l'erreur de chargement la plus récente
 * @returns {string|null} - Message d'erreur
 */
export function getLastError() {
  return lastError;
}

/**
 * Vérifie si le service est en cours de chargement
 * @returns {boolean} - État de chargement
 */
export function isProductServiceLoading() {
  return isLoading;
}

// Exporter les fonctions principales
export default {
  initProductsService,
  getAllProducts,
  getProductById,
  getProductsByCategory,
  getFeaturedProducts,
  getNewProducts,
  getSimilarProducts,
  searchProducts,
  getAllCategories,
  getCategoryById,
  getPriceRange,
  getAllTags,
  checkProductAvailability,
  getRecentlyViewedProducts,
  getCatalogStats,
  isProductServiceInitialized,
  isProductServiceLoading,
  getLastError
};
