// app/services/analytics.js

/**
 * Service d'analytique pour le suivi des événements
 * Implémente un système d'analytique respectueux de la vie privée
 */

import { ANALYTICS_CONFIG, FEATURES, STORAGE_KEYS } from '../config/constants.js';
import { getCurrentLanguage } from '../utils/i18n.js';
import { isRunningInTelegram, getCurrentUser } from '../utils/telegram-api.js';

// État du service d'analytique
const analyticsState = {
  isInitialized: false,
  isEnabled: ANALYTICS_CONFIG.enabled,
  sessionId: null,
  clientId: null,
  eventQueue: [],
  lastSentTimestamp: null,
  isOffline: false,
  deviceInfo: null,
  userType: 'anonymous',
  startTime: Date.now(),
  pageViewCount: 0,
  isDevEnvironment: process.env.NODE_ENV !== 'production'
};

// Types d'événements tracés
const EVENT_TYPES = {
  PAGE_VIEW: 'page_view',
  PRODUCT_VIEW: 'product_view',
  PRODUCT_CLICK: 'product_click',
  ADD_TO_CART: 'add_to_cart',
  REMOVE_FROM_CART: 'remove_from_cart',
  BEGIN_CHECKOUT: 'begin_checkout',
  PURCHASE: 'purchase',
  SEARCH: 'search',
  FILTER_CHANGE: 'filter_change',
  CATEGORY_VIEW: 'category_view',
  USER_VERIFY: 'user_verify',
  APP_ERROR: 'app_error',
  WALLET_CONNECT: 'wallet_connect',
  PERFORMANCE: 'performance'
};

/**
 * Initialise le service d'analytique
 * @param {Object} userData - Données utilisateur optionnelles
 * @returns {Promise<boolean>} - Succès de l'initialisation
 */
export async function setupAnalytics(userData = null) {
  // Ne pas initialiser si les analytics sont désactivés
  if (!ANALYTICS_CONFIG.enabled) {
    console.log('Analytics is disabled by configuration');
    analyticsState.isEnabled = false;
    return false;
  }
  
  // Ne pas initialiser en environnement de développement si configuré ainsi
  if (ANALYTICS_CONFIG.excludeDevEnvironment && analyticsState.isDevEnvironment) {
    console.log('Analytics disabled in development environment');
    analyticsState.isEnabled = false;
    return false;
  }
  
  try {
    // Vérifier si l'utilisateur a désactivé l'analytique
    const userPref = localStorage.getItem('analytics_opt_out');
    if (userPref === 'true') {
      console.log('User has opted out of analytics');
      analyticsState.isEnabled = false;
      return false;
    }
    
    // Initialiser l'ID client unique s'il n'existe pas déjà
    if (!analyticsState.clientId) {
      analyticsState.clientId = getClientId();
    }
    
    // Créer un nouvel ID de session pour chaque initialisation
    analyticsState.sessionId = generateSessionId();
    
    // Collecter des informations de base sur l'appareil
    analyticsState.deviceInfo = collectDeviceInfo();
    
    // Déterminer le type d'utilisateur
    determineUserType(userData);
    
    // Restaurer les événements en attente
    await restoreQueuedEvents();
    
    // Configurer les écouteurs d'événements
    setupEventListeners();
    
    // Configurer le processus d'envoi périodique
    setupPeriodicSending();
    
    // Vérifier l'état de la connexion
    analyticsState.isOffline = !navigator.onLine;
    
    analyticsState.isInitialized = true;
    console.log('Analytics service initialized');
    
    // Envoyer un événement de démarrage d'application
    trackEvent('app_start', {
      session_id: analyticsState.sessionId,
      referrer: document.referrer || 'direct',
      in_telegram: isRunningInTelegram()
    });
    
    return true;
  } catch (error) {
    console.error('Error initializing analytics:', error);
    return false;
  }
}

/**
 * Obtient ou génère l'ID client
 * @returns {string} - ID client unique
 */
function getClientId() {
  try {
    let clientId = localStorage.getItem(STORAGE_KEYS.ANALYTICS_CLIENT_ID);
    
    if (!clientId) {
      // Générer un ID unique
      clientId = 'th_' + Math.random().toString(36).substring(2, 15) + 
                 Math.random().toString(36).substring(2, 15);
      localStorage.setItem(STORAGE_KEYS.ANALYTICS_CLIENT_ID, clientId);
    }
    
    return clientId;
  } catch (e) {
    // Fallback si le stockage local n'est pas disponible
    return 'th_' + Math.random().toString(36).substring(2, 15);
  }
}

/**
 * Génère un ID de session unique
 * @returns {string} - ID de session
 */
function generateSessionId() {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 6);
  return `${timestamp}-${random}`;
}

/**
 * Collecte des informations de base sur l'appareil
 * @returns {Object} - Informations sur l'appareil
 */
function collectDeviceInfo() {
  // Collecter seulement des informations non-sensibles
  return {
    viewport: {
      width: window.innerWidth,
      height: window.innerHeight
    },
    userAgent: anonymizeUserAgent(navigator.userAgent),
    language: navigator.language,
    platform: getPlatformType(),
    deviceType: getDeviceType(),
    isInTelegram: isRunningInTelegram(),
    timeZoneOffset: new Date().getTimezoneOffset(),
    colorScheme: window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light',
    connectionType: getConnectionType()
  };
}

/**
 * Détermine le type d'utilisateur
 * @param {Object} userData - Données utilisateur
 */
function determineUserType(userData) {
  if (userData) {
    analyticsState.userType = 'authenticated';
    
    // Si les données ont un niveau d'accès, l'utiliser
    if (userData.accessLevel) {
      analyticsState.userType = userData.accessLevel;
    }
  } else if (isRunningInTelegram()) {
    // Utilisateur Telegram
    const telegramUser = getCurrentUser();
    if (telegramUser) {
      analyticsState.userType = telegramUser.isPremium ? 'telegram_premium' : 'telegram';
    }
  } else {
    // Vérifier s'il y a un token dans le stockage local
    try {
      const authToken = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (authToken) {
        analyticsState.userType = 'returning';
      }
    } catch (e) {
      // Ignorer les erreurs
    }
  }
}

/**
 * Anonymise l'agent utilisateur pour la confidentialité
 * @param {string} userAgent - Agent utilisateur brut
 * @returns {string} - Agent utilisateur anonymisé
 */
function anonymizeUserAgent(userAgent) {
  // Extraire seulement le navigateur et le système d'exploitation principal
  let browserInfo = '';
  
  if (userAgent.includes('Firefox')) {
    browserInfo += 'Firefox';
  } else if (userAgent.includes('Chrome')) {
    browserInfo += 'Chrome';
  } else if (userAgent.includes('Safari')) {
    browserInfo += 'Safari';
  } else if (userAgent.includes('Edge')) {
    browserInfo += 'Edge';
  } else if (userAgent.includes('Opera')) {
    browserInfo += 'Opera';
  } else {
    browserInfo += 'Other';
  }
  
  // Système d'exploitation
  if (userAgent.includes('Windows')) {
    browserInfo += '/Windows';
  } else if (userAgent.includes('Mac')) {
    browserInfo += '/Mac';
  } else if (userAgent.includes('Linux')) {
    browserInfo += '/Linux';
  } else if (userAgent.includes('Android')) {
    browserInfo += '/Android';
  } else if (userAgent.includes('iOS')) {
    browserInfo += '/iOS';
  } else {
    browserInfo += '/Other';
  }
  
  return browserInfo;
}

/**
 * Détermine le type de plateforme
 * @returns {string} - Type de plateforme
 */
function getPlatformType() {
  if (isRunningInTelegram()) {
    return 'telegram_webapp';
  } else if (window.matchMedia('(display-mode: standalone)').matches) {
    return 'pwa';
  } else {
    return 'web';
  }
}

/**
 * Détermine le type d'appareil
 * @returns {string} - Type d'appareil
 */
function getDeviceType() {
  const width = window.innerWidth;
  if (width <= 768) {
    return 'mobile';
  } else if (width <= 1024) {
    return 'tablet';
  } else {
    return 'desktop';
  }
}

/**
 * Obtient le type de connexion si disponible
 * @returns {string} - Type de connexion
 */
function getConnectionType() {
  if (navigator.connection) {
    return navigator.connection.effectiveType || navigator.connection.type || 'unknown';
  }
  return 'unknown';
}

/**
 * Configure les écouteurs d'événements
 */
function setupEventListeners() {
  // Écouteur pour le changement d'état en ligne/hors ligne
  window.addEventListener('online', () => {
    analyticsState.isOffline = false;
    
    // Envoyer les événements en attente
    if (analyticsState.eventQueue.length > 0) {
      sendQueuedEvents();
    }
  });
  
  window.addEventListener('offline', () => {
    analyticsState.isOffline = true;
  });
  
  // Écouteur pour le changement de visibilité de page
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      // Sauvegarder les événements en attente quand l'utilisateur quitte la page
      saveQueuedEvents();
    }
  });
  
  // Écouteur pour le panier
  document.addEventListener('cart-updated', (event) => {
    // Ne rien faire si l'analytique est désactivée
    if (!analyticsState.isEnabled) return;
    
    const detail = event.detail;
    if (detail) {
      trackEvent(EVENT_TYPES.ADD_TO_CART, {
        item_count: detail.itemCount,
        total_value: detail.total
      });
    }
  });
  
  // Écouter les clics sur les produits
  document.addEventListener('click', (event) => {
    // Ne rien faire si l'analytique est désactivée
    if (!analyticsState.isEnabled) return;
    
    // Détecter les clics sur les produits
    const productCard = event.target.closest('.product-card');
    if (productCard && productCard.dataset.id) {
      trackEvent(EVENT_TYPES.PRODUCT_CLICK, {
        product_id: productCard.dataset.id,
        product_name: productCard.querySelector('.product-name')?.textContent || 'Unknown',
        product_category: productCard.dataset.category || 'Unknown'
      });
    }
  });
  
  // Écouteur pour les erreurs non capturées
  window.addEventListener('error', (event) => {
    // Ne rien faire si l'analytique est désactivée
    if (!analyticsState.isEnabled) return;
    
    trackEvent(EVENT_TYPES.APP_ERROR, {
      error_message: event.message,
      error_source: event.filename,
      error_line: event.lineno,
      error_column: event.colno,
      error_stack: event.error ? (event.error.stack || '').substring(0, 500) : 'No stack trace'
    });
  });
  
  // Écouteur pour les promesses rejetées non gérées
  window.addEventListener('unhandledrejection', (event) => {
    // Ne rien faire si l'analytique est désactivée
    if (!analyticsState.isEnabled) return;
    
    trackEvent(EVENT_TYPES.APP_ERROR, {
      error_message: 'Unhandled Promise Rejection',
      error_reason: event.reason ? event.reason.toString().substring(0, 500) : 'Unknown reason'
    });
  });
  
  // Mesure des performances lors du chargement complet
  window.addEventListener('load', () => {
    // Ne rien faire si l'analytique est désactivée
    if (!analyticsState.isEnabled) return;
    
    setTimeout(() => {
      trackPerformance();
    }, 0);
  });
}

/**
 * Mesure et envoie les métriques de performance
 */
function trackPerformance() {
  try {
    if (!window.performance || !window.performance.timing) {
      return;
    }
    
    const timing = window.performance.timing;
    const navigationStart = timing.navigationStart;
    
    const performanceData = {
      page_load_time: timing.loadEventEnd - navigationStart,
      dom_ready_time: timing.domComplete - navigationStart,
      first_paint_time: getFCP(),
      dns_time: timing.domainLookupEnd - timing.domainLookupStart,
      tcp_connection_time: timing.connectEnd - timing.connectStart,
      server_response_time: timing.responseStart - timing.requestStart,
      dom_interactive_time: timing.domInteractive - navigationStart,
      content_download_time: timing.responseEnd - timing.responseStart
    };
    
    trackEvent(EVENT_TYPES.PERFORMANCE, performanceData);
  } catch (error) {
    console.warn('Error tracking performance:', error);
  }
}

/**
 * Obtient le FCP (First Contentful Paint) si disponible
 * @returns {number|null} - Temps FCP en ms ou null
 */
function getFCP() {
  if (window.performance && window.performance.getEntriesByType) {
    const paintEntries = window.performance.getEntriesByType('paint');
    const fcpEntry = paintEntries.find(entry => entry.name === 'first-contentful-paint');
    return fcpEntry ? Math.round(fcpEntry.startTime) : null;
  }
  return null;
}

/**
 * Configure l'envoi périodique des événements
 */
function setupPeriodicSending() {
  // Envoyer les événements toutes les 30 secondes ou selon la configuration
  const interval = ANALYTICS_CONFIG.eventFlushInterval || 30000;
  
  setInterval(() => {
    if (analyticsState.isEnabled && analyticsState.eventQueue.length >= 1) {
      sendQueuedEvents();
    }
  }, interval);
}

/**
 * Restaure les événements en attente depuis le stockage local
 */
async function restoreQueuedEvents() {
  try {
    const queuedEvents = localStorage.getItem(STORAGE_KEYS.ANALYTICS_QUEUE);
    
    if (queuedEvents) {
      const events = JSON.parse(queuedEvents);
      
      // Ne restaurer que les événements récents (moins de 24h)
      const now = Date.now();
      const filteredEvents = events.filter(event => 
        now - event.timestamp < 24 * 60 * 60 * 1000 // 24 heures
      );
      
      analyticsState.eventQueue.push(...filteredEvents);
      
      // Nettoyer si des événements ont été filtrés
      if (filteredEvents.length !== events.length) {
        localStorage.setItem(STORAGE_KEYS.ANALYTICS_QUEUE, JSON.stringify(filteredEvents));
      }
      
      console.log(`Restored ${filteredEvents.length} queued analytics events`);
    }
  } catch (error) {
    console.warn('Error restoring queued events:', error);
  }
}

/**
 * Sauvegarde les événements en attente dans le stockage local
 */
function saveQueuedEvents() {
  if (analyticsState.eventQueue.length === 0) {
    return;
  }
  
  try {
    localStorage.setItem(STORAGE_KEYS.ANALYTICS_QUEUE, JSON.stringify(analyticsState.eventQueue));
  } catch (error) {
    console.warn('Error saving queued events:', error);
    
    // Si l'erreur est due à un stockage plein, supprimer les anciens événements
    if (error.name === 'QuotaExceededError') {
      analyticsState.eventQueue = analyticsState.eventQueue.slice(-20); // Garder seulement les 20 derniers
      
      try {
        localStorage.setItem(STORAGE_KEYS.ANALYTICS_QUEUE, JSON.stringify(analyticsState.eventQueue));
      } catch (e) {
        // Si toujours en échec, juste vider la file
        analyticsState.eventQueue = [];
      }
    }
  }
}

/**
 * Envoie les événements en attente au serveur
 * @returns {Promise<boolean>} - Succès de l'envoi
 */
async function sendQueuedEvents() {
  if (analyticsState.isOffline || analyticsState.eventQueue.length === 0) {
    return false;
  }
  
  // Préparer le lot d'événements à envoyer
  const batchSize = ANALYTICS_CONFIG.eventBatchSize || 10;
  const eventsToSend = analyticsState.eventQueue.slice(0, batchSize);
  
  try {
    // Dans une implémentation réelle, envoi à un service d'analytique
    // Pour cet exemple, nous allons simplement simuler un envoi réussi
    const success = await mockSendEvents(eventsToSend);
    
    if (success) {
      // Retirer les événements envoyés de la file
      analyticsState.eventQueue = analyticsState.eventQueue.slice(batchSize);
      analyticsState.lastSentTimestamp = Date.now();
      
      // Mettre à jour le stockage local
      saveQueuedEvents();
      
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Error sending analytics events:', error);
    return false;
  }
}

/**
 * Simule l'envoi d'événements à un service d'analytique
 * @param {Array} events - Événements à envoyer
 * @returns {Promise<boolean>} - Succès de l'envoi
 */
async function mockSendEvents(events) {
  return new Promise((resolve) => {
    // Simuler un délai réseau
    setTimeout(() => {
      console.log(`Mock analytics: Sent ${events.length} events to server`);
      resolve(true);
    }, 300);
  });
}

/**
 * Suit un événement d'analytique
 * @param {string} eventType - Type d'événement
 * @param {Object} [eventData={}] - Données de l'événement
 */
export function trackEvent(eventType, eventData = {}) {
  // Ne rien faire si l'analytique est désactivée
  if (!analyticsState.isEnabled) {
    return;
  }
  
  // Créer l'événement avec des données communes
  const event = {
    event_type: eventType,
    client_id: analyticsState.clientId,
    session_id: analyticsState.sessionId,
    timestamp: Date.now(),
    app_version: FEATURES.APP_VERSION || '1.0.0',
    language: getCurrentLanguage(),
    page_url: window.location.pathname,
    user_type: analyticsState.userType,
    device_type: analyticsState.deviceInfo?.deviceType || 'unknown',
    platform: analyticsState.deviceInfo?.platform || 'web',
    // Fusionner avec les données d'événement spécifiques
    data: {
      ...eventData
    }
  };
  
  // Ajouter à la file d'attente
  analyticsState.eventQueue.push(event);
  
  // Si la file est assez grande, envoyer immédiatement
  if (analyticsState.eventQueue.length >= ANALYTICS_CONFIG.eventBatchSize) {
    sendQueuedEvents();
  }
  
  // Pour le développement, également logger dans la console
  if (analyticsState.isDevEnvironment) {
    console.log('Analytics event:', eventType, eventData);
  }
}

/**
 * Suit une vue de page
 * @param {string} pageName - Nom de la page
 * @param {Object} [additionalData={}] - Données supplémentaires
 */
export function trackPageView(pageName, additionalData = {}) {
  analyticsState.pageViewCount++;
  
  trackEvent(EVENT_TYPES.PAGE_VIEW, {
    page_name: pageName,
    page_view_count: analyticsState.pageViewCount,
    time_on_site: Math.floor((Date.now() - analyticsState.startTime) / 1000),
    ...additionalData
  });
}

/**
 * Suit une vue de produit
 * @param {Object} product - Produit consulté
 */
export function trackProductView(product) {
  if (!product || !product.id) {
    return;
  }
  
  trackEvent(EVENT_TYPES.PRODUCT_VIEW, {
    product_id: product.id,
    product_name: product.name,
    product_category: product.category,
    product_price: product.price,
    // Ne pas inclure de données détaillées pour la confidentialité
  });
}

/**
 * Suit une recherche effectuée
 * @param {string} query - Requête de recherche
 * @param {number} resultCount - Nombre de résultats
 * @param {Object} filters - Filtres appliqués
 */
export function trackSearch(query, resultCount, filters = {}) {
  trackEvent(EVENT_TYPES.SEARCH, {
    search_term: query,
    result_count: resultCount,
    has_filters: Object.keys(filters).length > 0,
    filter_categories: Object.keys(filters) // N'inclut pas les valeurs des filtres
  });
}

/**
 * Suit un début de processus de paiement
 * @param {number} cartValue - Valeur du panier
 * @param {number} itemCount - Nombre d'articles
 */
export function trackCheckoutStart(cartValue, itemCount) {
  trackEvent(EVENT_TYPES.BEGIN_CHECKOUT, {
    cart_value: cartValue,
    item_count: itemCount,
  });
}

/**
 * Suit un achat complété
 * @param {string} orderId - ID de la commande
 * @param {number} orderValue - Valeur de la commande
 * @param {string} paymentMethod - Méthode de paiement
 */
export function trackPurchase(orderId, orderValue, paymentMethod) {
  trackEvent(EVENT_TYPES.PURCHASE, {
    order_id: orderId,
    order_value: orderValue,
    payment_method: paymentMethod
  });
}

/**
 * Désactive l'analytique à la demande de l'utilisateur
 * @returns {boolean} - Succès de l'opération
 */
export function optOutOfAnalytics() {
  try {
    localStorage.setItem('analytics_opt_out', 'true');
    analyticsState.isEnabled = false;
    analyticsState.eventQueue = []; // Vider la file d'événements
    
    console.log('User opted out of analytics');
    return true;
  } catch (error) {
    console.error('Error opting out of analytics:', error);
    return false;
  }
}

/**
 * Réactive l'analytique si l'utilisateur le permet
 * @returns {boolean} - Succès de l'opération
 */
export function optInToAnalytics() {
  try {
    localStorage.removeItem('analytics_opt_out');
    analyticsState.isEnabled = ANALYTICS_CONFIG.enabled;
    
    console.log('User opted in to analytics');
    return true;
  } catch (error) {
    console.error('Error opting in to analytics:', error);
    return false;
  }
}

/**
 * Vérifie si l'analytique est activée
 * @returns {boolean} - État d'activation
 */
export function isAnalyticsEnabled() {
  return analyticsState.isEnabled;
}

// Exporter les fonctions et constantes principales
export default {
  setupAnalytics,
  trackEvent,
  trackPageView,
  trackProductView,
  trackSearch,
  trackCheckoutStart,
  trackPurchase,
  optOutOfAnalytics,
  optInToAnalytics,
  isAnalyticsEnabled,
  EVENT_TYPES
};
