// app/services/security.js

/**
 * Service de sécurité
 * Gère la protection de l'application, le chiffrement et les vérifications
 */

import { SECURITY_CONFIG, STORAGE_KEYS } from '../config/constants.js';
import { getInitData } from '../utils/telegram-api.js';
import { trackEvent } from './analytics.js';

// État du service de sécurité
const securityState = {
  isInitialized: false,
  csrfToken: null,
  lastDetection: null,
  securityChecks: [],
  telemetry: {},
  isDebuggerDetected: false,
  isTamperingDetected: false,
  isVirtualEnvironmentDetected: false,
  isProxyDetected: false,
  jailbreakDetections: 0,
  trustedOrigins: [
    'https://toolhackpro.com',
    'https://api.toolhackpro.com',
    'https://t.me',
    'https://telegram.org'
  ]
};

/**
 * Initialise le service de sécurité
 * @returns {Promise<boolean>} - Succès de l'initialisation
 */
export async function initSecurity() {
  if (securityState.isInitialized) {
    return true;
  }
  
  try {
    // Générer un token CSRF
    securityState.csrfToken = generateCSRFToken();
    
    // Vérifier l'intégrité du stockage local
    validateLocalStorage();
    
    // Détecter si on est dans un environnement Telegram
    const isTelegramEnv = detectTelegramEnvironment();
    
    // En production, effectuer des vérifications supplémentaires
    if (process.env.NODE_ENV === 'production') {
      // Détecter les outils de debug
      securityState.isDebuggerDetected = detectDebugger();
      
      // Détecter les manipulations DOM et modifications de code
      setupIntegrityChecks();
      
      // Détecter les proxys et VPNs (en option)
      if (SECURITY_CONFIG.detectProxies) {
        securityState.isProxyDetected = await detectProxy();
      }
      
      // Détecter les environnements virtuels / simulateurs
      securityState.isVirtualEnvironmentDetected = detectVirtualEnvironment();
      
      // Vérifier le jailbreak/root sur mobile (simplifié)
      checkDeviceIntegrity();
    }
    
    // Configurer les écouteurs d'événements de sécurité
    setupSecurityEventListeners();
    
    securityState.isInitialized = true;
    
    // Journaliser l'initialisation du service de sécurité
    console.log('Security service initialized');
    
    return true;
  } catch (error) {
    console.error('Error initializing security service:', error);
    return false;
  }
}

/**
 * Génère un token CSRF
 * @returns {string} - Token CSRF
 */
function generateCSRFToken() {
  const buffer = new Uint8Array(16);
  window.crypto.getRandomValues(buffer);
  return Array.from(buffer, byte => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * Valide l'intégrité du stockage local
 */
function validateLocalStorage() {
  try {
    // Vérifier si localStorage peut être utilisé
    const testKey = 'security_test';
    localStorage.setItem(testKey, 'test');
    const testValue = localStorage.getItem(testKey);
    localStorage.removeItem(testKey);
    
    if (testValue !== 'test') {
      throw new Error('localStorage integrity check failed');
    }
    
    // Vérifier si des valeurs critiques ont été manipulées
    const verificationStatus = localStorage.getItem(STORAGE_KEYS.VERIFICATION_STATUS);
    if (verificationStatus) {
      try {
        const parsed = JSON.parse(verificationStatus);
        
        // Vérifier des incohérences évidentes
        if (parsed.isVerified && !parsed.lastVerified) {
          localStorage.removeItem(STORAGE_KEYS.VERIFICATION_STATUS);
          console.warn('Inconsistent verification data detected and removed');
          
          // Enregistrer l'événement suspect
          trackEvent('security_alert', {
            type: 'localStorage_tampering',
            key: STORAGE_KEYS.VERIFICATION_STATUS
          });
        }
      } catch (e) {
        // JSON invalide, probablement manipulé
        localStorage.removeItem(STORAGE_KEYS.VERIFICATION_STATUS);
      }
    }
  } catch (error) {
    console.warn('localStorage validation failed:', error);
  }
}

/**
 * Détecte si l'application s'exécute dans l'environnement Telegram
 * @returns {boolean} - Vrai si dans Telegram
 */
function detectTelegramEnvironment() {
  // Vérifier si l'objet Telegram WebApp existe
  if (window.Telegram && window.Telegram.WebApp) {
    // Vérifier l'intégrité des données d'initialisation
    const initData = getInitData();
    if (initData && initData.raw) {
      return true;
    }
  }
  
  return false;
}

/**
 * Détecte la présence d'outils de débogage
 * @returns {boolean} - Vrai si un débogueur est détecté
 */
function detectDebugger() {
  // Plusieurs techniques pour détecter un débogueur
  let debuggerDetected = false;
  
  // 1. Vérification du temps d'exécution (peut indiquer un breakpoint)
  const startTime = performance.now();
  debugger; // Cette instruction est ignorée sans débogueur
  const endTime = performance.now();
  
  if (endTime - startTime > 100) {
    debuggerDetected = true;
  }
  
  // 2. Vérification des propriétés de la console (peut être modifiée en mode de développement)
  if (window.console && (
    Object.keys(window.console).length > 20 || 
    window.console.hasOwnProperty('_commandLineAPI')
  )) {
    debuggerDetected = true;
  }
  
  // 3. Détecter devtools (technique simplifiée)
  let devtoolsOpen = false;
  const element = document.createElement('div');
  Object.defineProperty(element, 'id', {
    get() { 
      devtoolsOpen = true; 
      return 'id';
    }
  });
  console.log(element);
  if (devtoolsOpen) {
    debuggerDetected = true;
  }
  
  return debuggerDetected;
}

/**
 * Configure des vérifications d'intégrité sur les éléments DOM critiques
 */
function setupIntegrityChecks() {
  // Liste des éléments critiques à surveiller
  const criticalElements = [
    { selector: 'form', attribute: 'action' },
    { selector: 'a.payment-link', attribute: 'href' },
    { selector: '.product-card', attribute: 'data-id' }
  ];
  
  // Enregistrer l'état initial des éléments
  const initialStates = new Map();
  
  criticalElements.forEach(item => {
    const elements = document.querySelectorAll(item.selector);
    elements.forEach((el, index) => {
      const key = `${item.selector}_${index}`;
      initialStates.set(key, el.getAttribute(item.attribute));
    });
  });
  
  // Vérifier périodiquement les modifications
  setInterval(() => {
    let tamperingDetected = false;
    
    criticalElements.forEach(item => {
      const elements = document.querySelectorAll(item.selector);
      elements.forEach((el, index) => {
        const key = `${item.selector}_${index}`;
        const initialValue = initialStates.get(key);
        const currentValue = el.getAttribute(item.attribute);
        
        // Si l'élément était présent initialement et a été modifié
        if (initialValue !== null && initialValue !== currentValue) {
          tamperingDetected = true;
          console.warn(`DOM tampering detected on ${item.selector}`);
          
          // Restaurer la valeur originale
          el.setAttribute(item.attribute, initialValue);
          
          // Enregistrer l'événement suspect
          trackEvent('security_alert', {
            type: 'dom_tampering',
            element: item.selector,
            attribute: item.attribute
          });
        }
      });
    });
    
    securityState.isTamperingDetected = tamperingDetected;
  }, 5000); // Vérifier toutes les 5 secondes
}

/**
 * Détecte si l'utilisateur utilise un proxy ou VPN
 * @returns {Promise<boolean>} - Vrai si un proxy est détecté
 */
async function detectProxy() {
  try {
    // Cette méthode est simplifiée pour l'exemple
    // En production, on utiliserait des services comme ipinfo.io ou similaires
    
    // 1. Vérification de l'horodatage réseau
    const startTime = Date.now();
    const response = await fetch('https://api.toolhackpro.com/time', {
      method: 'HEAD',
      cache: 'no-store',
      signal: AbortSignal.timeout(3000) // 3s timeout
    });
    const endTime = Date.now();
    
    // Un délai anormalement long peut indiquer un proxy
    if (endTime - startTime > 2000) {
      return true;
    }
    
    // 2. Vérification des en-têtes proxy
    const headers = response.headers;
    const proxyHeaders = [
      'via',
      'forwarded',
      'x-forwarded-for',
      'client-ip',
      'proxy-connection'
    ];
    
    for (const header of proxyHeaders) {
      if (headers.has(header)) {
        return true;
      }
    }
    
    // 3. Vérification de WebRTC leak (simplifié)
    if (window.RTCPeerConnection) {
      // Cette vérification nécessiterait plus de code pour être complète
      // Simplifié pour l'exemple
    }
    
    return false;
  } catch (error) {
    console.warn('Proxy detection failed:', error);
    return false;
  }
}

/**
 * Détecte si l'application s'exécute dans un environnement virtuel
 * @returns {boolean} - Vrai si un environnement virtuel est détecté
 */
function detectVirtualEnvironment() {
  // Cette détection est simplifiée pour l'exemple
  
  // Vérifier les propriétés du navigateur qui peuvent indiquer un simulateur
  if (navigator.userAgent.includes('Android Emulator') || 
      navigator.userAgent.includes('iPhone Simulator')) {
    return true;
  }
  
  // Vérifier les performances (souvent plus lentes dans les environnements virtuels)
  if (window.performance && window.performance.timing) {
    const timing = window.performance.timing;
    const loadTime = timing.loadEventEnd - timing.navigationStart;
    
    // Un temps de chargement anormalement long peut indiquer un environnement virtuel
    if (loadTime > 10000) { // Plus de 10 secondes
      return true;
    }
  }
  
  return false;
}

/**
 * Vérifie l'intégrité de l'appareil (jailbreak/root)
 */
function checkDeviceIntegrity() {
  // Ces vérifications sont simplifiées et illustratives
  
  let jailbreakDetected = false;
  const userAgent = navigator.userAgent.toLowerCase();
  
  // iOS
  if (userAgent.includes('iphone') || userAgent.includes('ipad')) {
    // Vérifier les applications Cydia, etc.
    if ('cydia' in window) {
      jailbreakDetected = true;
    }
    
    // Essayer d'accéder à des chemins spécifiques au jailbreak
    try {
      const iframe = document.createElement('iframe');
      iframe.src = 'cydia://package/com.example.package';
      iframe.style.display = 'none';
      document.body.appendChild(iframe);
      setTimeout(() => {
        document.body.removeChild(iframe);
      }, 100);
      
      jailbreakDetected = true;
    } catch (e) {
      // Ignorer les erreurs
    }
  }
  
  // Android
  if (userAgent.includes('android')) {
    // Vérifier les propriétés spécifiques au root
    if ('su' in window || 'superuser' in window) {
      jailbreakDetected = true;
    }
    
    // Autres vérifications possibles pour Android
  }
  
  if (jailbreakDetected) {
    securityState.jailbreakDetections++;
    
    if (securityState.jailbreakDetections >= 2) {
      // Enregistrer l'événement
      trackEvent('security_alert', {
        type: 'jailbreak_detected',
        platform: userAgent.includes('android') ? 'android' : 'ios'
      });
      
      // Afficher un avertissement
      showSecurityWarning('device_integrity');
    }
  }
}

/**
 * Configure les écouteurs d'événements pour la sécurité
 */
function setupSecurityEventListeners() {
  // Surveiller les tentatives de copier les données sensibles
  document.addEventListener('copy', (event) => {
    const selection = window.getSelection().toString();
    
    // Vérifier si la sélection contient des données sensibles
    if (isSensitiveData(selection)) {
      console.warn('Attempted to copy sensitive data');
      
      // Optionnellement, bloquer la copie
      if (SECURITY_CONFIG.preventSensitiveDataCopy) {
        event.preventDefault();
        
        // Substituer par un message d'avertissement
        event.clipboardData.setData('text/plain', 'Copying sensitive data is not allowed for security reasons.');
      }
      
      trackEvent('security_alert', {
        type: 'sensitive_data_copy',
        length: selection.length
      });
    }
  });
  
  // Surveiller les tentatives de capture d'écran
  if ('visibilityState' in document) {
    let lastBlurTime = 0;
    
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        lastBlurTime = Date.now();
      } else if (document.visibilityState === 'visible') {
        // Si l'utilisateur revient très rapidement, cela peut indiquer une capture d'écran
        const timeDiff = Date.now() - lastBlurTime;
        if (lastBlurTime > 0 && timeDiff < 100) {
          console.warn('Possible screenshot attempt detected');
          
          trackEvent('security_alert', {
            type: 'possible_screenshot',
            time_diff: timeDiff
          });
        }
      }
    });
  }
  
  // Surveiller les événements de débogage
  window.addEventListener('error', (event) => {
    // Vérifier si l'erreur est liée à la sécurité
    if (event.message && (
      event.message.includes('SecurityError') ||
      event.message.includes('cross-origin')
    )) {
      console.warn('Security-related error detected:', event.message);
      
      trackEvent('security_alert', {
        type: 'security_error',
        message: event.message.substring(0, 100) // Tronquer pour éviter les données sensibles
      });
    }
  });
}

/**
 * Vérifie si un texte contient des données sensibles
 * @param {string} text - Texte à vérifier
 * @returns {boolean} - Vrai si des données sensibles sont détectées
 */
function isSensitiveData(text) {
  if (!text || typeof text !== 'string') {
    return false;
  }
  
  // Modèles pour les données sensibles
  const patterns = [
    // Clés crypto (génériques)
    /[A-Fa-f0-9]{64}/,
    // Adresses de portefeuille crypto
    /0x[A-Fa-f0-9]{40}/,  // Ethereum
    /EQ[A-Za-z0-9_-]{48}/, // TON
    /bc1[a-zA-HJ-NP-Z0-9]{25,39}|[13][a-km-zA-HJ-NP-Z1-9]{25,34}/, // Bitcoin
    // Mots de passe et tokens
    /(password|token|secret|key|api[_-]?key).*[:=]\s*['"]?[A-Za-z0-9]{8,}['"]?/i,
    // Données personnelles
    /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i  // Email
  ];
  
  // Vérifier chaque motif
  return patterns.some(pattern => pattern.test(text));
}

/**
 * Affiche un avertissement de sécurité à l'utilisateur
 * @param {string} type - Type d'avertissement
 */
function showSecurityWarning(type) {
  if (!document.getElementById('security-warning')) {
    const warningDiv = document.createElement('div');
    warningDiv.id = 'security-warning';
    warningDiv.className = 'security-warning';
    
    let message = 'Security alert: ';
    
    switch (type) {
      case 'device_integrity':
        message += 'This device appears to be jailbroken or rooted, which may compromise security.';
        break;
      case 'tampering':
        message += 'Application code tampering detected.';
        break;
      case 'debugger':
        message += 'Debugging tools detected. Developer features should not be used in production.';
        break;
      case 'virtual_environment':
        message += 'This application is running in a virtual environment.';
        break;
      default:
        message += 'A security issue has been detected.';
    }
    
    warningDiv.textContent = message;
    document.body.appendChild(warningDiv);
    
    // Supprimer après un délai
    setTimeout(() => {
      if (warningDiv.parentNode) {
        warningDiv.parentNode.removeChild(warningDiv);
      }
    }, 10000);
  }
}

/**
 * Valide une URL pour les redirections et les liens externes
 * @param {string} url - URL à valider
 * @returns {boolean} - Vrai si l'URL est sûre
 */
export function validateUrl(url) {
  try {
    // Rejeter les URLs vides ou non valides
    if (!url || typeof url !== 'string') {
      return false;
    }
    
    // Accepter les chemins relatifs
    if (url.startsWith('/') && !url.startsWith('//')) {
      return true;
    }
    
    // Vérifier les protocoles autorisés
    const validProtocols = ['https:', 'tel:', 'mailto:'];
    const urlObj = new URL(url);
    
    if (!validProtocols.includes(urlObj.protocol)) {
      console.warn(`Blocked URL with invalid protocol: ${urlObj.protocol}`);
      return false;
    }
    
    // Vérifier les domaines de confiance pour les URLs absolues
    if (urlObj.protocol === 'https:') {
      const hostname = urlObj.hostname;
      const isTrusted = securityState.trustedOrigins.some(origin => {
        // Obtenir le hostname de l'origine de confiance
        const originHostname = new URL(origin).hostname;
        
        // Vérifier si c'est le même domaine ou un sous-domaine
        return hostname === originHostname || hostname.endsWith('.' + originHostname);
      });
      
      if (!isTrusted) {
        console.warn(`Blocked URL with untrusted domain: ${hostname}`);
        trackEvent('security_alert', {
          type: 'untrusted_url',
          url: hostname // Ne pas envoyer l'URL complète pour la confidentialité
        });
        return false;
      }
    }
    
    return true;
  } catch (error) {
    console.error('URL validation error:', error);
    return false;
  }
}

/**
 * Vérifie si un produit est d'une catégorie sensible
 * @param {Object} product - Produit à vérifier
 * @returns {boolean} - Vrai si le produit est sensible
 */
export function isSensitiveProduct(product) {
  if (!product) {
    return false;
  }
  
  // Vérifier si la catégorie du produit est sensible
  if (SECURITY_CONFIG.sensitiveCategories.includes(product.category)) {
    return true;
  }
  
  // Vérifier les indicateurs directs
  if (product.isRestricted || product.requiresVerification) {
    return true;
  }
  
  // Vérifier les mots-clés dans le nom et la description
  const sensitiveKeywords = [
    'hack', 'exploit', 'crack', 'attack', 'forensic', 'decrypt', 'backdoor',
    'vulnerability', 'spy', 'surveillance', 'tracker', 'monitoring'
  ];
  
  const textToCheck = `${product.name} ${product.description || ''}`.toLowerCase();
  
  return sensitiveKeywords.some(keyword => textToCheck.includes(keyword));
}

/**
 * Obtient le token CSRF actuel
 * @returns {string|null} - Token CSRF
 */
export function getCSRFToken() {
  return securityState.csrfToken;
}

/**
 * Hache une chaîne avec l'algorithme SHA-256
 * @param {string} str - Chaîne à hacher
 * @returns {Promise<string>} - Hachage hexadécimal
 */
export async function hashString(str) {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Vérifie si le service de sécurité a détecté des problèmes
 * @returns {boolean} - Vrai si des problèmes sont détectés
 */
export function hasSecurityIssues() {
  return (
    securityState.isDebuggerDetected ||
    securityState.isTamperingDetected ||
    securityState.isVirtualEnvironmentDetected ||
    securityState.isProxyDetected ||
    securityState.jailbreakDetections > 1
  );
}

/**
 * Ajoute une origine de confiance à la liste blanche
 * @param {string} origin - Origine à ajouter
 */
export function addTrustedOrigin(origin) {
  // Valider l'origine
  try {
    const url = new URL(origin);
    if (url.protocol === 'https:') {
      securityState.trustedOrigins.push(origin);
    }
  } catch (error) {
    console.error('Invalid origin:', origin);
  }
}

// Exporter les fonctions principales
export default {
  initSecurity,
  validateUrl,
  isSensitiveProduct,
  getCSRFToken,
  hashString,
  hasSecurityIssues,
  addTrustedOrigin
};
