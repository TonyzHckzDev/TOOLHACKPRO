// app/components/cart.js

/**
 * Module de gestion du panier d'achat
 * Gère l'ajout, la suppression et la persistance des produits
 */

import { hapticFeedback } from '../utils/telegram-api.js';
import { translate } from '../utils/i18n.js';
import { STORAGE_KEYS, MAX_CART_ITEMS } from '../config/constants.js';

// État du panier
let cartItems = [];
let updateCallback = null;
let securityCheckCallback = null;

/**
 * Initialise le module de panier
 * @param {Array} initialItems - Éléments initiaux du panier
 * @param {Function} onUpdate - Callback appelé lors des mises à jour du panier
 * @param {Function} [securityCheck] - Callback facultatif pour vérifier les produits sensibles
 */
export function initCart(initialItems = [], onUpdate = null, securityCheck = null) {
  cartItems = initialItems || [];
  updateCallback = onUpdate;
  securityCheckCallback = securityCheck;
  
  // Restaurer le panier depuis le stockage local si vide
  if (cartItems.length === 0) {
    restoreCart();
  }
  
  // Initialiser les gestionnaires d'événements
  initCartEventListeners();
  
  console.log('Cart initialized with', cartItems.length, 'items');
}

/**
 * Initialise les gestionnaires d'événements pour les boutons du panier
 */
function initCartEventListeners() {
  // Délégation d'événements pour les boutons d'ajout au panier
  document.addEventListener('click', (event) => {
    // Boutons d'ajout au panier
    if (event.target.matches('.add-to-cart') || event.target.closest('.add-to-cart')) {
      const button = event.target.matches('.add-to-cart') ? 
                    event.target : 
                    event.target.closest('.add-to-cart');
      
      const productId = button.dataset.id;
      const productElement = button.closest('.product-card') || button.closest('.product-details');
      
      if (productId && productElement) {
        const product = {
          id: productId,
          name: productElement.querySelector('.product-name')?.textContent || 'Produit',
          price: parseFloat(productElement.querySelector('.product-price')?.dataset.price || '0'),
          image: productElement.querySelector('.product-image')?.src || '',
          category: productElement.dataset.category || '',
          quantity: 1
        };
        
        addToCart(product);
        
        // Feedback visuel et haptique
        button.classList.add('added');
        hapticFeedback('medium');
        
        // Réinitialiser l'état du bouton après animation
        setTimeout(() => {
          button.classList.remove('added');
        }, 1500);
      }
    }
    
    // Boutons de suppression d'un élément du panier
    if (event.target.matches('.remove-item') || event.target.closest('.remove-item')) {
      const button = event.target.matches('.remove-item') ? 
                    event.target : 
                    event.target.closest('.remove-item');
      
      const itemId = button.dataset.id;
      if (itemId) {
        removeFromCart(itemId);
        hapticFeedback('light');
      }
    }
    
    // Boutons de mise à jour de quantité
    if (event.target.matches('.quantity-adjust') || event.target.closest('.quantity-adjust')) {
      const button = event.target.matches('.quantity-adjust') ? 
                    event.target : 
                    event.target.closest('.quantity-adjust');
      
      const itemId = button.dataset.id;
      const action = button.dataset.action; // 'increase' ou 'decrease'
      
      if (itemId && action) {
        if (action === 'increase') {
          updateItemQuantity(itemId, 1);
        } else if (action === 'decrease') {
          updateItemQuantity(itemId, -1);
        }
        hapticFeedback('light');
      }
    }
    
    // Bouton pour vider le panier
    if (event.target.matches('#clear-cart') || event.target.closest('#clear-cart')) {
      clearCart();
      hapticFeedback('medium');
    }
  });
  
  // Événement pour sauvegarder le panier avant de quitter la page
  window.addEventListener('beforeunload', saveCart);
  
  // Événement personnalisé pour la mise à jour du panier
  document.addEventListener('cart-update', (e) => {
    if (e.detail && e.detail.items) {
      cartItems = e.detail.items;
      saveCart();
      notifyUpdate();
    }
  });
}

/**
 * Ajoute un produit au panier
 * @param {Object} product - Produit à ajouter
 * @returns {boolean} Succès de l'opération
 */
export function addToCart(product) {
  // Vérifier si le produit est valide
  if (!product || !product.id) {
    console.error('Tentative d\'ajout d\'un produit invalide au panier');
    return false;
  }
  
  // Vérification de sécurité pour les produits sensibles
  if (securityCheckCallback && typeof securityCheckCallback === 'function') {
    const isAllowed = securityCheckCallback(product);
    if (!isAllowed) {
      console.warn('Produit non autorisé:', product.name);
      
      // Afficher un toast de notification
      showNotification(translate('cart.restricted_item'), 'warning');
      return false;
    }
  }
  
  // Vérifier si le produit est déjà dans le panier
  const existingIndex = cartItems.findIndex(item => item.id === product.id);
  
  if (existingIndex !== -1) {
    // Mettre à jour la quantité si le produit existe déjà
    cartItems[existingIndex].quantity += 1;
    
    // Limiter la quantité si nécessaire
    if (cartItems[existingIndex].quantity > MAX_CART_ITEMS) {
      cartItems[existingIndex].quantity = MAX_CART_ITEMS;
      showNotification(translate('cart.max_quantity_reached'), 'info');
    }
  } else {
    // Vérifier si le panier n'est pas trop grand
    if (cartItems.length >= 20) {
      showNotification(translate('cart.too_many_items'), 'warning');
      return false;
    }
    
    // Ajouter le nouveau produit
    cartItems.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
      quantity: 1,
      addedAt: new Date().toISOString()
    });
  }
  
  // Sauvegarder et notifier
  saveCart();
  notifyUpdate();
  
  // Afficher une notification
  showNotification(translate('cart.item_added'), 'success');
  
  return true;
}

/**
 * Retire un produit du panier
 * @param {string} productId - ID du produit à retirer
 * @param {boolean} [removeAll=false] - Supprimer toutes les quantités
 * @returns {boolean} Succès de l'opération
 */
export function removeFromCart(productId, removeAll = false) {
  const existingIndex = cartItems.findIndex(item => item.id === productId);
  
  if (existingIndex === -1) {
    return false;
  }
  
  if (removeAll || cartItems[existingIndex].quantity <= 1) {
    // Supprimer complètement l'élément
    cartItems.splice(existingIndex, 1);
  } else {
    // Réduire la quantité
    cartItems[existingIndex].quantity -= 1;
  }
  
  // Sauvegarder et notifier
  saveCart();
  notifyUpdate();
  
  return true;
}

/**
 * Met à jour la quantité d'un produit
 * @param {string} productId - ID du produit
 * @param {number} change - Changement de quantité (+1, -1, etc.)
 * @returns {boolean} Succès de l'opération
 */
export function updateItemQuantity(productId, change) {
  const existingIndex = cartItems.findIndex(item => item.id === productId);
  
  if (existingIndex === -1) {
    return false;
  }
  
  // Calculer la nouvelle quantité
  const newQuantity = cartItems[existingIndex].quantity + change;
  
  // Valider la nouvelle quantité
  if (newQuantity <= 0) {
    // Supprimer l'élément si la quantité atteint 0
    return removeFromCart(productId, true);
  } else if (newQuantity > MAX_CART_ITEMS) {
    // Limiter à la quantité maximale
    cartItems[existingIndex].quantity = MAX_CART_ITEMS;
    showNotification(translate('cart.max_quantity_reached'), 'info');
  } else {
    // Mettre à jour normalement
    cartItems[existingIndex].quantity = newQuantity;
  }
  
  // Sauvegarder et notifier
  saveCart();
  notifyUpdate();
  
  return true;
}

/**
 * Vide complètement le panier
 * @returns {boolean} Succès de l'opération
 */
export function clearCart() {
  if (cartItems.length === 0) {
    return false;
  }
  
  // Confirmer avec l'utilisateur avant de vider
  if (confirm(translate('cart.confirm_clear'))) {
    cartItems = [];
    
    // Sauvegarder et notifier
    saveCart();
    notifyUpdate();
    
    return true;
  }
  
  return false;
}

/**
 * Sauvegarde le panier dans le stockage local
 */
function saveCart() {
  try {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cartItems));
  } catch (e) {
    console.error('Erreur lors de la sauvegarde du panier:', e);
  }
}

/**
 * Restaure le panier depuis le stockage local
 */
function restoreCart() {
  try {
    const savedCart = localStorage.getItem(STORAGE_KEYS.CART);
    if (savedCart) {
      cartItems = JSON.parse(savedCart);
      
      // Nettoyer les éléments invalides
      cartItems = cartItems.filter(item => 
        item && item.id && item.name && typeof item.price === 'number'
      );
      
      // Assurez-vous que les articles ont une date d'ajout
      cartItems.forEach(item => {
        if (!item.addedAt) {
          item.addedAt = new Date().toISOString();
        }
      });
    }
  } catch (e) {
    console.error('Erreur lors de la restauration du panier:', e);
    cartItems = [];
  }
}

/**
 * Notifie les observateurs des changements dans le panier
 */
function notifyUpdate() {
  if (updateCallback && typeof updateCallback === 'function') {
    updateCallback(cartItems);
  }
  
  // Déclencher un événement personnalisé
  const event = new CustomEvent('cart-updated', { 
    detail: { 
      items: cartItems,
      itemCount: getCartItemCount(),
      total: getCartTotal()
    } 
  });
  document.dispatchEvent(event);
}

/**
 * Obtient tous les éléments du panier
 * @returns {Array} Éléments du panier
 */
export function getCartItems() {
  return [...cartItems];
}

/**
 * Obtient le nombre total d'articles dans le panier
 * @returns {number} Nombre d'articles
 */
export function getCartItemCount() {
  return cartItems.reduce((total, item) => total + item.quantity, 0);
}

/**
 * Obtient le prix total du panier
 * @param {boolean} [formatted=false] - Retourner le prix formaté
 * @returns {number|string} Prix total ou prix formaté
 */
export function getCartTotal(formatted = false) {
  const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  if (formatted) {
    // Formater le prix avec 2 décimales et le symbole de devise
    return new Intl.NumberFormat('fr-FR', { 
      style: 'currency', 
      currency: 'USD' 
    }).format(total);
  }
  
  return total;
}

/**
 * Vérifie si un produit est déjà dans le panier
 * @param {string} productId - ID du produit
 * @returns {boolean} Vrai si le produit est déjà dans le panier
 */
export function isProductInCart(productId) {
  return cartItems.some(item => item.id === productId);
}

/**
 * Obtient la quantité d'un produit dans le panier
 * @param {string} productId - ID du produit
 * @returns {number} Quantité du produit (0 si non présent)
 */
export function getProductQuantity(productId) {
  const item = cartItems.find(item => item.id === productId);
  return item ? item.quantity : 0;
}

/**
 * Calcule les taxes pour le panier
 * @param {number} [taxRate=0.20] - Taux de taxe (par défaut 20%)
 * @returns {number} Montant des taxes
 */
export function calculateTax(taxRate = 0.20) {
  const subtotal = getCartTotal();
  return subtotal * taxRate;
}

/**
 * Affiche une notification temporaire
 * @param {string} message - Message à afficher
 * @param {string} [type='info'] - Type de notification ('success', 'info', 'warning', 'error')
 * @param {number} [duration=3000] - Durée d'affichage en ms
 */
function showNotification(message, type = 'info', duration = 3000) {
  // Créer l'élément de notification s'il n'existe pas
  let container = document.getElementById('notification-container');
  
  if (!container) {
    container = document.createElement('div');
    container.id = 'notification-container';
    document.body.appendChild(container);
  }
  
  // Créer la notification
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  
  // Ajouter au container
  container.appendChild(notification);
  
  // Afficher avec animation
  setTimeout(() => {
    notification.classList.add('show');
  }, 10);
  
  // Supprimer après le délai
  setTimeout(() => {
    notification.classList.remove('show');
    notification.classList.add('hide');
    
    // Supprimer du DOM après l'animation
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, duration);
}

/**
 * Applique un code promotionnel au panier
 * @param {string} code - Code promotionnel
 * @returns {Promise<Object>} Résultat de l'application du code
 */
export async function applyPromoCode(code) {
  // Simuler une requête API
  try {
    // En production, ceci serait un appel API
    // Pour l'exemple, on simule une remise de 10% pour le code "TOOLHACK10"
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (code.toUpperCase() === 'TOOLHACK10') {
          resolve({
            success: true,
            discount: 0.10,
            message: translate('cart.promo_applied')
          });
        } else {
          reject({
            success: false,
            message: translate('cart.invalid_promo')
          });
        }
      }, 500);
    });
  } catch (error) {
    console.error('Erreur lors de l\'application du code promo:', error);
    throw error;
  }
}

/**
 * Génère un résumé de commande pour le processus de paiement
 * @returns {Object} Résumé de la commande
 */
export function generateOrderSummary() {
  const items = getCartItems();
  const subtotal = getCartTotal();
  const tax = calculateTax();
  const total = subtotal + tax;
  
  // Regrouper les articles par catégorie pour le résumé
  const categorized = items.reduce((acc, item) => {
    const category = item.category || 'other';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(item);
    return acc;
  }, {});
  
  return {
    orderId: generateOrderId(),
    items,
    itemCount: getCartItemCount(),
    categorized,
    subtotal,
    tax,
    total,
    currency: 'USD',
    timestamp: new Date().toISOString()
  };
}

/**
 * Génère un identifiant de commande unique
 * @returns {string} Identifiant de commande
 */
function generateOrderId() {
  const timestamp = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 8);
  return `TH-${timestamp}-${randomStr}`.toUpperCase();
}

/**
 * Sérialise le panier pour l'envoi à l'API
 * @returns {Object} Données du panier formatées pour l'API
 */
export function serializeCartForApi() {
  return {
    items: cartItems.map(item => ({
      product_id: item.id,
      quantity: item.quantity,
      unit_price: item.price
    })),
    meta: {
      item_count: getCartItemCount(),
      total: getCartTotal(),
      client_timestamp: new Date().toISOString(),
      currency: 'USD'
    }
  };
}

/**
 * Vérifie la disponibilité des produits dans le panier
 * @returns {Promise<Object>} Résultat de la vérification
 */
export async function checkProductAvailability() {
  // Cette fonction simulerait un appel API pour vérifier la disponibilité
  // En production, ceci serait une requête réseau
  return new Promise(resolve => {
    setTimeout(() => {
      const unavailableItems = [];
      
      // Simuler une vérification
      cartItems.forEach(item => {
        // Simuler un produit indisponible (pour test)
        if (item.id === 'USB_KILLER_PRO' && item.quantity > 2) {
          unavailableItems.push({
            id: item.id,
            name: item.name,
            requested: item.quantity,
            available: 2
          });
        }
      });
      
      resolve({
        allAvailable: unavailableItems.length === 0,
        unavailableItems
      });
    }, 800);
  });
}

// Exporter les méthodes principales
export default {
  initCart,
  addToCart,
  removeFromCart,
  updateItemQuantity,
  clearCart,
  getCartItems,
  getCartTotal,
  getCartItemCount,
  isProductInCart,
  getProductQuantity,
  applyPromoCode,
  generateOrderSummary,
  checkProductAvailability,
  serializeCartForApi
};
