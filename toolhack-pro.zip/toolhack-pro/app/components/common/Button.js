import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

/**
 * Composant Button
 * 
 * Composant de bouton réutilisable avec plusieurs variantes, tailles et états.
 * Supporte les icônes, le chargement, et peut être désactivé.
 * 
 * @component
 */
const Button = React.forwardRef(({
  children,
  variant = 'primary',
  size = 'md',
  type = 'button',
  className = '',
  icon = null,
  iconPosition = 'left',
  loading = false,
  disabled = false,
  fullWidth = false,
  rounded = false,
  outline = false,
  onClick,
  href,
  target,
  submit = false,
  title,
  ariaLabel,
  testId = 'button',
  ...rest
}, ref) => {
  // Détermination si c'est un lien ou un bouton
  const isLink = Boolean(href);
  
  // Construction des classes CSS
  const buttonClasses = classNames(
    'btn',
    `btn-${variant}${outline ? '-outline' : ''}`,
    `btn-${size}`,
    {
      'btn-icon-only': !children && icon,
      'btn-loading': loading,
      'btn-full-width': fullWidth,
      'btn-rounded': rounded,
      'disabled': disabled && isLink,
    },
    className
  );

  // Préparation du contenu du bouton
  const buttonContent = (
    <>
      {loading && (
        <span className="btn-spinner" aria-hidden="true">
          <svg className="spinner-svg" viewBox="0 0 24 24">
            <circle
              className="spinner-circle"
              cx="12"
              cy="12"
              r="10"
              fill="none"
              strokeWidth="3"
            />
          </svg>
        </span>
      )}
      
      {icon && iconPosition === 'left' && !loading && (
        <span className="btn-icon btn-icon-left">{icon}</span>
      )}
      
      {children && (
        <span className="btn-text">{children}</span>
      )}
      
      {icon && iconPosition === 'right' && !loading && (
        <span className="btn-icon btn-icon-right">{icon}</span>
      )}
    </>
  );

  // Si c'est un lien, rendre un <a>
  if (isLink) {
    return (
      <a
        ref={ref}
        href={disabled ? undefined : href}
        target={target}
        className={buttonClasses}
        onClick={disabled ? (e) => e.preventDefault() : onClick}
        aria-disabled={disabled}
        aria-label={ariaLabel}
        title={title}
        data-testid={testId}
        rel={target === '_blank' ? 'noreferrer noopener' : undefined}
        {...rest}
      >
        {buttonContent}
      </a>
    );
  }

  // Sinon, rendre un <button>
  return (
    <button
      ref={ref}
      type={submit ? 'submit' : type}
      className={buttonClasses}
      onClick={onClick}
      disabled={disabled || loading}
      aria-label={ariaLabel}
      aria-busy={loading}
      title={title}
      data-testid={testId}
      {...rest}
    >
      {buttonContent}
    </button>
  );
});

Button.displayName = 'Button';

Button.propTypes = {
  /** Contenu du bouton */
  children: PropTypes.node,
  
  /** Variante du bouton */
  variant: PropTypes.oneOf([
    'primary', 'secondary', 'success', 'danger', 'warning', 
    'info', 'dark', 'light', 'link', 'ghost', 'accent', 'tool'
  ]),
  
  /** Taille du bouton */
  size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
  
  /** Type HTML du bouton */
  type: PropTypes.oneOf(['button', 'submit', 'reset']),
  
  /** Classes personnalisées supplémentaires */
  className: PropTypes.string,
  
  /** Élément d'icône (composant ou nœud React) */
  icon: PropTypes.node,
  
  /** Position de l'icône */
  iconPosition: PropTypes.oneOf(['left', 'right']),
  
  /** État de chargement */
  loading: PropTypes.bool,
  
  /** État de désactivation */
  disabled: PropTypes.bool,
  
  /** Si vrai, le bouton prendra toute la largeur disponible */
  fullWidth: PropTypes.bool,
  
  /** Si vrai, le bouton aura des coins complètement arrondis */
  rounded: PropTypes.bool,
  
  /** Si vrai, le bouton sera en style outline */
  outline: PropTypes.bool,
  
  /** Gestionnaire d'événement de clic */
  onClick: PropTypes.func,
  
  /** URL en cas de bouton de type lien */
  href: PropTypes.string,
  
  /** Attribut cible pour les liens */
  target: PropTypes.string,
  
  /** Raccourci pour définir le type à 'submit' */
  submit: PropTypes.bool,
  
  /** Texte à afficher au survol (attribut title) */
  title: PropTypes.string,
  
  /** Texte d'accessibilité */
  ariaLabel: PropTypes.string,
  
  /** ID pour les tests */
  testId: PropTypes.string,
};

export default Button;

/** 
 * Exemples d'utilisation:
 * 
 * Bouton de base:
 * <Button>Cliquez-moi</Button>
 *
 * Bouton avec variante:
 * <Button variant="success">Confirmer</Button>
 * 
 * Bouton avec icône:
 * <Button icon={<IconCheck />}>Valider</Button>
 * 
 * Bouton de chargement:
 * <Button loading>Traitement en cours...</Button>
 * 
 * Bouton lien:
 * <Button href="https://example.com" target="_blank">Visiter le site</Button>
 * 
 * Bouton de soumission de formulaire:
 * <Button submit variant="primary">Soumettre</Button>
 */
