// configs/esbuild.config.js

const esbuild = require('esbuild');
const fs = require('fs');
const path = require('path');

// Configuration de l'environnement
const isProduction = process.env.NODE_ENV === 'production';
const outDir = 'dist';

// Assurer que le répertoire de sortie existe
if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

// Options de build principales
const buildOptions = {
  entryPoints: ['scripts/main.js'],
  bundle: true,
  minify: isProduction,
  sourcemap: !isProduction,
  outfile: `${outDir}/bundle.js`,
  format: 'esm',
  loader: {
    '.js': 'jsx',
    '.json': 'json',
    '.png': 'dataurl',
    '.jpg': 'dataurl',
    '.svg': 'text',
    '.css': 'text'
  },
  define: {
    'process.env.NODE_ENV': isProduction ? '"production"' : '"development"',
    'process.env.TELEGRAM_WEBAPP': 'true',
    'process.env.VERSION': `"${require('../package.json').version}"`
  },
  plugins: [
    // Plugin personnalisé pour notifier la fin du build
    {
      name: 'notify-end',
      setup(build) {
        build.onEnd(result => {
          const date = new Date().toLocaleTimeString();
          if (result.errors.length > 0) {
            console.log(`[${date}] Build failed with ${result.errors.length} errors`);
          } else {
            console.log(`[${date}] Build completed successfully`);
            // Nous pouvons ajouter ici une notification Telegram si nécessaire
          }
        });
      },
    },
    // Plugin pour copier le HTML et autres fichiers statiques
    {
      name: 'copy-static',
      setup(build) {
        build.onEnd(() => {
          fs.copyFileSync('public/index.html', `${outDir}/index.html`);
          fs.copyFileSync('public/manifest.json', `${outDir}/manifest.json`);
          
          // Copier les fichiers de style principaux
          if (!fs.existsSync(`${outDir}/styles`)) {
            fs.mkdirSync(`${outDir}/styles`, { recursive: true });
          }
          fs.copyFileSync('styles/main.css', `${outDir}/styles/main.css`);
          
          console.log('Static files copied to dist directory');
        });
      },
    },
  ],
};

// Mode watch pour le développement
if (process.argv.includes('--watch')) {
  // Mode watch
  esbuild.context(buildOptions).then(context => {
    context.watch();
    console.log('Watching for changes...');
  }).catch(() => process.exit(1));
} else {
  // Build unique
  esbuild.build(buildOptions).catch(() => process.exit(1));
}

// Ajouter un gestionnaire pour les signaux de terminaison
['SIGINT', 'SIGTERM'].forEach((signal) => {
  process.on(signal, () => {
    console.log('\nBuild process terminated');
    process.exit(0);
  });
});
