-- Structure de base de données pour le système de vérification professionnelle

-- Table des vérifications professionnelles
CREATE TABLE IF NOT EXISTS professional_verifications (
  id UUID PRIMARY KEY,
  telegram_id BIGINT,
  telegram_username VARCHAR(255),
  profession VARCHAR(50) NOT NULL,
  license_identifier VARCHAR(255) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  verified_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index pour accélérer les recherches
CREATE INDEX IF NOT EXISTS idx_verifications_telegram_id ON professional_verifications(telegram_id);
CREATE INDEX IF NOT EXISTS idx_verifications_status ON professional_verifications(status);
CREATE INDEX IF NOT EXISTS idx_verifications_expires_at ON professional_verifications(expires_at);

-- Table des tentatives de vérification (pour l'audit et la sécurité)
CREATE TABLE IF NOT EXISTS verification_attempts (
  id SERIAL PRIMARY KEY,
  telegram_id BIGINT,
  telegram_username VARCHAR(255),
  profession VARCHAR(50),
  license_hash VARCHAR(255),
  ip_address VARCHAR(45),
  user_agent TEXT,
  success BOOLEAN NOT NULL DEFAULT FALSE,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index pour l'analyse des tentatives
CREATE INDEX IF NOT EXISTS idx_attempts_telegram_id ON verification_attempts(telegram_id);
CREATE INDEX IF NOT EXISTS idx_attempts_success ON verification_attempts(success);
CREATE INDEX IF NOT EXISTS idx_attempts_timestamp ON verification_attempts(timestamp);

-- Table des alertes de sécurité
CREATE TABLE IF NOT EXISTS security_alerts (
  id SERIAL PRIMARY KEY,
  alert_type VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  source_ip VARCHAR(45),
  source_id VARCHAR(255),
  severity VARCHAR(20) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'new',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  resolved_at TIMESTAMP WITH TIME ZONE
);

-- Fonction pour mettre à jour le timestamp "updated_at"
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger pour mettre à jour "updated_at" automatiquement
CREATE TRIGGER update_verifications_timestamp
BEFORE UPDATE ON professional_verifications
FOR EACH ROW
EXECUTE FUNCTION update_timestamp();

-- Fonction pour créer des alertes de sécurité sur des tentatives multiples
CREATE OR REPLACE FUNCTION check_suspicious_attempts()
RETURNS TRIGGER AS $$
DECLARE
  attempt_count INTEGER;
BEGIN
  -- Compter les tentatives récentes de la même source
  SELECT COUNT(*) INTO attempt_count
  FROM verification_attempts
  WHERE (ip_address = NEW.ip_address OR telegram_id = NEW.telegram_id)
  AND success = FALSE
  AND timestamp > NOW() - INTERVAL '1 hour';
  
  -- Si plus de 5 tentatives échouées en une heure, créer une alerte
  IF attempt_count >= 5 THEN
    INSERT INTO security_alerts (
      alert_type, 
      description, 
      source_ip, 
      source_id, 
      severity, 
      status
    ) VALUES (
      'multiple_failed_attempts',
      'Multiple failed verification attempts detected',
      NEW.ip_address,
      COALESCE(NEW.telegram_id::TEXT, 'unknown'),
      'medium',
      'new'
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger pour la détection de tentatives suspectes
CREATE TRIGGER check_suspicious_verification_attempts
AFTER INSERT ON verification_attempts
FOR EACH ROW
WHEN (NEW.success = FALSE)
EXECUTE FUNCTION check_suspicious_attempts();
