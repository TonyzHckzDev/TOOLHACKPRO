/**
 * Tests unitaires pour le panier
 */

describe('CartManager', () => {
  // Mock du système d'internationalisation
  const mockI18n = {
    t: (key) => key
  };

  // Mock des éléments DOM
  const setupDomMocks = () => {
    document.body.innerHTML = `
      <span id="cartCount">0</span>
      <div id="cartItems"></div>
      <span id="cartTotalAmount">0 TON</span>
      <button id="checkoutButton" disabled>Checkout</button>
      <div id="cartEmptyMessage">Your cart is empty</div>
    `;
  };

  // Instance de CartManager pour les tests
  let cartManager;
  
  // Produit de test
  const testProduct = {
    id: 'test-product-1',
    name: 'USB Hacking Tool',
    price: 25.99,
    currency: 'TON',
    image: 'images/products/usb-tool.png',
    category: 'HARDWARE',
    inStock: true
  };

  beforeEach(() => {
    // Réinitialiser le DOM
    setupDomMocks();
    
    // Réinitialiser localStorage
    localStorage.clear();
    
    // Créer une nouvelle instance de CartManager
    cartManager = new CartManager(mockI18n);
  });

  describe('addItem', () => {
    it('should add an item to the cart', () => {
      cartManager.addItem(testProduct);
      
      expect(cartManager.items.length).toBe(1);
      expect(cartManager.items[0].id).toBe(testProduct.id);
      expect(cartManager.items[0].quantity).toBe(1);
    });

    it('should increase quantity if item already exists', () => {
      cartManager.addItem(testProduct);
      cartManager.addItem(testProduct);
      
      expect(cartManager.items.length).toBe(1);
      expect(cartManager.items[0].quantity).toBe(2);
    });

    it('should update DOM elements', () => {
      cartManager.addItem(testProduct);
      
      const cartCount = document.getElementById('cartCount');
      expect(cartCount.textContent).toBe('1');
      
      const checkoutButton = document.getElementById('checkoutButton');
      expect(checkoutButton.disabled).toBe(false);
    });

    it('should save cart to localStorage', () => {
      cartManager.addItem(testProduct);
      
      const savedCart = JSON.parse(localStorage.getItem('toolhack_cart'));
      expect(savedCart.items.length).toBe(1);
    });
  });

  describe('removeItem', () => {
    it('should remove an item from the cart', () => {
      cartManager.addItem(testProduct);
      expect(cartManager.items.length).toBe(1);
      
      cartManager.removeItem(testProduct.id);
      expect(cartManager.items.length).toBe(0);
    });

    it('should decrease quantity if more than one', () => {
      cartManager.addItem(testProduct);
      cartManager.addItem(testProduct);
      expect(cartManager.items[0].quantity).toBe(2);
      
      cartManager.removeItem(testProduct.id, 1);
      expect(cartManager.items[0].quantity).toBe(1);
    });

    it('should update DOM elements when cart becomes empty', () => {
      cartManager.addItem(testProduct);
      cartManager.removeItem(testProduct.id);
      
      const cartCount = document.getElementById('cartCount');
      expect(cartCount.textContent).toBe('0');
      
      const checkoutButton = document.getElementById('checkoutButton');
      expect(checkoutButton.disabled).toBe(true);
    });
  });

  describe('updateQuantity', () => {
    it('should update item quantity', () => {
      cartManager.addItem(testProduct);
      cartManager.updateQuantity(testProduct.id, 5);
      
      expect(cartManager.items[0].quantity).toBe(5);
    });

    it('should remove item if quantity is set to 0', () => {
      cartManager.addItem(testProduct);
      cartManager.updateQuantity(testProduct.id, 0);
      
      expect(cartManager.items.length).toBe(0);
    });
  });

  describe('getTotal', () => {
    it('should calculate correct total', () => {
      cartManager.addItem(testProduct);
      cartManager.addItem({...testProduct, id: 'test-product-2', price: 10.50});
      
      const total = cartManager.getTotal();
      expect(total).toBe(36.49);
    });

    it('should return 0 for empty cart', () => {
      const total = cartManager.getTotal();
      expect(total).toBe(0);
    });
  });

  describe('clearCart', () => {
    it('should remove all items', () => {
      cartManager.addItem(testProduct);
      cartManager.addItem({...testProduct, id: 'test-product-2'});
      
      cartManager.clearCart();
      expect(cartManager.items.length).toBe(0);
    });

    it('should update DOM elements', () => {
      cartManager.addItem(testProduct);
      cartManager.clearCart();
      
      const cartEmptyMessage = document.getElementById('cartEmptyMessage');
      expect(cartEmptyMessage.style.display).not.toBe('none');
    });
  });

  describe('loadFromStorage', () => {
    it('should load cart from localStorage', () => {
      // Préparer localStorage
      const savedCart = {
        items: [
          {...testProduct, quantity: 3}
        ],
        lastUpdated: new Date().toISOString()
      };
      
      localStorage.setItem('toolhack_cart', JSON.stringify(savedCart));
      
      cartManager.loadFromStorage();
      expect(cartManager.items.length).toBe(1);
      expect(cartManager.items[0].quantity).toBe(3);
    });

    it('should handle empty or invalid localStorage', () => {
      localStorage.setItem('toolhack_cart', 'invalid json');
      
      cartManager.loadFromStorage();
      expect(cartManager.items.length).toBe(0);
    });
  });
});
